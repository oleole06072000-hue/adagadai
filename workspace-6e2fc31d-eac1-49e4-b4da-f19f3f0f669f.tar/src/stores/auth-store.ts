import { create } from 'zustand';
import type { JWTPayload } from '@/lib/auth';

interface AuthState {
  user: JWTPayload | null;
  token: string | null;
  isAuthenticated: boolean;
  login: (token: string, user: JWTPayload) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: null,
  isAuthenticated: false,
  login: (token: string, user: JWTPayload) => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('ada_gadai_token', token);
      localStorage.setItem('ada_gadai_user', JSON.stringify(user));
    }
    set({ token, user, isAuthenticated: true });
  },
  logout: () => {
    if (typeof window !== 'undefined') {
      localStorage.removeItem('ada_gadai_token');
      localStorage.removeItem('ada_gadai_user');
    }
    set({ token: null, user: null, isAuthenticated: false });
  },
}));

export const useAppStore = create<{
  currentPage: string;
  sidebarOpen: boolean;
  selectedBranch: string;
  setCurrentPage: (page: string) => void;
  toggleSidebar: () => void;
  setSidebarOpen: (open: boolean) => void;
  setSelectedBranch: (branch: string) => void;
}>((set) => ({
  currentPage: 'dashboard',
  sidebarOpen: true,
  selectedBranch: 'all',
  setCurrentPage: (page) => set({ currentPage: page }),
  toggleSidebar: () => set((s) => ({ sidebarOpen: !s.sidebarOpen })),
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setSelectedBranch: (branch) => set({ selectedBranch: branch }),
}));