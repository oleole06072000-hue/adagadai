'use client';

import { useState, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Save, AlertCircle, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

interface SettingItem {
  id: string;
  key: string;
  value: string;
  description: string | null;
}

interface SettingsGroup {
  key: string;
  label: string;
  settings: SettingItem[];
}

// Map key prefixes to group labels
const GROUP_MAPPING: Record<string, string> = {
  fee: 'Biaya',
  loan: 'Pinjaman',
  interest: 'Bunga',
  penalty: 'Denda',
  max: 'Batas',
  system: 'Sistem',
  app: 'Aplikasi',
  notification: 'Notifikasi',
};

function inferGroup(key: string): string {
  const prefix = key.split('_')[0].toLowerCase();
  return GROUP_MAPPING[prefix] || 'Lainnya';
}

function inferGroupKey(key: string): string {
  const prefix = key.split('_')[0].toLowerCase();
  return GROUP_MAPPING[prefix] ? prefix : 'other';
}

// Heuristic: determine input type from key/value
function inferType(key: string, value: string): string {
  if (key.toLowerCase().includes('rate') || key.toLowerCase().includes('persen') || key.toLowerCase().includes('percentage')) return 'percentage';
  if (!isNaN(Number(value)) && value !== '') return 'number';
  if (value === 'true' || value === 'false') return 'boolean';
  return 'text';
}

// Make label from key: e.g. "admin_fee_rate" → "Admin Fee Rate"
function keyToLabel(key: string): string {
  return key
    .split('_')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(' ');
}

export default function SettingsPage() {
  const { token } = useAuthStore();
  const queryClient = useQueryClient();

  const { data: raw, isLoading, error } = useQuery<{ data: SettingItem[]; settings: Record<string, string> }>({
    queryKey: ['settings'],
    queryFn: async () => {
      const r = await fetch('/api/settings', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error('Gagal memuat pengaturan');
      return r.json();
    },
  });

  const groups: SettingsGroup[] = useMemo(() => {
    const items = raw?.data || [];
    const groupMap: Record<string, { key: string; label: string; settings: SettingItem[] }> = {};

    for (const item of items) {
      const gk = inferGroupKey(item.key);
      const gl = inferGroup(item.key);
      if (!groupMap[gk]) {
        groupMap[gk] = { key: gk, label: gl, settings: [] };
      }
      groupMap[gk].settings.push(item);
    }

    // If no items, create a default group
    if (Object.keys(groupMap).length === 0) {
      groupMap['system'] = { key: 'system', label: 'Sistem', settings: [] };
    }

    return Object.values(groupMap);
  }, [raw]);

  const [values, setValues] = useState<Record<string, string>>({});

  const initializedData = useMemo(() => {
    const items = raw?.data || [];
    const map: Record<string, string> = {};
    items.forEach((s) => { map[s.key] = s.value; });
    return map;
  }, [raw]);

  const currentValues = Object.keys(values).length === 0 ? initializedData : values;

  const mutation = useMutation({
    mutationFn: async () => {
      const r = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ settings: currentValues }),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal menyimpan'); }
      return r.json();
    },
    onSuccess: () => {
      toast.success('Pengaturan berhasil disimpan');
      setValues({});
      queryClient.invalidateQueries({ queryKey: ['settings'] });
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const updateValue = (key: string, value: string) => {
    setValues((prev) => ({ ...prev, [key]: value }));
  };

  if (error) return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>;

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <div className="space-y-4">{Array.from({ length: 3 }).map((_, i) => <Card key={i}><CardContent className="p-4"><Skeleton className="h-40 w-full" /></CardContent></Card>)}</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Pengaturan</h1>
          <p className="text-sm text-muted-foreground">Konfigurasi sistem gadai</p>
        </div>
        <Button onClick={() => mutation.mutate()} disabled={mutation.isPending} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">
          {mutation.isPending ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
          Simpan Pengaturan
        </Button>
      </div>

      {groups.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-muted-foreground">Belum ada pengaturan.</CardContent></Card>
      ) : (
        <Tabs defaultValue={groups[0]?.key || 'system'}>
          <TabsList>
            {groups.map((g) => (
              <TabsTrigger key={g.key} value={g.key}>{g.label}</TabsTrigger>
            ))}
          </TabsList>

          {groups.map((group) => (
            <TabsContent key={group.key} value={group.key} className="mt-4 space-y-4">
              {group.settings.length === 0 ? (
                <Card><CardContent className="py-8 text-center text-muted-foreground">Tidak ada pengaturan di grup ini.</CardContent></Card>
              ) : (
                group.settings.map((setting) => {
                  const type = inferType(setting.key, currentValues[setting.key] || setting.value);
                  const label = keyToLabel(setting.key);

                  return (
                    <Card key={setting.key}>
                      <CardContent className="p-4">
                        <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                          <div className="flex-1">
                            <Label className="text-sm font-medium">{label}</Label>
                            <p className="text-xs text-muted-foreground mt-0.5">{setting.description || setting.key}</p>
                          </div>
                          <div className="w-full sm:w-48">
                            {type === 'percentage' ? (
                              <div className="relative">
                                <Input
                                  type="number"
                                  value={currentValues[setting.key] || ''}
                                  onChange={(e) => updateValue(setting.key, e.target.value)}
                                  className="pr-8"
                                />
                                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-muted-foreground">%</span>
                              </div>
                            ) : type === 'number' ? (
                              <Input
                                type="number"
                                value={currentValues[setting.key] || ''}
                                onChange={(e) => updateValue(setting.key, e.target.value)}
                              />
                            ) : type === 'boolean' ? (
                              <div className="flex items-center gap-2">
                                <button
                                  type="button"
                                  onClick={() => updateValue(setting.key, currentValues[setting.key] === 'true' ? 'false' : 'true')}
                                  className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                                    currentValues[setting.key] === 'true' ? 'bg-[#FBC02D]' : 'bg-gray-300 dark:bg-gray-600'
                                  }`}
                                >
                                  <span className={`inline-block h-4 w-4 rounded-full bg-white transition-transform ${
                                    currentValues[setting.key] === 'true' ? 'translate-x-6' : 'translate-x-1'
                                  }`} />
                                </button>
                                <span className="text-sm text-muted-foreground">
                                  {currentValues[setting.key] === 'true' ? 'Aktif' : 'Nonaktif'}
                                </span>
                              </div>
                            ) : (
                              <Input
                                value={currentValues[setting.key] || ''}
                                onChange={(e) => updateValue(setting.key, e.target.value)}
                              />
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </TabsContent>
          ))}
        </Tabs>
      )}
    </div>
  );
}