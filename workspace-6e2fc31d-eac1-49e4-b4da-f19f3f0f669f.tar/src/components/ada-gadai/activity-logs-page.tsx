'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuthStore } from '@/stores/auth-store';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Search, AlertCircle } from 'lucide-react';
import { formatDateTime } from '@/lib/format';

interface ActivityLog {
  id: string;
  userId: string;
  user: string;
  action: string;
  module: string;
  description: string;
  ipAddress: string;
  createdAt: string;
}

const MODULES = ['ALL', 'AUTH', 'CUSTOMER', 'SIMULATION', 'LOAN', 'APPROVAL', 'CASH_ACCOUNT', 'CASH_TRANSACTION', 'USER', 'BRANCH', 'SETTINGS'];
const ACTIONS = ['ALL', 'CREATE', 'UPDATE', 'DELETE', 'LOGIN', 'LOGOUT', 'APPROVE', 'REJECT'];

export default function ActivityLogsPage() {
  const { token } = useAuthStore();
  const [search, setSearch] = useState('');
  const [module, setModule] = useState('ALL');
  const [action, setAction] = useState('ALL');

  const { data: raw, isLoading, error } = useQuery<{ data: ActivityLog[]; pagination: { total: number; totalPages: number; page: number; limit: number } }>({
    queryKey: ['activity-logs', search, module, action],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (search) params.set('search', search);
      if (module !== 'ALL') params.set('module', module);
      if (action !== 'ALL') params.set('action', action);
      const r = await fetch(`/api/activity-logs?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!r.ok) throw new Error('Gagal memuat audit log');
      return r.json();
    },
  });

  const logs = raw?.data || [];

  if (error) return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Audit Log</h1>
        <p className="text-sm text-muted-foreground">Riwayat aktivitas pengguna dalam sistem</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Cari pengguna atau deskripsi..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={module} onValueChange={setModule}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Modul" /></SelectTrigger>
          <SelectContent>
            {MODULES.map((m) => <SelectItem key={m} value={m}>{m === 'ALL' ? 'Semua Modul' : m}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={action} onValueChange={setAction}>
          <SelectTrigger className="w-[160px]"><SelectValue placeholder="Aksi" /></SelectTrigger>
          <SelectContent>
            {ACTIONS.map((a) => <SelectItem key={a} value={a}>{a === 'ALL' ? 'Semua Aksi' : a}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="p-6 space-y-3">{Array.from({ length: 8 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px]">No</TableHead>
                    <TableHead>Waktu</TableHead>
                    <TableHead>Pengguna</TableHead>
                    <TableHead>Aksi</TableHead>
                    <TableHead className="hidden md:table-cell">Modul</TableHead>
                    <TableHead className="hidden lg:table-cell">Deskripsi</TableHead>
                    <TableHead className="hidden xl:table-cell">IP Address</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {logs.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Tidak ada log aktivitas</TableCell></TableRow>
                  ) : (
                    logs.map((log, i) => (
                      <TableRow key={log.id}>
                        <TableCell className="text-muted-foreground">{i + 1}</TableCell>
                        <TableCell className="text-xs text-muted-foreground whitespace-nowrap">{formatDateTime(log.createdAt)}</TableCell>
                        <TableCell className="font-medium">{log.user}</TableCell>
                        <TableCell>
                          <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200">
                            {log.action}
                          </span>
                        </TableCell>
                        <TableCell className="hidden md:table-cell">{log.module}</TableCell>
                        <TableCell className="hidden lg:table-cell text-sm text-muted-foreground max-w-[250px] truncate">{log.description}</TableCell>
                        <TableCell className="hidden xl:table-cell font-mono text-xs text-muted-foreground">{log.ipAddress || '-'}</TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}