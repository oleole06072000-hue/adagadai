'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore, useAppStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { Search, Eye, Banknote, ChevronLeft, ChevronRight, AlertCircle, CreditCard, CalendarPlus } from 'lucide-react';
import { toast } from 'sonner';
import { formatRupiah, formatDate, formatDateTime, getStatusColor } from '@/lib/format';

// Raw API shape for a loan from the list endpoint
interface LoanRaw {
  id: string;
  loanNumber: string;
  principalAmount: number;
  loanAmount: number;
  outstanding: number;
  adminFee: number;
  serviceFeeRate: number;
  serviceFee: number;
  penaltyFee: number;
  roundingIncome: number;
  loanDate: string;
  dueDate: string;
  maturityDate: string | null;
  closeDate: string | null;
  status: string;
  disbursementMethod: string;
  bankName: string | null;
  bankAccount: string | null;
  bankAccountHolder: string | null;
  createdAt: string;
  updatedAt: string;
  customer: { id: string; name: string; nik: string; phone: string; customerNumber: string } | null;
  surveyor: { id: string; name: string; username: string } | null;
  branch: { id: string; code: string; name: string } | null;
  assessment: { id: string; assessmentNumber: string; itemName: string; grade: string; photos: string | null } | null;
  account: { id: string; code: string; name: string } | null;
  approval: { id: string; status: string; approvalNumber: string } | null;
  _count: { payments: number; extensions: number };
}

// Flattened shape used by the UI
interface Loan {
  id: string;
  loanNumber: string;
  customerName: string;
  customerNik: string;
  itemName: string;
  itemDescription: string;
  loanAmount: number;
  outstanding: number;
  serviceFeeRate: number;
  status: string;
  loanDate: string;
  dueDate: string;
  tenorDays: number;
  grade: string;
  disbursementMethod: string;
  branchName: string;
  createdAt: string;
}

function flattenLoan(raw: LoanRaw): Loan {
  const loanDate = new Date(raw.loanDate);
  const dueDate = new Date(raw.dueDate);
  const tenorDays = Math.max(0, Math.round((dueDate.getTime() - loanDate.getTime()) / (1000 * 60 * 60 * 24)));
  return {
    id: raw.id,
    loanNumber: raw.loanNumber,
    customerName: raw.customer?.name || '-',
    customerNik: raw.customer?.nik || '-',
    itemName: raw.assessment?.itemName || '-',
    itemDescription: '',
    loanAmount: raw.loanAmount,
    outstanding: raw.outstanding,
    serviceFeeRate: raw.serviceFeeRate,
    status: raw.status,
    loanDate: raw.loanDate,
    dueDate: raw.dueDate,
    tenorDays,
    grade: raw.assessment?.grade || '-',
    disbursementMethod: raw.disbursementMethod,
    branchName: raw.branch?.name || '-',
    createdAt: raw.createdAt,
  };
}

const PAGE_SIZE = 10;

function PaymentDialog({ loan, open, onClose }: { loan: Loan | null; open: boolean; onClose: () => void }) {
  const { token } = useAuthStore();
  const queryClient = useQueryClient();
  const [payAmount, setPayAmount] = useState('');
  const [payType, setPayType] = useState<'PAYMENT' | 'EXTENSION'>('PAYMENT');

  const interestFee = loan ? Math.round(loan.outstanding * (loan.serviceFeeRate / 100) * (30 / 365)) : 0;
  const penaltyFee = loan && new Date(loan.dueDate) < new Date() ? Math.round(loan.outstanding * 0.02) : 0;
  const totalPay = Number(payAmount) || (loan?.outstanding || 0) + interestFee + penaltyFee;

  const mutation = useMutation({
    mutationFn: async () => {
      const r = await fetch(`/api/loans`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: 'payment', loanId: loan!.id, amount: totalPay, paymentMethod: 'CASH' }),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal memproses pembayaran'); }
      return r.json();
    },
    onSuccess: () => {
      toast.success('Pembayaran berhasil diproses');
      queryClient.invalidateQueries({ queryKey: ['loans'] });
      onClose();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Pembayaran / Perpanjangan</DialogTitle>
          <DialogDescription>Loan: {loan?.loanNumber}</DialogDescription>
        </DialogHeader>
        {loan && (
          <div className="space-y-4">
            <div className="flex gap-2">
              <Button size="sm" variant={payType === 'PAYMENT' ? 'default' : 'outline'} onClick={() => setPayType('PAYMENT')} className={payType === 'PAYMENT' ? 'bg-[#FBC02D] text-gray-900' : ''}>
                <CreditCard className="w-4 h-4 mr-1" /> Pelunasan
              </Button>
              <Button size="sm" variant={payType === 'EXTENSION' ? 'default' : 'outline'} onClick={() => setPayType('EXTENSION')} className={payType === 'EXTENSION' ? 'bg-[#FBC02D] text-gray-900' : ''}>
                <CalendarPlus className="w-4 h-4 mr-1" /> Perpanjangan
              </Button>
            </div>
            <Separator />
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-muted-foreground">Outstanding</span><span>{formatRupiah(loan.outstanding)}</span></div>
              <div className="flex justify-between"><span className="text-muted-foreground">Bunga ({loan.serviceFeeRate}%)</span><span>{formatRupiah(interestFee)}</span></div>
              {penaltyFee > 0 && <div className="flex justify-between text-red-600"><span>Denda keterlambatan</span><span>{formatRupiah(penaltyFee)}</span></div>}
              <Separator />
              <div className="flex justify-between font-bold"><span>Total</span><span className="text-[#FBC02D]">{formatRupiah(totalPay)}</span></div>
            </div>
            <div className="space-y-2">
              <Label>Jumlah Bayar</Label>
              <Input type="number" value={payAmount} onChange={(e) => setPayAmount(e.target.value)} placeholder={String(totalPay)} />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={onClose}>Batal</Button>
              <Button onClick={() => mutation.mutate()} disabled={mutation.isPending} className="bg-green-600 hover:bg-green-700 text-white">
                {mutation.isPending ? 'Memproses...' : 'Proses Pembayaran'}
              </Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function LoansPage() {
  const { token } = useAuthStore();
  const { selectedBranch } = useAppStore();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [tab, setTab] = useState('all');
  const [detailOpen, setDetailOpen] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [selected, setSelected] = useState<Loan | null>(null);

  const { data, isLoading, error } = useQuery<{ data: LoanRaw[]; pagination: { page: number; limit: number; total: number; totalPages: number } }>({
    queryKey: ['loans', tab, search, page, selectedBranch],
    queryFn: async () => {
      const params = new URLSearchParams({ page: String(page), limit: String(PAGE_SIZE) });
      if (tab !== 'all') params.set('status', tab);
      if (search) params.set('search', search);
      if (selectedBranch !== 'all') params.set('branch', selectedBranch);
      const res = await fetch(`/api/loans?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Gagal memuat data loan');
      return res.json();
    },
  });

  const loans = (data?.data || []).map(flattenLoan);
  const total = data?.pagination?.total || 0;
  const totalPages = Math.ceil(total / PAGE_SIZE);

  const statusLabels: Record<string, string> = {
    ACTIVE: 'Aktif',
    OVERDUE: 'Jatuh Tempo',
    PAID_OFF: 'Lunas',
    CLOSED: 'Lelang',
    PENDING_APPROVAL: 'Menunggu Persetujuan',
    REJECTED: 'Ditolak',
  };

  if (error) {
    return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>;
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Loan</h1>
        <p className="text-sm text-muted-foreground">Kelola pinjaman gadai</p>
      </div>

      <Tabs value={tab} onValueChange={(v) => { setTab(v); setPage(1); }}>
        <TabsList>
          <TabsTrigger value="all">Semua</TabsTrigger>
          <TabsTrigger value="ACTIVE">Aktif</TabsTrigger>
          <TabsTrigger value="OVERDUE">Jatuh Tempo</TabsTrigger>
          <TabsTrigger value="PAID_OFF">Lunas</TabsTrigger>
          <TabsTrigger value="CLOSED">Lelang</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4 space-y-4">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Cari loan no, nasabah..." value={search} onChange={(e) => { setSearch(e.target.value); setPage(1); }} className="pl-9" />
          </div>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                {isLoading ? (
                  <div className="p-6 space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
                ) : (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-[50px]">No</TableHead>
                        <TableHead>No Loan</TableHead>
                        <TableHead>Nasabah</TableHead>
                        <TableHead className="hidden sm:table-cell">Nilai Pinjaman</TableHead>
                        <TableHead className="hidden md:table-cell">Outstanding</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="hidden lg:table-cell">Tgl Mulai</TableHead>
                        <TableHead className="w-[120px]">Aksi</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {loans.length === 0 ? (
                        <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">Tidak ada data loan</TableCell></TableRow>
                      ) : (
                        loans.map((l, i) => (
                          <TableRow key={l.id}>
                            <TableCell className="text-muted-foreground">{(page - 1) * PAGE_SIZE + i + 1}</TableCell>
                            <TableCell className="font-mono text-xs">{l.loanNumber}</TableCell>
                            <TableCell className="font-medium">{l.customerName}</TableCell>
                            <TableCell className="hidden sm:table-cell">{formatRupiah(l.loanAmount)}</TableCell>
                            <TableCell className="hidden md:table-cell">{formatRupiah(l.outstanding)}</TableCell>
                            <TableCell><Badge variant="secondary" className={getStatusColor(l.status)}>{statusLabels[l.status] || l.status}</Badge></TableCell>
                            <TableCell className="hidden lg:table-cell text-muted-foreground text-xs">{formatDate(l.loanDate)}</TableCell>
                            <TableCell>
                              <div className="flex items-center gap-1">
                                <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => { setSelected(l); setDetailOpen(true); }} title="Detail"><Eye className="w-4 h-4" /></Button>
                                {(l.status === 'ACTIVE' || l.status === 'OVERDUE') && (
                                  <Button size="icon" variant="ghost" className="h-8 w-8 text-green-600" onClick={() => { setSelected(l); setPaymentOpen(true); }} title="Bayar">
                                    <Banknote className="w-4 h-4" />
                                  </Button>
                                )}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                )}
              </div>

              {!isLoading && totalPages > 1 && (
                <div className="flex items-center justify-between px-4 py-3 border-t">
                  <p className="text-sm text-muted-foreground">Halaman {page} dari {totalPages} ({total} data)</p>
                  <div className="flex items-center gap-2">
                    <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}><ChevronLeft className="w-4 h-4" /></Button>
                    <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}><ChevronRight className="w-4 h-4" /></Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Detail Loan</DialogTitle></DialogHeader>
          {selected && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><span className="text-muted-foreground">No Loan</span><p className="font-mono">{selected.loanNumber}</p></div>
                <div><span className="text-muted-foreground">Status</span><p><Badge variant="secondary" className={getStatusColor(selected.status)}>{statusLabels[selected.status] || selected.status}</Badge></p></div>
                <div><span className="text-muted-foreground">Nasabah</span><p className="font-medium">{selected.customerName}</p></div>
                <div><span className="text-muted-foreground">NIK</span><p className="font-mono">{selected.customerNik}</p></div>
                <div><span className="text-muted-foreground">Barang</span><p>{selected.itemName}</p></div>
                <div><span className="text-muted-foreground">Grade</span><p>{selected.grade}</p></div>
                <div><span className="text-muted-foreground">Nilai Pinjaman</span><p className="font-semibold">{formatRupiah(selected.loanAmount)}</p></div>
                <div><span className="text-muted-foreground">Outstanding</span><p className="font-semibold text-red-600">{formatRupiah(selected.outstanding)}</p></div>
                <div><span className="text-muted-foreground">Bunga</span><p>{selected.serviceFeeRate}%</p></div>
                <div><span className="text-muted-foreground">Tenor</span><p>{selected.tenorDays} hari</p></div>
                <div><span className="text-muted-foreground">Pencairan</span><p>{selected.disbursementMethod}</p></div>
                <div><span className="text-muted-foreground">Cabang</span><p>{selected.branchName || '-'}</p></div>
              </div>
              <Separator />
              <div className="text-xs text-muted-foreground">
                <p>Mulai: {formatDateTime(selected.loanDate)}</p>
                <p>Jatuh Tempo: {formatDateTime(selected.dueDate)}</p>
              </div>
              <div><span className="text-muted-foreground">Deskripsi Barang</span><p>{selected.itemDescription || '-'}</p></div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <PaymentDialog loan={selected} open={paymentOpen} onClose={() => { setPaymentOpen(false); setSelected(null); }} />
    </div>
  );
}