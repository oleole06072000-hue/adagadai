'use client';

import { useQuery } from '@tanstack/react-query';
import { useAuthStore, useAppStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Users, FileSearch, Banknote, TrendingUp, Clock, AlertTriangle, Wallet, AlertCircle,
} from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend,
} from 'recharts';
import { formatRupiah, formatDate, getStatusColor } from '@/lib/format';

interface DashboardKpis {
  totalCustomers: number;
  totalAssessments: number;
  totalActiveLoans: number;
  totalOutstanding: number;
  totalIncome: number;
  pendingApprovals: number;
  nearDue: number;
  dueToday: number;
  overdue: number;
  todayNewCustomers: number;
  todayNewLoans: number;
}

interface DashboardData {
  kpis: DashboardKpis;
  chartData: {
    monthlyLoans: { month: string; loans: number; payments: number }[];
    categoryDistribution: { name: string; value: number }[];
  };
  recentActivities: {
    id: string;
    action: string;
    module: string;
    description: string;
    user: string;
    createdAt: string;
  }[];
}

const PIE_COLORS = ['#FBC02D', '#4CAF50', '#2196F3', '#FF9800', '#9C27B0', '#F44336'];

function KpiCard({ title, value, icon: Icon, color, isCurrency }: {
  title: string; value: number; icon: React.ElementType; color: string; isCurrency?: boolean;
}) {
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4 flex items-center gap-4">
        <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className="min-w-0">
          <p className="text-xs text-muted-foreground font-medium uppercase tracking-wide">{title}</p>
          <p className="text-lg font-bold truncate">{isCurrency ? formatRupiah(value) : value.toLocaleString('id-ID')}</p>
        </div>
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {Array.from({ length: 8 }).map((_, i) => (
          <Card key={i}><CardContent className="p-4"><Skeleton className="h-16 w-full" /></CardContent></Card>
        ))}
      </div>
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Card key={i}><CardHeader><Skeleton className="h-5 w-40" /></CardHeader><CardContent><Skeleton className="h-[250px] w-full" /></CardContent></Card>
        ))}
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const { token } = useAuthStore();
  const { selectedBranch } = useAppStore();

  const { data, isLoading, error } = useQuery<DashboardData>({
    queryKey: ['dashboard', selectedBranch],
    queryFn: async () => {
      const params = selectedBranch !== 'all' ? `?branch=${selectedBranch}` : '';
      const res = await fetch(`/api/dashboard${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Gagal memuat data dashboard');
      return res.json();
    },
  });

  if (isLoading) return <DashboardSkeleton />;

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>{error.message}</AlertDescription>
      </Alert>
    );
  }

  const kpis = data?.kpis;
  const chartData = data?.chartData;
  const activities = data?.recentActivities || [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-sm text-muted-foreground">Ringkasan data operasional gadai</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard title="Total Nasabah" value={kpis?.totalCustomers ?? 0} icon={Users} color="bg-blue-500" />
        <KpiCard title="Total Pengajuan" value={kpis?.totalAssessments ?? 0} icon={FileSearch} color="bg-green-500" />
        <KpiCard title="Loan Aktif" value={kpis?.totalActiveLoans ?? 0} icon={Banknote} color="bg-orange-500" />
        <KpiCard title="Outstanding" value={kpis?.totalOutstanding ?? 0} icon={TrendingUp} color="bg-red-500" isCurrency />
        <KpiCard title="Approval Pending" value={kpis?.pendingApprovals ?? 0} icon={Clock} color="bg-purple-500" />
        <KpiCard title="Jatuh Tempo" value={kpis?.dueToday ?? 0} icon={AlertTriangle} color="bg-red-500" />
        <KpiCard title="Total Pendapatan" value={kpis?.totalIncome ?? 0} icon={Wallet} color="bg-green-500" isCurrency />
        <KpiCard title="Nasabah Hari Ini" value={kpis?.todayNewCustomers ?? 0} icon={TrendingUp} color="bg-emerald-500" />
      </div>

      {/* Charts */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Monthly Applications Bar Chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Pengajuan Bulanan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData?.monthlyLoans || []}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <RechartsTooltip />
                  <Bar dataKey="loans" fill="#FBC02D" radius={[4, 4, 0, 0]} name="Loan" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Cash Flow Line Chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Cash Flow</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData?.monthlyLoans || []}>
                  <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                  <XAxis dataKey="month" tick={{ fontSize: 11 }} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <RechartsTooltip />
                  <Line type="monotone" dataKey="payments" stroke="#4CAF50" strokeWidth={2} name="Pembayaran" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Category Pie Chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-semibold">Kategori Barang</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[250px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData?.categoryDistribution || []}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                    nameKey="name"
                  >
                    {(chartData?.categoryDistribution || []).map((_, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend wrapperStyle={{ fontSize: 11 }} />
                  <RechartsTooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activities */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-semibold">Aktivitas Terbaru</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-[50px]">No</TableHead>
                  <TableHead>Pengguna</TableHead>
                  <TableHead>Aksi</TableHead>
                  <TableHead>Modul</TableHead>
                  <TableHead className="hidden md:table-cell">Deskripsi</TableHead>
                  <TableHead>Waktu</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {activities.length === 0 ? (
                  <TableRow><TableCell colSpan={6} className="text-center py-8 text-muted-foreground">Belum ada aktivitas</TableCell></TableRow>
                ) : (
                  activities.map((act, i) => (
                    <TableRow key={act.id}>
                      <TableCell className="text-muted-foreground">{i + 1}</TableCell>
                      <TableCell className="font-medium">{act.user}</TableCell>
                      <TableCell><Badge variant="secondary" className={getStatusColor(act.action)}>{act.action}</Badge></TableCell>
                      <TableCell>{act.module}</TableCell>
                      <TableCell className="hidden md:table-cell text-muted-foreground max-w-[200px] truncate">{act.description}</TableCell>
                      <TableCell className="text-muted-foreground text-xs">{formatDate(act.createdAt)}</TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}