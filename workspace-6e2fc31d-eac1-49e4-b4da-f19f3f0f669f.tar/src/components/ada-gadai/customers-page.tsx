'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore, useAppStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
  DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Search, Plus, Eye, Pencil, Trash2, AlertCircle, ChevronLeft, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';
import { formatDate, getStatusColor } from '@/lib/format';

interface Customer {
  id: string;
  customerNumber: string;
  name: string;
  nik: string;
  birthPlace: string;
  birthDate: string;
  gender: string;
  address: string;
  kelurahan: string;
  kecamatan: string;
  kabupaten: string;
  provinsi: string;
  postalCode: string;
  phone: string;
  email: string;
  occupation: string;
  maritalStatus: string;
  isActive: boolean;
  branch: { id: string; code: string; name: string } | null;
  _count: { loans: number; assessments: number };
  createdAt: string;
}

const PAGE_SIZE = 10;

function CustomerForm({ customer, onClose }: {
  customer: Partial<Customer> | null;
  onClose: () => void;
}) {
  const { token } = useAuthStore();
  const queryClient = useQueryClient();
  const isEdit = !!customer?.id;

  const [form, setForm] = useState({
    name: customer?.name || '',
    nik: customer?.nik || '',
    birthPlace: customer?.birthPlace || '',
    birthDate: customer?.birthDate ? customer.birthDate.split('T')[0] : '',
    gender: customer?.gender || '',
    address: customer?.address || '',
    kelurahan: customer?.kelurahan || '',
    kecamatan: customer?.kecamatan || '',
    kabupaten: customer?.kabupaten || '',
    provinsi: customer?.provinsi || '',
    postalCode: customer?.postalCode || '',
    phone: customer?.phone || '',
    email: customer?.email || '',
    occupation: customer?.occupation || '',
    maritalStatus: customer?.maritalStatus || '',
  });

  const mutation = useMutation({
    mutationFn: async () => {
      const body: Record<string, string> = { ...form };
      if (isEdit) {
        body.id = customer!.id;
      }
      const url = isEdit ? `/api/customers/${customer!.id}` : '/api/customers';
      const method = isEdit ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
      });
      if (!res.ok) {
        const d = await res.json();
        throw new Error(d.error || 'Gagal menyimpan data nasabah');
      }
      return res.json();
    },
    onSuccess: () => {
      toast.success(isEdit ? 'Nasabah berhasil diperbarui' : 'Nasabah berhasil ditambahkan');
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      onClose();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutation.mutate();
  };

  const updateField = (field: string, value: string) => setForm((prev) => ({ ...prev, [field]: value }));

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label>Nama Lengkap *</Label>
          <Input value={form.name} onChange={(e) => updateField('name', e.target.value)} required />
        </div>
        <div className="space-y-2">
          <Label>NIK *</Label>
          <Input value={form.nik} onChange={(e) => updateField('nik', e.target.value)} required maxLength={16} />
        </div>
        <div className="space-y-2">
          <Label>Tempat Lahir</Label>
          <Input value={form.birthPlace} onChange={(e) => updateField('birthPlace', e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label>Tanggal Lahir</Label>
          <Input type="date" value={form.birthDate} onChange={(e) => updateField('birthDate', e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label>Jenis Kelamin</Label>
          <Select value={form.gender} onValueChange={(v) => updateField('gender', v)}>
            <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="LAKI_LAKI">Laki-laki</SelectItem>
              <SelectItem value="PEREMPUAN">Perempuan</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-2">
          <Label>Pekerjaan</Label>
          <Input value={form.occupation} onChange={(e) => updateField('occupation', e.target.value)} />
        </div>
      </div>
      <div className="space-y-2">
        <Label>Alamat *</Label>
        <Input value={form.address} onChange={(e) => updateField('address', e.target.value)} required />
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="space-y-2"><Label>Kelurahan</Label><Input value={form.kelurahan} onChange={(e) => updateField('kelurahan', e.target.value)} /></div>
        <div className="space-y-2"><Label>Kecamatan</Label><Input value={form.kecamatan} onChange={(e) => updateField('kecamatan', e.target.value)} /></div>
        <div className="space-y-2"><Label>Kode Pos</Label><Input value={form.postalCode} onChange={(e) => updateField('postalCode', e.target.value)} /></div>
        <div className="space-y-2"><Label>Status Pernikahan</Label>
          <Select value={form.maritalStatus} onValueChange={(v) => updateField('maritalStatus', v)}>
            <SelectTrigger><SelectValue placeholder="Pilih" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="BELUM_MENIKAH">Belum Menikah</SelectItem>
              <SelectItem value="MENIKAH">Menikah</SelectItem>
              <SelectItem value="CERAI">Cerai</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2"><Label>Kabupaten/Kota</Label><Input value={form.kabupaten} onChange={(e) => updateField('kabupaten', e.target.value)} /></div>
        <div className="space-y-2"><Label>Provinsi</Label><Input value={form.provinsi} onChange={(e) => updateField('provinsi', e.target.value)} /></div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-2"><Label>No HP *</Label><Input value={form.phone} onChange={(e) => updateField('phone', e.target.value)} required /></div>
        <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => updateField('email', e.target.value)} /></div>
      </div>
      <DialogFooter>
        <Button type="button" variant="outline" onClick={onClose}>Batal</Button>
        <Button type="submit" disabled={mutation.isPending} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">
          {mutation.isPending ? 'Menyimpan...' : isEdit ? 'Perbarui' : 'Simpan'}
        </Button>
      </DialogFooter>
    </form>
  );
}

export default function CustomersPage() {
  const { token } = useAuthStore();
  const { selectedBranch } = useAppStore();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const [formOpen, setFormOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selected, setSelected] = useState<Customer | null>(null);

  const { data, isLoading, error } = useQuery<{ data: Customer[]; pagination: { page: number; limit: number; total: number; totalPages: number } }>({
    queryKey: ['customers', search, page, selectedBranch],
    queryFn: async () => {
      const params = new URLSearchParams({ page: String(page), limit: String(PAGE_SIZE) });
      if (search) params.set('search', search);
      if (selectedBranch !== 'all') params.set('branch', selectedBranch);
      const res = await fetch(`/api/customers?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Gagal memuat data nasabah');
      return res.json();
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      if (!selected?.id) return;
      const res = await fetch(`/api/customers/${selected.id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Gagal menghapus nasabah');
    },
    onSuccess: () => {
      toast.success('Nasabah berhasil dihapus');
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      setDeleteOpen(false);
      setSelected(null);
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const customers = data?.data || [];
  const total = data?.pagination?.total || 0;
  const totalPages = Math.ceil(total / PAGE_SIZE);

  if (error) {
    return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>;
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Nasabah</h1>
          <p className="text-sm text-muted-foreground">Kelola data nasabah gadai</p>
        </div>
        <Dialog open={formOpen} onOpenChange={(open) => { setFormOpen(open); if (!open) setSelected(null); }}>
          <DialogTrigger asChild>
            <Button className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">
              <Plus className="w-4 h-4 mr-2" />Tambah Nasabah
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{selected?.id ? 'Edit Nasabah' : 'Tambah Nasabah Baru'}</DialogTitle>
              <DialogDescription>Lengkapi data nasabah di bawah ini.</DialogDescription>
            </DialogHeader>
            <CustomerForm customer={selected} onClose={() => { setFormOpen(false); setSelected(null); }} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Search */}
      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder="Cari nama, NIK, atau no HP..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setPage(1); }}
          className="pl-9"
        />
      </div>

      {/* Table */}
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="p-6 space-y-3">
                {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px]">No</TableHead>
                    <TableHead>No Nasabah</TableHead>
                    <TableHead>Nama</TableHead>
                    <TableHead className="hidden sm:table-cell">NIK</TableHead>
                    <TableHead className="hidden md:table-cell">No HP</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="w-[120px]">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {customers.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Tidak ada data nasabah</TableCell></TableRow>
                  ) : (
                    customers.map((c, i) => (
                      <TableRow key={c.id}>
                        <TableCell className="text-muted-foreground">{(page - 1) * PAGE_SIZE + i + 1}</TableCell>
                        <TableCell className="font-mono text-xs">{c.customerNumber}</TableCell>
                        <TableCell className="font-medium">{c.name}</TableCell>
                        <TableCell className="hidden sm:table-cell font-mono text-xs">{c.nik}</TableCell>
                        <TableCell className="hidden md:table-cell">{c.phone}</TableCell>
                        <TableCell><Badge variant="secondary" className={c.isActive ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'}>{c.isActive ? 'Aktif' : 'Nonaktif'}</Badge></TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1">
                            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => { setSelected(c); setDetailOpen(true); }} title="Detail">
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => { setSelected(c); setFormOpen(true); }} title="Edit">
                              <Pencil className="w-4 h-4" />
                            </Button>
                            <Button size="icon" variant="ghost" className="h-8 w-8 text-red-500 hover:text-red-700" onClick={() => { setSelected(c); setDeleteOpen(true); }} title="Hapus">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            )}
          </div>

          {/* Pagination */}
          {!isLoading && totalPages > 1 && (
            <div className="flex items-center justify-between px-4 py-3 border-t">
              <p className="text-sm text-muted-foreground">
                Halaman {page} dari {totalPages} ({total} data)
              </p>
              <div className="flex items-center gap-2">
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                  <ChevronLeft className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                  <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Detail Nasabah</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><span className="text-muted-foreground">No Nasabah</span><p className="font-mono">{selected.customerNumber}</p></div>
                <div><span className="text-muted-foreground">Status</span><p><Badge variant="secondary" className={selected.isActive ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400'}>{selected.isActive ? 'Aktif' : 'Nonaktif'}</Badge></p></div>
                <div><span className="text-muted-foreground">Nama</span><p className="font-medium">{selected.name}</p></div>
                <div><span className="text-muted-foreground">NIK</span><p className="font-mono">{selected.nik}</p></div>
                <div><span className="text-muted-foreground">Tempat, Tgl Lahir</span><p>{selected.birthPlace || '-'}, {selected.birthDate ? formatDate(selected.birthDate) : '-'}</p></div>
                <div><span className="text-muted-foreground">Jenis Kelamin</span><p>{selected.gender === 'LAKI_LAKI' ? 'Laki-laki' : selected.gender === 'PEREMPUAN' ? 'Perempuan' : '-'}</p></div>
                <div><span className="text-muted-foreground">No HP</span><p>{selected.phone}</p></div>
                <div><span className="text-muted-foreground">Email</span><p>{selected.email || '-'}</p></div>
                <div><span className="text-muted-foreground">Pekerjaan</span><p>{selected.occupation || '-'}</p></div>
              </div>
              <div>
                <span className="text-muted-foreground">Alamat</span>
                <p>{selected.address}{selected.kelurahan ? `, ${selected.kelurahan}` : ''}{selected.kecamatan ? `, ${selected.kecamatan}` : ''}{selected.kabupaten ? `, ${selected.kabupaten}` : ''}{selected.provinsi ? `, ${selected.provinsi}` : ''}{selected.postalCode ? ` ${selected.postalCode}` : ''}</p>
              </div>
              <div className="text-xs text-muted-foreground">Terdaftar: {formatDate(selected.createdAt)}</div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Nasabah?</AlertDialogTitle>
            <AlertDialogDescription>
              Data nasabah <strong>{selected?.name}</strong> akan dihapus secara permanen. Tindakan ini tidak dapat dibatalkan.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteMutation.mutate()} disabled={deleteMutation.isPending} className="bg-red-600 hover:bg-red-700">
              {deleteMutation.isPending ? 'Menghapus...' : 'Hapus'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}