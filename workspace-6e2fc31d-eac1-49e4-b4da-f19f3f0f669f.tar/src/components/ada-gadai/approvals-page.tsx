'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore, useAppStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Separator } from '@/components/ui/separator';
import { CheckCircle, XCircle, AlertCircle, Clock, User, Package, CalendarDays } from 'lucide-react';
import { toast } from 'sonner';
import { formatRupiah, formatDateTime, getStatusColor } from '@/lib/format';

// Raw API response shape for a single approval from the list endpoint
interface ApprovalRaw {
  id: string;
  approvalNumber: string;
  type: string;
  referenceId: string;
  status: string;
  approverId: string | null;
  approver: { id: string; name: string; username: string } | null;
  notes: string | null;
  approvedAt: string | null;
  createdAt: string;
  updatedAt: string;
  assessments: Array<{
    id: string;
    assessmentNumber: string;
    itemName: string | null;
    recommendedLoan: number;
    customer: { name: string } | null;
    surveyor: { name: string } | null;
    branch: { name: string } | null;
  }>;
  loans: Array<{
    id: string;
    loanNumber: string;
    loanAmount: number;
    customer: { name: string } | null;
    branch: { name: string } | null;
  }>;
}

// Flattened shape used by the UI
interface Approval {
  id: string;
  approvalNumber: string;
  type: string;
  customerName: string;
  itemName: string;
  recommendedLoan: number;
  marketPrice: number;
  grade: string;
  liquidationPercentage: number;
  tenorDays: number;
  disbursementMethod: string;
  surveyorName: string;
  status: string;
  notes: string;
  createdAt: string;
}

function flattenApproval(raw: ApprovalRaw): Approval {
  const assessment = raw.assessments?.[0];
  const loan = raw.loans?.[0];
  return {
    id: raw.id,
    approvalNumber: raw.approvalNumber,
    type: raw.type,
    customerName: assessment?.customer?.name || loan?.customer?.name || '-',
    itemName: assessment?.itemName || '-',
    recommendedLoan: assessment?.recommendedLoan || 0,
    marketPrice: 0, // not returned by list API
    grade: '-', // not returned by list API
    liquidationPercentage: 0, // not returned by list API
    tenorDays: 0, // not returned by list API
    disbursementMethod: '-', // not returned by list API
    surveyorName: assessment?.surveyor?.name || '-',
    status: raw.status,
    notes: raw.notes || '',
    createdAt: raw.createdAt,
  };
}

export default function ApprovalsPage() {
  const { token, user } = useAuthStore();
  const { selectedBranch } = useAppStore();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState('PENDING');
  const [actionOpen, setActionOpen] = useState(false);
  const [actionType, setActionType] = useState<'approve' | 'reject'>('approve');
  const [actionNotes, setActionNotes] = useState('');
  const [selected, setSelected] = useState<Approval | null>(null);

  const { data, isLoading, error } = useQuery<{ data: ApprovalRaw[]; pagination: { page: number; limit: number; total: number; totalPages: number } }>({
    queryKey: ['approvals', tab, selectedBranch],
    queryFn: async () => {
      const params = new URLSearchParams({ status: tab });
      if (selectedBranch !== 'all') params.set('branch', selectedBranch);
      const res = await fetch(`/api/approvals?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error('Gagal memuat data approval');
      return res.json();
    },
  });

  const approvals = (data?.data || []).map(flattenApproval);

  const actionMutation = useMutation({
    mutationFn: async () => {
      if (!selected) return;
      const res = await fetch(`/api/approvals/${selected.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ action: actionType, notes: actionNotes }),
      });
      if (!res.ok) { const d = await res.json(); throw new Error(d.error || 'Gagal memproses approval'); }
      return res.json();
    },
    onSuccess: () => {
      toast.success(actionType === 'approve' ? 'Pengajuan disetujui' : 'Pengajuan ditolak');
      queryClient.invalidateQueries({ queryKey: ['approvals'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard'] });
      setActionOpen(false);
      setSelected(null);
      setActionNotes('');
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const openAction = (approval: Approval, type: 'approve' | 'reject') => {
    setSelected(approval);
    setActionType(type);
    setActionNotes('');
    setActionOpen(true);
  };

  const statusLabels: Record<string, string> = {
    PENDING: 'Menunggu', APPROVED: 'Disetujui', REJECTED: 'Ditolak',
  };

  if (error) {
    return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>;
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Approval</h1>
        <p className="text-sm text-muted-foreground">Kelola persetujuan pengajuan gadai</p>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          <TabsTrigger value="PENDING">Menunggu</TabsTrigger>
          <TabsTrigger value="APPROVED">Disetujui</TabsTrigger>
          <TabsTrigger value="REJECTED">Ditolak</TabsTrigger>
        </TabsList>

        <TabsContent value={tab} className="mt-4">
          {isLoading ? (
            <div className="grid md:grid-cols-2 gap-4">
              {Array.from({ length: 4 }).map((_, i) => <Card key={i}><CardContent className="p-4"><Skeleton className="h-40 w-full" /></CardContent></Card>)}
            </div>
          ) : approvals.length === 0 ? (
            <Card><CardContent className="py-12 text-center text-muted-foreground">
              <Clock className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>Tidak ada pengajuan {tab === 'PENDING' ? 'menunggu' : tab === 'APPROVED' ? 'disetujui' : 'ditolak'}</p>
            </CardContent></Card>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {approvals.map((a) => (
                <Card key={a.id} className="overflow-hidden">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-mono">{a.approvalNumber}</CardTitle>
                      <Badge variant="secondary" className={getStatusColor(a.status)}>
                        {statusLabels[a.status] || a.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center gap-2"><User className="w-3.5 h-3.5 text-muted-foreground" /><div><p className="text-muted-foreground text-xs">Nasabah</p><p className="font-medium">{a.customerName}</p></div></div>
                      <div className="flex items-center gap-2"><Package className="w-3.5 h-3.5 text-muted-foreground" /><div><p className="text-muted-foreground text-xs">Barang</p><p className="font-medium">{a.itemName}</p></div></div>
                    </div>
                    <Separator />
                    <div className="grid grid-cols-2 gap-2">
                      <div><span className="text-muted-foreground">Pinjaman</span><p className="font-bold text-[#FBC02D]">{formatRupiah(a.recommendedLoan)}</p></div>
                      <div><span className="text-muted-foreground">Tipe</span><p>{a.type === 'ASSESSMENT' ? 'Simulasi' : a.type === 'LOAN' ? 'Pinjaman' : a.type}</p></div>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <CalendarDays className="w-3.5 h-3.5" />
                      <span>{a.surveyorName} &middot; {formatDateTime(a.createdAt)}</span>
                    </div>

                    {a.status === 'PENDING' && (
                      <div className="flex gap-2 pt-2">
                        <Button size="sm" className="flex-1 bg-green-600 hover:bg-green-700 text-white" onClick={() => openAction(a, 'approve')}>
                          <CheckCircle className="w-4 h-4 mr-1" /> Setujui
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1 text-red-600 border-red-200 hover:bg-red-50" onClick={() => openAction(a, 'reject')}>
                          <XCircle className="w-4 h-4 mr-1" /> Tolak
                        </Button>
                      </div>
                    )}

                    {a.notes && (
                      <p className="text-xs text-muted-foreground bg-gray-50 dark:bg-gray-800/50 rounded p-2">Catatan: {a.notes}</p>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Action Dialog */}
      <Dialog open={actionOpen} onOpenChange={setActionOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{actionType === 'approve' ? 'Setujui' : 'Tolak'} Pengajuan</DialogTitle>
            <DialogDescription>
              {actionType === 'approve'
                ? `Setujui pengajuan ${selected?.approvalNumber} dari ${selected?.customerName}?`
                : `Tolak pengajuan ${selected?.approvalNumber} dari ${selected?.customerName}?`
              }
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {selected && (
              <div className="bg-gray-50 dark:bg-gray-800/50 rounded-lg p-3 text-sm">
                <p className="font-medium">{selected.customerName} - {selected.itemName}</p>
                <p className="text-[#FBC02D] font-bold">{formatRupiah(selected.recommendedLoan)}</p>
              </div>
            )}
            <div className="space-y-2">
              <Label>Catatan</Label>
              <Textarea
                value={actionNotes}
                onChange={(e) => setActionNotes(e.target.value)}
                placeholder={actionType === 'approve' ? 'Catatan persetujuan (opsional)' : 'Alasan penolakan'}
                rows={3}
              />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setActionOpen(false)}>Batal</Button>
              <Button
                onClick={() => actionMutation.mutate()}
                disabled={actionMutation.isPending}
                className={actionType === 'approve' ? 'bg-green-600 hover:bg-green-700 text-white' : 'bg-red-600 hover:bg-red-700 text-white'}
              >
                {actionMutation.isPending ? 'Memproses...' : actionType === 'approve' ? 'Setujui' : 'Tolak'}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}