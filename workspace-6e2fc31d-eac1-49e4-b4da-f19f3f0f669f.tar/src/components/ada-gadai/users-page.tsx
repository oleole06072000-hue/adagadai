'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/stores/auth-store';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, Pencil, Trash2, AlertCircle, Search } from 'lucide-react';
import { toast } from 'sonner';
import { formatDate } from '@/lib/format';

interface UserRecord {
  id: string; username: string; name: string; role: string; email: string;
  phone: string; isActive: boolean; branchId: string | null;
  branch?: { id: string; code: string; name: string } | null;
  lastLogin: string; createdAt: string;
}
interface BranchOption { id: string; name: string; }

const ROLES = ['ADMIN', 'SURVEYOR', 'KEPALA_CABANG'];

export default function UsersPage() {
  const { token } = useAuthStore();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState('');
  const [formOpen, setFormOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selected, setSelected] = useState<UserRecord | null>(null);
  const [form, setForm] = useState({ username: '', name: '', email: '', phone: '', role: '', branchId: '', password: '' });

  const { data: branchesRaw } = useQuery<{ data: { id: string; code: string; name: string }[] }>({
    queryKey: ['branches-list'],
    queryFn: async () => { const r = await fetch('/api/branches', { headers: { Authorization: `Bearer ${token}` } }); if (!r.ok) return { data: [] }; return r.json(); },
  });
  const branches: BranchOption[] = (branchesRaw?.data || []).map((b) => ({ id: b.id, name: b.name }));

  const { data: usersRaw, isLoading, error } = useQuery<{ data: UserRecord[]; pagination: { total: number; totalPages: number; page: number; limit: number } }>({
    queryKey: ['users', search],
    queryFn: async () => {
      const params = search ? `?search=${search}` : '';
      const r = await fetch(`/api/users${params}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error('Gagal memuat data pengguna');
      return r.json();
    },
  });
  const users = usersRaw?.data || [];

  const saveMutation = useMutation({
    mutationFn: async () => {
      const isEdit = !!selected?.id;
      const url = isEdit ? `/api/users/${selected!.id}` : '/api/users';
      const body = { ...form, branchId: form.branchId || null };
      if (isEdit) delete (body as Record<string, unknown>).password;
      const r = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(body),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal menyimpan'); }
      return r.json();
    },
    onSuccess: () => {
      toast.success(selected?.id ? 'Pengguna diperbarui' : 'Pengguna ditambahkan');
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setFormOpen(false); setSelected(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const r = await fetch(`/api/users/${selected!.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error('Gagal menghapus');
    },
    onSuccess: () => {
      toast.success('Pengguna dihapus');
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setDeleteOpen(false); setSelected(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const openEdit = (u: UserRecord) => {
    setSelected(u);
    setForm({ username: u.username, name: u.name, email: u.email || '', phone: u.phone || '', role: u.role, branchId: u.branchId || '', password: '' });
    setFormOpen(true);
  };
  const openAdd = () => {
    setSelected(null);
    setForm({ username: '', name: '', email: '', phone: '', role: '', branchId: '', password: '' });
    setFormOpen(true);
  };

  if (error) return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Pengguna</h1>
          <p className="text-sm text-muted-foreground">Kelola akun pengguna sistem</p>
        </div>
        <Button className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900" onClick={openAdd}>
          <Plus className="w-4 h-4 mr-2" />Tambah Pengguna
        </Button>
      </div>

      <div className="relative max-w-sm">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Cari pengguna..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
      </div>

      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="p-6 space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Username</TableHead>
                    <TableHead>Nama</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead className="hidden md:table-cell">Cabang</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="hidden lg:table-cell">Login Terakhir</TableHead>
                    <TableHead className="w-[100px]">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.length === 0 ? (
                    <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">Tidak ada pengguna</TableCell></TableRow>
                  ) : users.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-mono text-sm">{u.username}</TableCell>
                      <TableCell className="font-medium">{u.name}</TableCell>
                      <TableCell><Badge variant="outline">{u.role}</Badge></TableCell>
                      <TableCell className="hidden md:table-cell">{u.branch?.name || '-'}</TableCell>
                      <TableCell><Badge variant={u.isActive ? 'default' : 'secondary'} className={u.isActive ? 'bg-green-100 text-green-800' : ''}>{u.isActive ? 'Aktif' : 'Nonaktif'}</Badge></TableCell>
                      <TableCell className="hidden lg:table-cell text-sm text-muted-foreground">{u.lastLogin ? formatDate(u.lastLogin) : '-'}</TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(u)}><Pencil className="w-4 h-4" /></Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 text-red-500" onClick={() => { setSelected(u); setDeleteOpen(true); }}><Trash2 className="w-4 h-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Form Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{selected?.id ? 'Edit' : 'Tambah'} Pengguna</DialogTitle>
            <DialogDescription>{selected?.id ? 'Perbarui data pengguna.' : 'Lengkapi data pengguna baru.'}</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Username *</Label><Input value={form.username} onChange={(e) => setForm((p) => ({ ...p, username: e.target.value }))} /></div>
              <div className="space-y-2"><Label>Nama *</Label><Input value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} /></div>
            </div>
            {!selected?.id && (
              <div className="space-y-2"><Label>Password *</Label><Input type="password" value={form.password} onChange={(e) => setForm((p) => ({ ...p, password: e.target.value }))} /></div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} /></div>
              <div className="space-y-2"><Label>No HP</Label><Input value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Role *</Label>
                <Select value={form.role} onValueChange={(v) => setForm((p) => ({ ...p, role: v }))}>
                  <SelectTrigger><SelectValue placeholder="Pilih role" /></SelectTrigger>
                  <SelectContent>{ROLES.map((r) => <SelectItem key={r} value={r}>{r}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Cabang</Label>
                <Select value={form.branchId} onValueChange={(v) => setForm((p) => ({ ...p, branchId: v }))}>
                  <SelectTrigger><SelectValue placeholder="Pilih cabang" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Tanpa Cabang</SelectItem>
                    {branches.map((b) => <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setFormOpen(false)}>Batal</Button>
              <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">
                {saveMutation.isPending ? 'Menyimpan...' : 'Simpan'}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Pengguna?</AlertDialogTitle>
            <AlertDialogDescription>Akun <strong>{selected?.name}</strong> ({selected?.username}) akan dihapus.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteMutation.mutate()} className="bg-red-600 hover:bg-red-700">Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}