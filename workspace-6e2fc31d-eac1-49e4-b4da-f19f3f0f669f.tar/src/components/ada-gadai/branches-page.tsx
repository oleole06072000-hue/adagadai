'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, Pencil, Trash2, AlertCircle, Users, MapPin, Phone } from 'lucide-react';
import { toast } from 'sonner';

interface BranchRaw {
  id: string; name: string; code: string; address: string; area: string; regional: string;
  phone: string; isActive: boolean;
  _count?: { users: number; customers: number; loans: number; accounts: number };
  createdAt: string;
}

interface Branch extends BranchRaw {
  userCount: number;
}

export default function BranchesPage() {
  const { token } = useAuthStore();
  const queryClient = useQueryClient();
  const [formOpen, setFormOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selected, setSelected] = useState<Branch | null>(null);
  const [form, setForm] = useState({ name: '', code: '', address: '', city: '', province: '', phone: '', email: '' });

  const { data: raw, isLoading, error } = useQuery<{ data: BranchRaw[] }>({
    queryKey: ['branches'],
    queryFn: async () => {
      const r = await fetch('/api/branches', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error('Gagal memuat data cabang');
      return r.json();
    },
  });

  const data: Branch[] = (raw?.data || []).map((b) => ({
    ...b,
    userCount: b._count?.users ?? 0,
  }));

  const saveMutation = useMutation({
    mutationFn: async () => {
      const isEdit = !!selected?.id;
      const url = isEdit ? `/api/branches/${selected!.id}` : '/api/branches';
      const r = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(form),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal menyimpan'); }
      return r.json();
    },
    onSuccess: () => {
      toast.success(selected?.id ? 'Cabang diperbarui' : 'Cabang ditambahkan');
      queryClient.invalidateQueries({ queryKey: ['branches'] });
      setFormOpen(false); setSelected(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const r = await fetch(`/api/branches/${selected!.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error('Gagal menghapus');
    },
    onSuccess: () => {
      toast.success('Cabang dihapus');
      queryClient.invalidateQueries({ queryKey: ['branches'] });
      setDeleteOpen(false); setSelected(null);
    },
    onError: (e: Error) => toast.error(e.message),
  });

  const openEdit = (b: Branch) => {
    setSelected(b);
    setForm({ name: b.name, code: b.code, address: b.address || '', city: '', province: '', phone: b.phone || '', email: '' });
    setFormOpen(true);
  };
  const openAdd = () => {
    setSelected(null);
    setForm({ name: '', code: '', address: '', city: '', province: '', phone: '', email: '' });
    setFormOpen(true);
  };

  if (error) return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Cabang</h1>
          <p className="text-sm text-muted-foreground">Kelola data cabang gadai</p>
        </div>
        <Button className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900" onClick={openAdd}>
          <Plus className="w-4 h-4 mr-2" />Tambah Cabang
        </Button>
      </div>

      {isLoading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => <Card key={i}><CardContent className="p-4"><Skeleton className="h-32 w-full" /></CardContent></Card>)}
        </div>
      ) : data.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-muted-foreground">Tidak ada cabang</CardContent></Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {data.map((b) => (
            <Card key={b.id} className="hover:shadow-md transition-shadow">
              <CardHeader className="pb-2">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-base">{b.name}</CardTitle>
                    <Badge variant="outline" className="mt-1 font-mono text-xs">{b.code}</Badge>
                  </div>
                  <div className="flex gap-1">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(b)}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-red-500" onClick={() => { setSelected(b); setDeleteOpen(true); }}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                {b.address && (
                  <div className="flex items-start gap-2 text-muted-foreground">
                    <MapPin className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{b.address}</span>
                  </div>
                )}
                {b.phone && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Phone className="w-4 h-4 shrink-0" />
                    <span>{b.phone}</span>
                  </div>
                )}
                <div className="flex items-center justify-between pt-2 border-t">
                  <div className="flex items-center gap-1.5 text-muted-foreground">
                    <Users className="w-4 h-4" />
                    <span>{b.userCount} pengguna</span>
                  </div>
                  <Badge variant={b.isActive ? 'default' : 'secondary'} className={b.isActive ? 'bg-green-100 text-green-800' : ''}>
                    {b.isActive ? 'Aktif' : 'Nonaktif'}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Form Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>{selected?.id ? 'Edit' : 'Tambah'} Cabang</DialogTitle>
            <DialogDescription>Lengkapi data cabang.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Nama *</Label><Input value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} /></div>
              <div className="space-y-2"><Label>Kode *</Label><Input value={form.code} onChange={(e) => setForm((p) => ({ ...p, code: e.target.value }))} placeholder="e.g. CBG-001" /></div>
            </div>
            <div className="space-y-2"><Label>Alamat</Label><Input value={form.address} onChange={(e) => setForm((p) => ({ ...p, address: e.target.value }))} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Kota</Label><Input value={form.city} onChange={(e) => setForm((p) => ({ ...p, city: e.target.value }))} /></div>
              <div className="space-y-2"><Label>Provinsi</Label><Input value={form.province} onChange={(e) => setForm((p) => ({ ...p, province: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Telepon</Label><Input value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} /></div>
              <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} /></div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setFormOpen(false)}>Batal</Button>
              <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">
                {saveMutation.isPending ? 'Menyimpan...' : 'Simpan'}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Hapus Cabang?</AlertDialogTitle>
            <AlertDialogDescription>Cabang <strong>{selected?.name}</strong> beserta {selected?.userCount} pengguna akan dihapus.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Batal</AlertDialogCancel>
            <AlertDialogAction onClick={() => deleteMutation.mutate()} className="bg-red-600 hover:bg-red-700">Hapus</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}