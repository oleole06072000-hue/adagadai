'use client';

import { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import {
  Search, ChevronRight, ChevronLeft, CheckCircle, User, Package,
  Calculator, Send, Loader2, AlertCircle, Camera, Banknote, Building2,
} from 'lucide-react';
import { toast } from 'sonner';
import { formatRupiah, getGradeColor } from '@/lib/format';

interface CustomerBrief { id: string; name: string; nik: string; phone: string; customerNumber: string; }
interface Category { id: string; name: string; description: string | null; icon: string | null; isActive: boolean; sortOrder: number; }
interface ItemPrice { id: string; marketPrice: number; liquidationPercent: number; liquidationPrice: number; effectiveDate: string; }
interface MasterItem {
  id: string; name: string; brand: string | null; model: string | null;
  categoryId: string; category: { id: string; name: string };
  ram: string | null; storage: string | null; specs: string | null;
  isActive: boolean; prices: ItemPrice[];
}
interface ChecklistItem {
  id: string; name: string; category: { id: string; name: string };
  weight: number; type: string | null; grade: string | null; isActive: boolean;
}
interface GradeItem {
  id: string; grade: string; factor: number; description: string | null;
  minScore: number; maxScore: number; sortOrder: number;
}

const STEPS = [
  { label: 'Data Nasabah', icon: User },
  { label: 'Barang Jaminan', icon: Package },
  { label: 'Kalkulasi', icon: Calculator },
  { label: 'Kirim', icon: Send },
];

export default function SimulationPage() {
  const { token, user } = useAuthStore();
  const queryClient = useQueryClient();
  const [step, setStep] = useState(0);

  // Step 1: Customer
  const [nikSearch, setNikSearch] = useState('');
  const [searching, setSearching] = useState(false);
  const [customer, setCustomer] = useState<CustomerBrief | null>(null);
  const [showRegister, setShowRegister] = useState(false);
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');

  // Step 2: Item
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedItem, setSelectedItem] = useState<MasterItem | null>(null);
  const [itemDesc, setItemDesc] = useState('');
  const [checklistResults, setChecklistResults] = useState<Record<string, boolean>>({});

  // Step 3: Calculation
  const [selectedGrade, setSelectedGrade] = useState('');
  const [liquidPct, setLiquidPct] = useState(80);
  const [disbursement, setDisbursement] = useState<'CASH' | 'TRANSFER'>('CASH');
  const [loanTenor, setLoanTenor] = useState(90);

  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ['categories'],
    queryFn: async () => {
      const r = await fetch('/api/master/categories', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
  });

  // Fetch items (with prices) for selected category
  const { data: items } = useQuery<MasterItem[]>({
    queryKey: ['master-items', selectedCategory],
    queryFn: async () => {
      if (!selectedCategory) return [];
      const r = await fetch(`/api/master/items?categoryId=${selectedCategory}&includePrices=true`, { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
    enabled: !!selectedCategory,
  });

  // Fetch checklists for selected category
  const { data: checklists } = useQuery<ChecklistItem[]>({
    queryKey: ['checklists', selectedCategory],
    queryFn: async () => {
      if (!selectedCategory) return [];
      const r = await fetch(`/api/master/checklists?categoryId=${selectedCategory}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
    enabled: !!selectedCategory,
  });

  // Fetch grades
  const { data: grades } = useQuery<GradeItem[]>({
    queryKey: ['grades'],
    queryFn: async () => {
      const r = await fetch('/api/master/grades', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
  });

  // Search customer by NIK/name
  const handleSearchCustomer = async () => {
    if (!nikSearch || nikSearch.length < 10) {
      toast.error('Masukkan NIK yang valid (min. 10 digit)');
      return;
    }
    setSearching(true);
    try {
      const res = await fetch(`/api/customers?search=${nikSearch}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const json = await res.json();
      const customers = json.data || [];
      if (customers.length > 0) {
        setCustomer(customers[0]);
        setShowRegister(false);
        toast.success(`Nasabah ditemukan: ${customers[0].name}`);
      } else {
        setCustomer(null);
        setShowRegister(true);
        toast.info('Nasabah belum terdaftar. Silakan lengkapi data.');
      }
    } catch {
      toast.error('Gagal mencari nasabah');
    } finally {
      setSearching(false);
    }
  };

  // Calculations
  const marketPrice = selectedItem?.prices?.[0]?.marketPrice || 0;
  const gradeFactor = grades?.find((g) => g.grade === selectedGrade)?.factor || 0;
  const recommendedLoan = marketPrice * (liquidPct / 100) * gradeFactor;

  // Auto description
  useEffect(() => {
    if (selectedItem) {
      const cat = categories?.find((c) => c.id === selectedCategory);
      setItemDesc(`${selectedItem.name}${cat ? ` - ${cat.name}` : ''}. Kondisi ${selectedGrade || '-'}. Penilaian berdasarkan checklist.`);
    }
  }, [selectedItem, selectedCategory, selectedGrade, categories]);

  const submitMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        customerId: customer?.id,
        itemId: selectedItem?.id,
        itemName: selectedItem?.name,
        itemBrand: selectedItem?.brand,
        itemModel: selectedItem?.model,
        itemRam: selectedItem?.ram,
        itemStorage: selectedItem?.storage,
        itemSpecs: selectedItem?.specs,
        priceId: selectedItem?.prices?.[0]?.id,
        categoryId: selectedCategory,
        autoDescription: itemDesc,
        description: itemDesc,
        marketPrice,
        liquidationPercent: liquidPct,
        liquidationPrice: marketPrice * (liquidPct / 100),
        grade: selectedGrade,
        gradeFactor,
        recommendedLoan,
        disbursementMethod: disbursement,
        checklistResults,
        status: 'DRAFT',
      };
      const r = await fetch('/api/assessments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify(payload),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal mengirim simulasi'); }
      return r.json();
    },
    onSuccess: () => {
      toast.success('Simulasi berhasil dikirim untuk approval');
      queryClient.invalidateQueries({ queryKey: ['assessments'] });
      resetForm();
    },
    onError: (err: Error) => toast.error(err.message),
  });

  const resetForm = () => {
    setStep(0);
    setNikSearch(''); setCustomer(null); setShowRegister(false); setRegName(''); setRegPhone('');
    setSelectedCategory(''); setSelectedItem(null); setItemDesc(''); setChecklistResults({});
    setSelectedGrade(''); setLiquidPct(80); setDisbursement('CASH'); setLoanTenor(90);
  };

  const canNext = () => {
    if (step === 0) return customer?.id || (showRegister && regName && regPhone);
    if (step === 1) return selectedItem && selectedCategory;
    if (step === 2) return selectedGrade && recommendedLoan > 0;
    return true;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Simulasi Gadai</h1>
        <p className="text-sm text-muted-foreground">Buat simulasi pengajuan gadai baru</p>
      </div>

      {/* Step Indicator */}
      <div className="flex items-center justify-center gap-2">
        {STEPS.map((s, i) => (
          <div key={i} className="flex items-center gap-2">
            <button
              onClick={() => i < step && setStep(i)}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                i === step ? 'bg-[#FBC02D] text-gray-900' : i < step ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-gray-100 text-gray-400 dark:bg-gray-800 dark:text-gray-500'
              }`}
            >
              {i < step ? <CheckCircle className="w-4 h-4" /> : <s.icon className="w-4 h-4" />}
              <span className="hidden sm:inline">{s.label}</span>
            </button>
            {i < STEPS.length - 1 && <ChevronRight className="w-4 h-4 text-muted-foreground" />}
          </div>
        ))}
      </div>

      {/* Step Content */}
      <Card>
        <CardContent className="p-6">
          {/* Step 1: Customer */}
          {step === 0 && (
            <div className="space-y-4">
              <h3 className="font-semibold">Langkah 1: Data Nasabah</h3>
              <p className="text-sm text-muted-foreground">Cari nasabah berdasarkan NIK atau daftarkan nasabah baru.</p>

              <div className="flex gap-2">
                <div className="relative flex-1 max-w-sm">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input placeholder="Masukkan NIK nasabah..." value={nikSearch} onChange={(e) => setNikSearch(e.target.value)} className="pl-9" />
                </div>
                <Button onClick={handleSearchCustomer} disabled={searching}>
                  {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4 mr-2" />}
                  Cari
                </Button>
              </div>

              {customer && (
                <Card className="bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-semibold text-green-800 dark:text-green-400">Nasabah Ditemukan</span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div><span className="text-muted-foreground">Nama:</span> <strong>{customer.name}</strong></div>
                      <div><span className="text-muted-foreground">No HP:</span> {customer.phone}</div>
                      <div><span className="text-muted-foreground">NIK:</span> {customer.nik}</div>
                      <div><span className="text-muted-foreground">No Nasabah:</span> {customer.customerNumber}</div>
                    </div>
                  </CardContent>
                </Card>
              )}

              {showRegister && !customer && (
                <Card className="bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
                  <CardContent className="p-4 space-y-3">
                    <p className="text-sm font-medium text-yellow-800 dark:text-yellow-400">Nasabah belum terdaftar. Lengkapi data berikut:</p>
                    <div className="grid sm:grid-cols-2 gap-3">
                      <div className="space-y-1"><Label>Nama Lengkap *</Label><Input value={regName} onChange={(e) => setRegName(e.target.value)} /></div>
                      <div className="space-y-1"><Label>No HP *</Label><Input value={regPhone} onChange={(e) => setRegPhone(e.target.value)} /></div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {/* Step 2: Item */}
          {step === 1 && (
            <div className="space-y-4">
              <h3 className="font-semibold">Langkah 2: Barang Jaminan</h3>

              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Kategori Barang *</Label>
                  <Select value={selectedCategory} onValueChange={(v) => { setSelectedCategory(v); setSelectedItem(null); }}>
                    <SelectTrigger><SelectValue placeholder="Pilih kategori" /></SelectTrigger>
                    <SelectContent>
                      {(categories || []).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Nama Barang *</Label>
                  <Select value={selectedItem?.id || ''} onValueChange={(v) => setSelectedItem((items || []).find((i) => i.id === v) || null)} disabled={!selectedCategory}>
                    <SelectTrigger><SelectValue placeholder="Pilih barang" /></SelectTrigger>
                    <SelectContent>
                      {(items || []).map((i) => <SelectItem key={i.id} value={i.id}>{i.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {selectedItem && (
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-3 text-sm">
                  <span className="text-muted-foreground">Harga Pasar:</span>{' '}
                  <strong className="text-blue-800 dark:text-blue-400">{formatRupiah(marketPrice)}</strong>
                </div>
              )}

              {/* Checklist */}
              {(checklists || []).length > 0 && (
                <div className="space-y-3">
                  <Label className="text-sm font-medium">Checklist Penilaian</Label>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {(checklists || []).map((cl) => (
                      <div key={cl.id} className="flex items-center gap-2 p-2 rounded border bg-card">
                        <Checkbox
                          checked={checklistResults[cl.id] || false}
                          onCheckedChange={(checked) => setChecklistResults((prev) => ({ ...prev, [cl.id]: !!checked }))}
                        />
                        <span className="text-sm">{cl.name}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Photo Placeholder */}
              <div className="flex items-center gap-4">
                <Button variant="outline" className="gap-2" type="button">
                  <Camera className="w-4 h-4" /> Upload Foto Barang
                </Button>
                <span className="text-xs text-muted-foreground">Belum ada foto diunggah</span>
              </div>
            </div>
          )}

          {/* Step 3: Calculation */}
          {step === 2 && (
            <div className="space-y-4">
              <h3 className="font-semibold">Langkah 3: Kalkulasi Harga</h3>

              <div className="grid sm:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Grade</Label>
                  <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                    <SelectTrigger><SelectValue placeholder="Pilih grade" /></SelectTrigger>
                    <SelectContent>
                      {(grades || []).map((g) => (
                        <SelectItem key={g.id} value={g.grade}>
                          <div className="flex items-center gap-2">
                            <Badge className={getGradeColor(g.grade)}>{g.grade}</Badge>
                            <span className="text-xs">{g.description || g.grade} (x{g.factor})</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Persentase Likuidasi (%)</Label>
                  <Input type="number" min={50} max={100} value={liquidPct} onChange={(e) => setLiquidPct(Number(e.target.value))} />
                </div>
                <div className="space-y-2">
                  <Label>Tenor (Hari)</Label>
                  <Select value={String(loanTenor)} onValueChange={(v) => setLoanTenor(Number(v))}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="30">30 Hari</SelectItem>
                      <SelectItem value="60">60 Hari</SelectItem>
                      <SelectItem value="90">90 Hari</SelectItem>
                      <SelectItem value="120">120 Hari</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Calculation Display */}
              <Card className="bg-gray-50 dark:bg-gray-800/50">
                <CardContent className="p-4 space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Harga Pasar</span>
                    <span className="font-medium">{formatRupiah(marketPrice)}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Persentase Likuidasi</span>
                    <span className="font-medium">{liquidPct}%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Grade ({selectedGrade || '-'})</span>
                    <span><Badge className={getGradeColor(selectedGrade)}>{selectedGrade || '-'}</Badge></span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Faktor Grade</span>
                    <span className="font-medium">{gradeFactor}x</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between">
                    <span className="font-semibold">Pinjaman yang Disarankan</span>
                    <span className="font-bold text-lg text-[#FBC02D]">{formatRupiah(recommendedLoan)}</span>
                  </div>
                </CardContent>
              </Card>

              {/* Disbursement */}
              <div className="space-y-2">
                <Label>Metode Pencairan</Label>
                <RadioGroup value={disbursement} onValueChange={(v) => setDisbursement(v as 'CASH' | 'TRANSFER')} className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="CASH" id="cash" />
                    <Label htmlFor="cash" className="flex items-center gap-2 cursor-pointer"><Banknote className="w-4 h-4" /> Tunai</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem value="TRANSFER" id="transfer" />
                    <Label htmlFor="transfer" className="flex items-center gap-2 cursor-pointer"><Building2 className="w-4 h-4" /> Transfer</Label>
                  </div>
                </RadioGroup>
              </div>

              {/* Item Description */}
              <div className="space-y-2">
                <Label>Deskripsi Barang</Label>
                <textarea
                  className="w-full min-h-[80px] rounded-md border border-input bg-transparent px-3 py-2 text-sm"
                  value={itemDesc}
                  onChange={(e) => setItemDesc(e.target.value)}
                />
              </div>
            </div>
          )}

          {/* Step 4: Review */}
          {step === 3 && (
            <div className="space-y-4">
              <h3 className="font-semibold">Langkah 4: Review & Kirim</h3>
              <p className="text-sm text-muted-foreground">Periksa kembali data sebelum mengirim.</p>

              <div className="grid sm:grid-cols-2 gap-4">
                <Card><CardHeader className="pb-2"><CardTitle className="text-sm">Data Nasabah</CardTitle></CardHeader>
                  <CardContent className="text-sm space-y-1">
                    <p><span className="text-muted-foreground">Nama:</span> {customer?.name || regName}</p>
                    <p><span className="text-muted-foreground">NIK:</span> {nikSearch}</p>
                    <p><span className="text-muted-foreground">No HP:</span> {customer?.phone || regPhone}</p>
                  </CardContent>
                </Card>
                <Card><CardHeader className="pb-2"><CardTitle className="text-sm">Barang Jaminan</CardTitle></CardHeader>
                  <CardContent className="text-sm space-y-1">
                    <p><span className="text-muted-foreground">Barang:</span> {selectedItem?.name}</p>
                    <p><span className="text-muted-foreground">Grade:</span> <Badge className={getGradeColor(selectedGrade)}>{selectedGrade}</Badge></p>
                    <p><span className="text-muted-foreground">Harga Pasar:</span> {formatRupiah(marketPrice)}</p>
                  </CardContent>
                </Card>
              </div>

              <Card className="bg-[#FBC02D]/10 border-[#FBC02D]/30">
                <CardContent className="p-4 text-center">
                  <p className="text-sm text-muted-foreground mb-1">Pinjaman yang Disarankan</p>
                  <p className="text-3xl font-bold text-[#FBC02D]">{formatRupiah(recommendedLoan)}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {liquidPct}% likuidasi &times; {gradeFactor}x grade &times; {formatRupiah(marketPrice)} | {loanTenor} hari | {disbursement === 'CASH' ? 'Tunai' : 'Transfer'}
                  </p>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Navigation Buttons */}
          <div className="flex justify-between pt-6 border-t mt-6">
            <Button variant="outline" onClick={() => step > 0 && setStep((s) => s - 1)} disabled={step === 0}>
              <ChevronLeft className="w-4 h-4 mr-2" /> Kembali
            </Button>
            {step < 3 ? (
              <Button onClick={() => setStep((s) => s + 1)} disabled={!canNext()} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">
                Lanjut <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            ) : (
              <Button onClick={() => submitMutation.mutate()} disabled={submitMutation.isPending} className="bg-green-600 hover:bg-green-700 text-white">
                {submitMutation.isPending ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Mengirim...</> : 'Kirim Pengajuan'}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}