'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore, useAppStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Wallet, TrendingUp, TrendingDown, Plus, ArrowUpCircle, ArrowDownCircle, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { formatRupiah, formatDateTime } from '@/lib/format';

interface CashAccount {
  id: string; name: string; code: string; currentBalance: number; type: string;
  branch?: { id: string; code: string; name: string } | null;
}
interface CashTransactionRaw {
  id: string; transactionNumber: string; type: string; category: string; amount: number;
  description: string; debitAccountId: string | null;
  debitAccount?: { id: string; code: string; name: string } | null;
  creditAccountId: string | null;
  creditAccount?: { id: string; code: string; name: string } | null;
  referenceId: string | null; userId: string;
  user?: { id: string; name: string; username: string } | null;
  createdAt: string;
}

const CATEGORIES = [
  { value: 'DISBURSEMENT', label: 'Pencairan' },
  { value: 'COLLECTION', label: 'Pembayaran' },
  { value: 'TRANSFER', label: 'Transfer' },
  { value: 'ADJUSTMENT', label: 'Penyesuaian' },
];

function AddTransactionDialog({ open, onClose, accounts }: {
  open: boolean; onClose: () => void; accounts: CashAccount[];
}) {
  const { token } = useAuthStore();
  const queryClient = useQueryClient();
  const [type, setType] = useState('INCOME');
  const [category, setCategory] = useState('DISBURSEMENT');
  const [amount, setAmount] = useState('');
  const [debitId, setDebitId] = useState('');
  const [creditId, setCreditId] = useState('');
  const [description, setDescription] = useState('');
  const [referenceId, setReferenceId] = useState('');

  const mutation = useMutation({
    mutationFn: async () => {
      const r = await fetch('/api/cash/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({ type, category, amount: Number(amount), debitAccountId: debitId, creditAccountId: creditId, description, referenceId }),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal menyimpan transaksi'); }
      return r.json();
    },
    onSuccess: () => {
      toast.success('Transaksi berhasil dicatat');
      queryClient.invalidateQueries({ queryKey: ['cash'] });
      onClose();
      setAmount(''); setDescription(''); setReferenceId('');
    },
    onError: (err: Error) => toast.error(err.message),
  });

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Tambah Transaksi</DialogTitle>
          <DialogDescription>Catat transaksi kas baru (double-entry).</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Jenis</Label>
            <Select value={type} onValueChange={setType}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="INCOME">Pendapatan</SelectItem>
                <SelectItem value="EXPENSE">Pengeluaran</SelectItem>
                <SelectItem value="TRANSFER">Transfer Antar Kas</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Kategori</Label>
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger><SelectValue placeholder="Pilih kategori" /></SelectTrigger>
              <SelectContent>
                {CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label>Jumlah (Rp)</Label>
            <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0" />
          </div>
          <div className="space-y-2">
            <Label>Rekening Debit (Penerima)</Label>
            <Select value={debitId} onValueChange={setDebitId}>
              <SelectTrigger><SelectValue placeholder="Pilih rekening" /></SelectTrigger>
              <SelectContent>
                {accounts.map((a) => <SelectItem key={a.id} value={a.id}>{a.name} ({formatRupiah(a.currentBalance)})</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {type !== 'INCOME' && (
            <div className="space-y-2">
              <Label>Rekening Kredit (Pengirim)</Label>
              <Select value={creditId} onValueChange={setCreditId}>
                <SelectTrigger><SelectValue placeholder="Pilih rekening" /></SelectTrigger>
                <SelectContent>
                  {accounts.map((a) => <SelectItem key={a.id} value={a.id}>{a.name} ({formatRupiah(a.currentBalance)})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}
          <div className="space-y-2">
            <Label>Keterangan</Label>
            <Input value={description} onChange={(e) => setDescription(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label>No Referensi</Label>
            <Input value={referenceId} onChange={(e) => setReferenceId(e.target.value)} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={onClose}>Batal</Button>
            <Button onClick={() => mutation.mutate()} disabled={mutation.isPending || !amount || !debitId || !category} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">
              {mutation.isPending ? 'Menyimpan...' : 'Simpan'}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default function CashPage() {
  const { token } = useAuthStore();
  const { selectedBranch } = useAppStore();
  const [addOpen, setAddOpen] = useState(false);

  const { data: summary, isLoading: summaryLoading, error } = useQuery({
    queryKey: ['cash-summary', selectedBranch],
    queryFn: async () => {
      const params = selectedBranch !== 'all' ? `?branchId=${selectedBranch}` : '';
      const r = await fetch(`/api/cash/summary${params}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error('Gagal memuat data kas');
      return r.json();
    },
  });

  const { data: accountsRaw } = useQuery<{ data: CashAccount[] }>({
    queryKey: ['cash-accounts', selectedBranch],
    queryFn: async () => {
      const params = selectedBranch !== 'all' ? `?branchId=${selectedBranch}` : '';
      const r = await fetch(`/api/cash/accounts${params}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return { data: [] };
      return r.json();
    },
  });
  const accounts = accountsRaw?.data || [];

  const { data: transactionsRaw } = useQuery<{ data: CashTransactionRaw[]; pagination: { total: number; totalPages: number; page: number; limit: number } }>({
    queryKey: ['cash-transactions', selectedBranch],
    queryFn: async () => {
      const params = selectedBranch !== 'all' ? `?branchId=${selectedBranch}` : '';
      const r = await fetch(`/api/cash/transactions${params}`, { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return { data: [], pagination: { total: 0, totalPages: 0, page: 1, limit: 20 } };
      return r.json();
    },
  });
  const transactions = transactionsRaw?.data || [];

  if (error) {
    return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>;
  }

  const totalBalance = summary?.totalBalance || 0;
  const todayInflow = summary?.todayInflow || 0;
  const todayOutflow = summary?.todayOutflow || 0;

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Cash Management</h1>
          <p className="text-sm text-muted-foreground">Kelola kas dan transaksi keuangan</p>
        </div>
        <Button className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900" onClick={() => setAddOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />Tambah Transaksi
        </Button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-green-500 flex items-center justify-center"><Wallet className="w-6 h-6 text-white" /></div>
            <div><p className="text-xs text-muted-foreground font-medium">Total Saldo</p><p className="text-lg font-bold">{formatRupiah(totalBalance)}</p></div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-emerald-500 flex items-center justify-center"><TrendingUp className="w-6 h-6 text-white" /></div>
            <div><p className="text-xs text-muted-foreground font-medium">Pendapatan Hari Ini</p><p className="text-lg font-bold text-green-600">{formatRupiah(todayInflow)}</p></div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-red-500 flex items-center justify-center"><TrendingDown className="w-6 h-6 text-white" /></div>
            <div><p className="text-xs text-muted-foreground font-medium">Pengeluaran Hari Ini</p><p className="text-lg font-bold text-red-600">{formatRupiah(todayOutflow)}</p></div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="accounts">
        <TabsList>
          <TabsTrigger value="accounts">Rekening Kas</TabsTrigger>
          <TabsTrigger value="transactions">Transaksi</TabsTrigger>
        </TabsList>

        <TabsContent value="accounts" className="mt-4">
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {summaryLoading ? (
              Array.from({ length: 3 }).map((_, i) => <Card key={i}><CardContent className="p-4"><Skeleton className="h-20 w-full" /></CardContent></Card>)
            ) : accounts.length === 0 ? (
              <Card><CardContent className="py-12 text-center text-muted-foreground">Tidak ada rekening kas</CardContent></Card>
            ) : (
              accounts.map((a) => (
                <Card key={a.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-2">
                      <p className="font-semibold">{a.name}</p>
                      <Badge variant="outline" className="text-xs">{a.branch?.name || '-'}</Badge>
                    </div>
                    <p className="font-mono text-xs text-muted-foreground mb-1">{a.code}</p>
                    <p className="text-xl font-bold text-green-600">{formatRupiah(a.currentBalance)}</p>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="transactions" className="mt-4">
          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>No Transaksi</TableHead>
                      <TableHead>Jenis</TableHead>
                      <TableHead>Kategori</TableHead>
                      <TableHead>Jumlah</TableHead>
                      <TableHead className="hidden md:table-cell">Debit</TableHead>
                      <TableHead className="hidden md:table-cell">Kredit</TableHead>
                      <TableHead className="hidden lg:table-cell">Keterangan</TableHead>
                      <TableHead>Waktu</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.length === 0 ? (
                      <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">Tidak ada transaksi</TableCell></TableRow>
                    ) : (
                      transactions.map((t) => (
                        <TableRow key={t.id}>
                          <TableCell className="font-mono text-xs">{t.transactionNumber}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className={t.type === 'INCOME' ? 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400' : t.type === 'EXPENSE' ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400' : 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'}>
                              {t.type === 'INCOME' ? <ArrowUpCircle className="w-3 h-3 inline mr-1" /> : t.type === 'EXPENSE' ? <ArrowDownCircle className="w-3 h-3 inline mr-1" /> : null}
                              {t.type}
                            </Badge>
                          </TableCell>
                          <TableCell><Badge variant="outline" className="text-xs">{t.category}</Badge></TableCell>
                          <TableCell className="font-medium">{formatRupiah(t.amount)}</TableCell>
                          <TableCell className="hidden md:table-cell text-sm">{t.debitAccount?.name || '-'}</TableCell>
                          <TableCell className="hidden md:table-cell text-sm">{t.creditAccount?.name || '-'}</TableCell>
                          <TableCell className="hidden lg:table-cell text-sm text-muted-foreground max-w-[150px] truncate">{t.description}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{formatDateTime(t.createdAt)}</TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <AddTransactionDialog open={addOpen} onClose={() => setAddOpen(false)} accounts={accounts} />
    </div>
  );
}