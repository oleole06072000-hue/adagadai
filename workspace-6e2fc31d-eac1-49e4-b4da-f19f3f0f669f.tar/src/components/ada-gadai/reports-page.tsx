'use client';

import { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useAuthStore, useAppStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Download, AlertCircle, FileText, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import { formatRupiah, formatDate } from '@/lib/format';
import { Input } from '@/components/ui/input';

const REPORT_TYPES = [
  { value: 'loan-summary', label: 'Ringkasan Pinjaman' },
  { value: 'payment-summary', label: 'Ringkasan Pembayaran' },
  { value: 'cash-flow', label: 'Arus Kas' },
  { value: 'overdue-report', label: 'Laporan Jatuh Tempo' },
  { value: 'branch-summary', label: 'Ringkasan Cabang' },
];

// Friendly column header labels
const COLUMN_LABELS: Record<string, string> = {
  id: 'ID',
  loanNumber: 'No Pinjaman',
  customerName: 'Nama Nasabah',
  customerNik: 'NIK',
  branchName: 'Cabang',
  itemName: 'Nama Barang',
  grade: 'Grade',
  principalAmount: 'Pokok',
  loanAmount: 'Jumlah Pinjaman',
  outstanding: 'Tunggakan',
  status: 'Status',
  loanDate: 'Tanggal Pinjaman',
  dueDate: 'Jatuh Tempo',
  paymentNumber: 'No Pembayaran',
  type: 'Tipe',
  principalPaid: 'Pokok Dibayar',
  serviceFeePaid: 'Biaya Layanan',
  penaltyPaid: 'Denda',
  adminFeePaid: 'Biaya Admin',
  totalPaid: 'Total Dibayar',
  paymentMethod: 'Metode Bayar',
  receivedBy: 'Diterima Oleh',
  createdAt: 'Tanggal',
  customerPhone: 'Telepon Nasabah',
  daysOverdue: 'Hari Terlambat',
  monthsOverdue: 'Bulan Terlambat',
  serviceFeeDue: 'Biaya Layanan Terutang',
  penaltyDue: 'Denda Terutang',
  totalPayable: 'Total Harus Dibayar',
  surveyorName: 'Surveyor',
  totalPayments: 'Jumlah Pembayaran',
  code: 'Kode',
  name: 'Nama',
  area: 'Area',
  regional: 'Regional',
  totalUsers: 'Total Pengguna',
  totalCustomers: 'Total Nasabah',
  activeLoans: 'Pinjaman Aktif',
  totalOutstanding: 'Total Tunggakan',
  totalPrincipal: 'Total Pokok',
  totalDisbursed: 'Total Dicairkan',
  totalCollections: 'Total Pendapatan',
  totalFees: 'Total Biaya',
  transactionNumber: 'No Transaksi',
  category: 'Kategori',
  amount: 'Jumlah',
  description: 'Keterangan',
  debitAccount: 'Akun Debit',
  creditAccount: 'Akun Kredit',
  referenceType: 'Tipe Referensi',
  referenceId: 'ID Referensi',
  userName: 'Pengguna',
};

interface ReportResponse {
  type: string;
  summary?: Record<string, unknown>;
  data?: Record<string, unknown>[];
  categoryBreakdown?: { category: string; count: number; totalAmount: number }[];
  statusBreakdown?: { status: string; count: number; outstanding: number; loanAmount: number }[];
}

export default function ReportsPage() {
  const { token } = useAuthStore();
  const { selectedBranch } = useAppStore();
  const [reportType, setReportType] = useState('loan-summary');
  const [dateFrom, setDateFrom] = useState(new Date().toISOString().split('T')[0]);
  const [dateTo, setDateTo] = useState(new Date().toISOString().split('T')[0]);
  const [branch, setBranch] = useState(selectedBranch);

  const { data, isLoading, error, refetch } = useQuery<ReportResponse>({
    queryKey: ['report', reportType, dateFrom, dateTo, branch],
    queryFn: async () => {
      const params = new URLSearchParams({ type: reportType });
      if (dateFrom) params.set('dateFrom', dateFrom);
      if (dateTo) params.set('dateTo', dateTo);
      if (branch !== 'all') params.set('branchId', branch);
      const r = await fetch(`/api/reports?${params}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!r.ok) {
        const d = await r.json();
        throw new Error(d.error || 'Gagal memuat laporan');
      }
      return r.json();
    },
    enabled: false,
  });

  const handleGenerate = () => {
    refetch();
  };

  const handleExport = () => {
    toast.info('Fitur export akan segera tersedia.');
  };

  const columns = useMemo(() => {
    if (!data?.data || data.data.length === 0) return [];
    return Object.keys(data.data[0]);
  }, [data]);

  const rows = data?.data || [];
  const summary = data?.summary || null;

  const formatCell = (value: unknown, col: string): string => {
    if (value === null || value === undefined) return '-';
    if (typeof value === 'number') {
      // Format currency fields
      const currencyFields = ['principalAmount', 'loanAmount', 'outstanding', 'totalPaid', 'principalPaid', 'serviceFeePaid', 'penaltyPaid', 'adminFeePaid', 'totalOutstanding', 'totalPrincipal', 'totalDisbursed', 'totalCollections', 'totalFees', 'serviceFeeDue', 'penaltyDue', 'totalPayable', 'amount', 'totalAmount'];
      if (currencyFields.includes(col)) return formatRupiah(value);
      return value.toLocaleString('id-ID');
    }
    if (typeof value === 'object') {
      // Handle nested objects like debitAccount, creditAccount
      const obj = value as Record<string, unknown>;
      if (obj.name) return String(obj.name);
      if (obj.code) return String(obj.code);
      return JSON.stringify(value);
    }
    if (typeof value === 'string' && (col.endsWith('Date') || col === 'createdAt' || col === 'loanDate' || col === 'dueDate')) {
      return formatDate(value);
    }
    return String(value);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold">Laporan</h1>
          <p className="text-sm text-muted-foreground">Generate dan lihat laporan operasional</p>
        </div>
        <Button variant="outline" onClick={handleExport}>
          <Download className="w-4 h-4 mr-2" />Export
        </Button>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Jenis Laporan</Label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {REPORT_TYPES.map((r) => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Dari Tanggal</Label>
              <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Sampai Tanggal</Label>
              <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">Cabang</Label>
              <Select value={branch} onValueChange={setBranch}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Semua Cabang</SelectItem>
                  <SelectItem value="branch-1">Cabang Pusat</SelectItem>
                  <SelectItem value="branch-2">Cabang Utara</SelectItem>
                  <SelectItem value="branch-3">Cabang Selatan</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="mt-4">
            <Button onClick={handleGenerate} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">
              <FileText className="w-4 h-4 mr-2" />Generate Laporan
            </Button>
          </div>
        </CardContent>
      </Card>

      {error && (
        <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{error.message}</AlertDescription></Alert>
      )}

      {/* Summary */}
      {summary && Object.keys(summary).length > 0 && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {Object.entries(summary).map(([key, value]) => (
            <Card key={key}>
              <CardContent className="p-4 text-center">
                <p className="text-xs text-muted-foreground">{COLUMN_LABELS[key] || key}</p>
                <p className="text-xl font-bold mt-1">
                  {typeof value === 'number' ? formatRupiah(value) : String(value)}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Status Breakdown (for loan-summary) */}
      {data?.statusBreakdown && data.statusBreakdown.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Status Breakdown</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Jumlah</TableHead>
                    <TableHead className="text-right">Tunggakan</TableHead>
                    <TableHead className="text-right">Jumlah Pinjaman</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.statusBreakdown.map((s) => (
                    <TableRow key={s.status}>
                      <TableCell><Badge variant="outline">{s.status}</Badge></TableCell>
                      <TableCell className="text-right">{s.count}</TableCell>
                      <TableCell className="text-right">{formatRupiah(s.outstanding)}</TableCell>
                      <TableCell className="text-right">{formatRupiah(s.loanAmount)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Category Breakdown (for cash-flow) */}
      {data?.categoryBreakdown && data.categoryBreakdown.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Breakdown per Kategori</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Kategori</TableHead>
                    <TableHead className="text-right">Jumlah Transaksi</TableHead>
                    <TableHead className="text-right">Total</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.categoryBreakdown.map((c) => (
                    <TableRow key={c.category}>
                      <TableCell><Badge variant="outline">{c.category}</Badge></TableCell>
                      <TableCell className="text-right">{c.count}</TableCell>
                      <TableCell className="text-right">{formatRupiah(c.totalAmount)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Report Table */}
      {rows.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              {REPORT_TYPES.find((r) => r.value === reportType)?.label} &mdash; {dateFrom && formatDate(dateFrom)} s/d {dateTo && formatDate(dateTo)}
            </CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            <div className="overflow-x-auto max-h-[500px] overflow-y-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[50px] sticky top-0 bg-background">No</TableHead>
                    {columns.map((col) => (
                      <TableHead key={col} className="sticky top-0 bg-background whitespace-nowrap">{COLUMN_LABELS[col] || col}</TableHead>
                    ))}
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((row, i) => (
                    <TableRow key={i}>
                      <TableCell className="text-muted-foreground">{i + 1}</TableCell>
                      {columns.map((col) => (
                        <TableCell key={col} className="whitespace-nowrap">
                          {formatCell(row[col], col)}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {data && rows.length === 0 && !error && (
        <Card><CardContent className="py-12 text-center text-muted-foreground">
          <FileText className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>Tidak ada data untuk laporan ini.</p>
        </CardContent></Card>
      )}

      {isLoading && (
        <Card><CardContent className="p-6 space-y-3">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</CardContent></Card>
      )}
    </div>
  );
}