'use client';

import { useEffect, useCallback, useMemo, Suspense } from 'react';
import { useAuthStore, useAppStore } from '@/stores/auth-store';
import { hasPermission } from '@/lib/auth';
import { useTheme } from 'next-themes';
import { toast } from 'sonner';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel,
} from '@/components/ui/dropdown-menu';
import {
  Breadcrumb, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbSeparator,
} from '@/components/ui/breadcrumb';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  LayoutDashboard, Users, Calculator, Banknote, CheckCircle, Wallet,
  Package, DollarSign, ClipboardCheck, Award, UserCog, Building2,
  FileText, Shield, Settings, Menu, ChevronLeft, ChevronRight,
  LogOut, Moon, Sun, User, KeyRound,
} from 'lucide-react';

import dynamic from 'next/dynamic';

const DashboardPage = dynamic(() => import('./dashboard-page'), { loading: () => <PageLoading /> });
const CustomersPage = dynamic(() => import('./customers-page'), { loading: () => <PageLoading /> });
const SimulationPage = dynamic(() => import('./simulation-page'), { loading: () => <PageLoading /> });
const LoansPage = dynamic(() => import('./loans-page'), { loading: () => <PageLoading /> });
const ApprovalsPage = dynamic(() => import('./approvals-page'), { loading: () => <PageLoading /> });
const CashPage = dynamic(() => import('./cash-page'), { loading: () => <PageLoading /> });
const MasterPage = dynamic(() => import('./master-page'), { loading: () => <PageLoading /> });
const UsersPage = dynamic(() => import('./users-page'), { loading: () => <PageLoading /> });
const BranchesPage = dynamic(() => import('./branches-page'), { loading: () => <PageLoading /> });
const ReportsPage = dynamic(() => import('./reports-page'), { loading: () => <PageLoading /> });
const ActivityLogsPage = dynamic(() => import('./activity-logs-page'), { loading: () => <PageLoading /> });
import SettingsPage from './settings-page';

function PageLoading() {
  return (
    <div className="flex items-center justify-center h-64">
      <div className="flex flex-col items-center gap-3">
        <div className="w-8 h-8 border-3 border-[#FBC02D] border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-muted-foreground">Memuat...</p>
      </div>
    </div>
  );
}

const PAGE_LABELS: Record<string, string> = {
  dashboard: 'Dashboard',
  customers: 'Nasabah',
  simulation: 'Simulasi Gadai',
  loans: 'Loan',
  approval: 'Approval',
  cash: 'Cash Management',
  master_items: 'Master Barang',
  master_prices: 'Master Harga',
  master_checklists: 'Master Checklist',
  master_grades: 'Master Grade',
  users: 'Pengguna',
  branches: 'Cabang',
  reports: 'Laporan',
  audit_log: 'Audit Log',
  settings: 'Pengaturan',
  monitoring: 'Monitoring',
};

interface NavItem {
  page: string;
  label: string;
  icon: React.ElementType;
  permission: string;
  section?: string;
}

const NAV_ITEMS: NavItem[] = [
  { page: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, permission: 'dashboard' },
  { page: 'customers', label: 'Nasabah', icon: Users, permission: 'customers' },
  { page: 'simulation', label: 'Simulasi Gadai', icon: Calculator, permission: 'simulation' },
  { page: 'loans', label: 'Loan', icon: Banknote, permission: 'loans' },
  { page: 'approval', label: 'Approval', icon: CheckCircle, permission: 'approval' },
  { page: 'cash', label: 'Cash Management', icon: Wallet, permission: 'cash' },
  { page: 'master_items', label: 'Master Barang', icon: Package, permission: 'master_items', section: 'master' },
  { page: 'master_prices', label: 'Master Harga', icon: DollarSign, permission: 'master_prices', section: 'master' },
  { page: 'master_checklists', label: 'Master Checklist', icon: ClipboardCheck, permission: 'master_checklists', section: 'master' },
  { page: 'master_grades', label: 'Master Grade', icon: Award, permission: 'master_grades', section: 'master' },
  { page: 'users', label: 'Pengguna', icon: UserCog, permission: 'users' },
  { page: 'branches', label: 'Cabang', icon: Building2, permission: 'branches' },
  { page: 'reports', label: 'Laporan', icon: FileText, permission: 'reports' },
  { page: 'audit_log', label: 'Audit Log', icon: Shield, permission: 'audit_log' },
  { page: 'settings', label: 'Pengaturan', icon: Settings, permission: 'settings' },
];

const MASTER_PAGES = ['master_items', 'master_prices', 'master_checklists', 'master_grades'];

function getPageComponent(page: string) {
  if (MASTER_PAGES.includes(page)) return <MasterPage initialTab={page} />;
  const map: Record<string, React.ReactNode> = {
    dashboard: <DashboardPage />,
    customers: <CustomersPage />,
    simulation: <SimulationPage />,
    loans: <LoansPage />,
    approval: <ApprovalsPage />,
    cash: <CashPage />,
    users: <UsersPage />,
    branches: <BranchesPage />,
    reports: <ReportsPage />,
    audit_log: <ActivityLogsPage />,
    settings: <SettingsPage />,
    monitoring: <DashboardPage />,
  };
  return map[page] || <DashboardPage />;
}

function SidebarContent({ collapsed, onNavigate }: { collapsed: boolean; onNavigate?: () => void }) {
  const { user } = useAuthStore();
  const { currentPage, setCurrentPage, toggleSidebar } = useAppStore();
  const { logout } = useAuthStore();
  const role = user?.role || '';

  const handleNav = (page: string) => {
    setCurrentPage(page);
    onNavigate?.();
  };

  const handleLogout = () => {
    logout();
    toast.info('Anda telah keluar dari sistem.');
  };

  const visibleNav = useMemo(() => {
    const items = NAV_ITEMS.filter((item) => hasPermission(role, item.permission));
    const result: { item: typeof items[0]; showSepBefore: boolean }[] = [];
    let lastSection = '';
    for (const item of items) {
      const showSep = item.section === 'master' && lastSection !== 'master';
      result.push({ item, showSepBefore: showSep });
      lastSection = item.section || '';
    }
    return result;
  }, [role]);

  return (
    <div className="flex flex-col h-full bg-[#212121] text-white">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-white/10 shrink-0">
        <div className="w-8 h-8 rounded-lg bg-[#FBC02D] flex items-center justify-center shrink-0">
          <Shield className="w-5 h-5 text-gray-900" />
        </div>
        {!collapsed && (
          <span className="text-lg font-bold tracking-tight text-[#FBC02D]">ADA GADAI</span>
        )}
      </div>

      {/* Navigation */}
      <ScrollArea className="flex-1 py-4">
        <nav className="space-y-1 px-2">
          {visibleNav.map(({ item, showSepBefore }) => (
              <div key={item.page}>
                {showSepBefore && <Separator className="my-3 bg-white/10" />}
                <button
                  onClick={() => handleNav(item.page)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group ${
                    currentPage === item.page
                      ? 'bg-white/10 text-[#FBC02D] border-l-[3px] border-[#FBC02D]'
                      : 'text-gray-300 hover:bg-white/5 hover:text-white border-l-[3px] border-transparent'
                  } ${collapsed ? 'justify-center' : ''}`}
                  title={collapsed ? item.label : undefined}
                >
                  <item.icon className={`w-5 h-5 shrink-0 ${currentPage === item.page ? 'text-[#FBC02D]' : 'text-gray-400 group-hover:text-white'}`} />
                  {!collapsed && <span>{item.label}</span>}
                </button>
              </div>
            ))}
        </nav>
      </ScrollArea>

      {/* User Info & Actions */}
      <div className="border-t border-white/10 p-3 shrink-0">
        {!collapsed && user && (
          <div className="flex items-center gap-3 px-2 mb-3">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-[#FBC02D] text-gray-900 text-xs font-bold">
                {user.name?.charAt(0).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{user.name}</p>
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0 bg-white/10 text-gray-300 hover:bg-white/10">
                {user.role}
              </Badge>
            </div>
          </div>
        )}

        <div className="flex items-center gap-1">
          {!collapsed && (
            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="flex-1 text-gray-400 hover:text-white hover:bg-white/5 justify-start gap-2 h-9 text-sm"
            >
              <LogOut className="w-4 h-4" />
              Keluar
            </Button>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleSidebar}
            className="text-gray-400 hover:text-white hover:bg-white/5 h-9 w-9 p-0"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </Button>
        </div>
      </div>
    </div>
  );
}

export default function AppShell() {
  const { user } = useAuthStore();
  const { currentPage, sidebarOpen, setSidebarOpen, selectedBranch, setSelectedBranch } = useAppStore();
  const { theme, setTheme } = useTheme();

  // DEBUG: log page changes
  useEffect(() => {
    document.title = `ADA GADAI - ${currentPage}`;
  }, [currentPage]);

  const handleMobileNav = useCallback(() => {
    setSidebarOpen(false);
  }, [setSidebarOpen]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 1024) {
        setSidebarOpen(false);
      }
    };
    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [setSidebarOpen]);

  const { logout } = useAuthStore();

  return (
    <div className="min-h-screen flex bg-[#F5F5F5] dark:bg-gray-950">
      {/* Desktop Sidebar */}
      <aside
        className={`hidden lg:block shrink-0 transition-all duration-300 ${
          sidebarOpen ? 'w-[260px]' : 'w-[68px]'
        }`}
      >
        <div className="fixed top-0 left-0 bottom-0 z-30" style={{ width: sidebarOpen ? 260 : 68 }}>
          <SidebarContent collapsed={!sidebarOpen} />
        </div>
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={false} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="p-0 w-[280px] bg-[#212121]">
          <SheetTitle className="sr-only">Menu Navigasi</SheetTitle>
          <SidebarContent collapsed={false} onNavigate={handleMobileNav} />
        </SheetContent>
      </Sheet>

      {/* Main Area */}
      <div className={`flex-1 flex flex-col min-h-screen transition-all duration-300 ${sidebarOpen ? 'lg:ml-[260px]' : 'lg:ml-[68px]'}`}>
        {/* Top Bar */}
        <header className="sticky top-0 z-20 bg-white dark:bg-gray-900 border-b border-gray-200 dark:border-gray-800 h-14 flex items-center px-4 gap-4 shrink-0">
          {/* Mobile hamburger */}
          <Button
            variant="ghost"
            size="sm"
            className="lg:hidden h-9 w-9 p-0"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>

          {/* Breadcrumb */}
          <Breadcrumb className="hidden sm:flex">
            <BreadcrumbList>
              <BreadcrumbItem>
                <BreadcrumbLink href="#" onClick={(e) => { e.preventDefault(); }} className="text-gray-400">
                  ADA GADAI
                </BreadcrumbLink>
              </BreadcrumbItem>
              <BreadcrumbSeparator />
              <BreadcrumbItem>
                <BreadcrumbPage>{PAGE_LABELS[currentPage] || currentPage}</BreadcrumbPage>
              </BreadcrumbItem>
            </BreadcrumbList>
          </Breadcrumb>
          <span className="sm:hidden text-sm font-medium">{PAGE_LABELS[currentPage] || currentPage}</span>

          <div className="flex-1" />

          {/* Branch Filter */}
          {user && (
            <Select value={selectedBranch} onValueChange={setSelectedBranch}>
              <SelectTrigger className="w-[160px] h-9 text-xs hidden md:flex">
                <Building2 className="w-3.5 h-3.5 mr-1.5" />
                <SelectValue placeholder="Semua Cabang" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Semua Cabang</SelectItem>
                <SelectItem value="branch-1">Cabang Pusat</SelectItem>
                <SelectItem value="branch-2">Cabang Utara</SelectItem>
                <SelectItem value="branch-3">Cabang Selatan</SelectItem>
              </SelectContent>
            </Select>
          )}

          {/* Dark mode toggle */}
          <Button
            variant="ghost"
            size="sm"
            className="h-9 w-9 p-0"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
          >
            <Sun className="h-4 w-4 rotate-0 scale-100 transition-all dark:-rotate-90 dark:scale-0" />
            <Moon className="absolute h-4 w-4 rotate-90 scale-0 transition-all dark:rotate-0 dark:scale-100" />
            <span className="sr-only">Toggle theme</span>
          </Button>

          {/* User Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="h-9 gap-2 px-2">
                <Avatar className="h-7 w-7">
                  <AvatarFallback className="bg-[#FBC02D] text-gray-900 text-xs font-bold">
                    {user?.name?.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <span className="hidden md:inline text-sm max-w-[120px] truncate">{user?.name}</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel>
                <div className="flex flex-col">
                  <span className="text-sm font-medium">{user?.name}</span>
                  <span className="text-xs text-muted-foreground">{user?.username} &middot; {user?.role}</span>
                </div>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" /> Profil
              </DropdownMenuItem>
              <DropdownMenuItem>
                <KeyRound className="mr-2 h-4 w-4" /> Ubah Password
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => {
                  logout();
                  toast.info('Anda telah keluar dari sistem.');
                }}
                className="text-red-600 focus:text-red-600"
              >
                <LogOut className="mr-2 h-4 w-4" /> Keluar
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-4 md:p-6">
          <div data-page={currentPage} className="hidden" />
          {currentPage === 'settings' ? <SettingsPage /> : getPageComponent(currentPage)}
        </main>

        {/* Footer */}
        <footer className="border-t border-gray-200 dark:border-gray-800 px-4 py-3 text-center text-xs text-muted-foreground bg-white dark:bg-gray-900 mt-auto">
          &copy; {new Date().getFullYear()} ADA GADAI &mdash; Sistem Manajemen Gadai Terpadu v1.0
        </footer>
      </div>
    </div>
  );
}