'use client';

import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAuthStore } from '@/stores/auth-store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription,
} from '@/components/ui/dialog';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Plus, Pencil, Trash2, Package, DollarSign, ClipboardCheck, Award, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { formatRupiah, formatDate, getGradeColor } from '@/lib/format';

interface ItemPrice { id: string; marketPrice: number; liquidationPercent: number; liquidationPrice: number; effectiveDate: string; }
interface MasterItem {
  id: string; name: string; brand: string | null; model: string | null;
  categoryId: string; category: { id: string; name: string };
  ram: string | null; storage: string | null; specs: string | null;
  isActive: boolean; prices: ItemPrice[];
}
interface MasterPrice {
  id: string; itemId: string;
  item: { id: string; name: string; brand: string | null; model: string | null; category: { name: string } } | null;
  marketPrice: number; liquidationPercent: number; liquidationPrice: number;
  effectiveDate: string; isActive: boolean;
}
interface MasterChecklist {
  id: string; name: string; category: { id: string; name: string };
  weight: number; type: string | null; grade: string | null;
  isActive: boolean;
}
interface MasterGrade {
  id: string; grade: string; factor: number; description: string | null;
  minScore: number; maxScore: number; sortOrder: number;
}
interface Category {
  id: string; name: string; description: string | null;
  icon: string | null; isActive: boolean; sortOrder: number;
}

const TAB_CONFIG = [
  { key: 'master_items', label: 'Barang', icon: Package },
  { key: 'master_prices', label: 'Harga', icon: DollarSign },
  { key: 'master_checklists', label: 'Checklist', icon: ClipboardCheck },
  { key: 'master_grades', label: 'Grade', icon: Award },
] as const;

export default function MasterPage({ initialTab = 'master_items' }: { initialTab?: string }) {
  const { token } = useAuthStore();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState(initialTab);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold">Master Data</h1>
        <p className="text-sm text-muted-foreground">Kelola data master sistem</p>
      </div>

      <Tabs value={tab} onValueChange={setTab}>
        <TabsList>
          {TAB_CONFIG.map((t) => (
            <TabsTrigger key={t.key} value={t.key} className="gap-1.5">
              <t.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{t.label}</span>
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="master_items" className="mt-4"><ItemsTab token={token} queryClient={queryClient} /></TabsContent>
        <TabsContent value="master_prices" className="mt-4"><PricesTab token={token} queryClient={queryClient} /></TabsContent>
        <TabsContent value="master_checklists" className="mt-4"><ChecklistsTab token={token} queryClient={queryClient} /></TabsContent>
        <TabsContent value="master_grades" className="mt-4"><GradesTab token={token} queryClient={queryClient} /></TabsContent>
      </Tabs>
    </div>
  );
}

/* ==================== ITEMS TAB ==================== */
function ItemsTab({ token, queryClient }: { token: string | null; queryClient: ReturnType<typeof useQueryClient> }) {
  const [formOpen, setFormOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selected, setSelected] = useState<MasterItem | null>(null);
  const [form, setForm] = useState({ name: '', categoryId: '', brand: '', model: '', ram: '', storage: '', specs: '' });

  const { data: categories } = useQuery<Category[]>({
    queryKey: ['categories'],
    queryFn: async () => {
      const r = await fetch('/api/master/categories', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
  });

  const { data: items, isLoading, error } = useQuery<MasterItem[]>({
    queryKey: ['master-items-all'],
    queryFn: async () => {
      const r = await fetch('/api/master/items?includePrices=true', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error('Gagal memuat data');
      const json = await r.json();
      return json.data || [];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const isEdit = !!selected?.id;
      const url = isEdit ? `/api/master/items/${selected!.id}` : '/api/master/items';
      const r = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          name: form.name,
          brand: form.brand || undefined,
          model: form.model || undefined,
          categoryId: form.categoryId,
          ram: form.ram || undefined,
          storage: form.storage || undefined,
          specs: form.specs || undefined,
        }),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal menyimpan'); }
      return r.json();
    },
    onSuccess: () => { toast.success(selected?.id ? 'Barang diperbarui' : 'Barang ditambahkan'); queryClient.invalidateQueries({ queryKey: ['master-items'] }); setFormOpen(false); setSelected(null); },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      const r = await fetch(`/api/master/items/${selected!.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) throw new Error('Gagal menghapus');
    },
    onSuccess: () => { toast.success('Barang dihapus'); queryClient.invalidateQueries({ queryKey: ['master-items'] }); setDeleteOpen(false); setSelected(null); },
    onError: (e: Error) => toast.error(e.message),
  });

  const openEdit = (item: MasterItem) => {
    setSelected(item);
    setForm({
      name: item.name,
      categoryId: item.categoryId,
      brand: item.brand || '',
      model: item.model || '',
      ram: item.ram || '',
      storage: item.storage || '',
      specs: item.specs || '',
    });
    setFormOpen(true);
  };
  const openAdd = () => {
    setSelected(null);
    setForm({ name: '', categoryId: '', brand: '', model: '', ram: '', storage: '', specs: '' });
    setFormOpen(true);
  };

  if (error) return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{(error as Error).message}</AlertDescription></Alert>;

  return (
    <>
      <div className="flex justify-end">
        <Button className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900" onClick={openAdd}><Plus className="w-4 h-4 mr-2" />Tambah Barang</Button>
      </div>
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="p-6 space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
            ) : (
              <Table>
                <TableHeader><TableRow><TableHead>Nama</TableHead><TableHead>Kategori</TableHead><TableHead>Harga Pasar</TableHead><TableHead>Status</TableHead><TableHead className="w-[100px]">Aksi</TableHead></TableRow></TableHeader>
                <TableBody>
                  {(!items || items.length === 0) ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Tidak ada data barang</TableCell></TableRow>
                  ) : items.map((item) => (
                    <TableRow key={item.id}>
                      <TableCell className="font-medium">{item.name}</TableCell>
                      <TableCell>{item.category?.name || item.categoryId}</TableCell>
                      <TableCell>{formatRupiah(item.prices?.[0]?.marketPrice || 0)}</TableCell>
                      <TableCell><Badge variant={item.isActive ? 'default' : 'secondary'} className={item.isActive ? 'bg-green-100 text-green-800' : ''}>{item.isActive ? 'Aktif' : 'Nonaktif'}</Badge></TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(item)}><Pencil className="w-4 h-4" /></Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 text-red-500" onClick={() => { setSelected(item); setDeleteOpen(true); }}><Trash2 className="w-4 h-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{selected?.id ? 'Edit' : 'Tambah'} Barang</DialogTitle><DialogDescription>Lengkapi data barang.</DialogDescription></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Nama *</Label><Input value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Kategori *</Label>
              <Select value={form.categoryId} onValueChange={(v) => setForm((p) => ({ ...p, categoryId: v }))}>
                <SelectTrigger><SelectValue placeholder="Pilih kategori" /></SelectTrigger>
                <SelectContent>{(categories || []).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Merek</Label><Input value={form.brand} onChange={(e) => setForm((p) => ({ ...p, brand: e.target.value }))} placeholder="e.g. Apple" /></div>
              <div className="space-y-2"><Label>Model</Label><Input value={form.model} onChange={(e) => setForm((p) => ({ ...p, model: e.target.value }))} placeholder="e.g. iPhone 15" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2"><Label>RAM</Label><Input value={form.ram} onChange={(e) => setForm((p) => ({ ...p, ram: e.target.value }))} placeholder="e.g. 8GB" /></div>
              <div className="space-y-2"><Label>Storage</Label><Input value={form.storage} onChange={(e) => setForm((p) => ({ ...p, storage: e.target.value }))} placeholder="e.g. 256GB" /></div>
            </div>
            <div className="space-y-2"><Label>Spesifikasi</Label><Input value={form.specs} onChange={(e) => setForm((p) => ({ ...p, specs: e.target.value }))} placeholder="Detail spesifikasi lainnya" /></div>
            <DialogFooter><Button variant="outline" onClick={() => setFormOpen(false)}>Batal</Button>
              <Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">{saveMutation.isPending ? 'Menyimpan...' : 'Simpan'}</Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Hapus Barang?</AlertDialogTitle><AlertDialogDescription>Data <strong>{selected?.name}</strong> akan dihapus.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Batal</AlertDialogCancel><AlertDialogAction onClick={() => deleteMutation.mutate()} className="bg-red-600 hover:bg-red-700">Hapus</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

/* ==================== PRICES TAB ==================== */
function PricesTab({ token, queryClient }: { token: string | null; queryClient: ReturnType<typeof useQueryClient> }) {
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState({ itemId: '', marketPrice: '', liquidationPercent: '70', effectiveDate: new Date().toISOString().split('T')[0] });

  // Fetch all items for the dropdown
  const { data: allItems } = useQuery<MasterItem[]>({
    queryKey: ['master-items-all'],
    queryFn: async () => {
      const r = await fetch('/api/master/items', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
  });

  const { data: prices, isLoading, error } = useQuery<MasterPrice[]>({
    queryKey: ['master-prices'],
    queryFn: async () => {
      const r = await fetch('/api/master/prices', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
  });

  const mutation = useMutation({
    mutationFn: async () => {
      const r = await fetch('/api/master/prices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          itemId: form.itemId,
          marketPrice: Number(form.marketPrice),
          liquidationPercent: Number(form.liquidationPercent),
          effectiveDate: form.effectiveDate,
        }),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal'); }
      return r.json();
    },
    onSuccess: () => { toast.success('Harga ditambahkan'); queryClient.invalidateQueries({ queryKey: ['master-prices'] }); setFormOpen(false); setForm({ itemId: '', marketPrice: '', liquidationPercent: '70', effectiveDate: new Date().toISOString().split('T')[0] }); },
    onError: (e: Error) => toast.error(e.message),
  });

  if (error) return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{(error as Error).message}</AlertDescription></Alert>;

  return (
    <>
      <div className="flex justify-end"><Button className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900" onClick={() => setFormOpen(true)}><Plus className="w-4 h-4 mr-2" />Update Harga</Button></div>
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="p-6 space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
            ) : (
              <Table>
                <TableHeader><TableRow><TableHead>Barang</TableHead><TableHead>Kategori</TableHead><TableHead>Harga Pasar</TableHead><TableHead>Tgl Efektif</TableHead></TableRow></TableHeader>
                <TableBody>
                  {(!prices || prices.length === 0) ? (
                    <TableRow><TableCell colSpan={4} className="text-center py-8 text-muted-foreground">Tidak ada data harga</TableCell></TableRow>
                  ) : prices.map((p) => (
                    <TableRow key={p.id}>
                      <TableCell className="font-medium">{p.item?.name || p.itemId}</TableCell>
                      <TableCell>{p.item?.category?.name || '-'}</TableCell>
                      <TableCell className="font-medium">{formatRupiah(p.marketPrice)}</TableCell>
                      <TableCell className="text-sm text-muted-foreground">{formatDate(p.effectiveDate)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Update Harga Pasar</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Barang *</Label>
              <Select value={form.itemId} onValueChange={(v) => setForm((p) => ({ ...p, itemId: v }))}>
                <SelectTrigger><SelectValue placeholder="Pilih barang" /></SelectTrigger>
                <SelectContent className="max-h-60">
                  {(allItems || []).map((item) => (
                    <SelectItem key={item.id} value={item.id}>{item.name}{item.brand ? ` ${item.brand}` : ''}{item.model ? ` ${item.model}` : ''}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>Harga Pasar (Rp) *</Label><Input type="number" value={form.marketPrice} onChange={(e) => setForm((p) => ({ ...p, marketPrice: e.target.value }))} /></div>
            <div className="space-y-2"><Label>% Likuidasi</Label><Input type="number" min={0} max={100} value={form.liquidationPercent} onChange={(e) => setForm((p) => ({ ...p, liquidationPercent: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Tanggal Efektif</Label><Input type="date" value={form.effectiveDate} onChange={(e) => setForm((p) => ({ ...p, effectiveDate: e.target.value }))} /></div>
            <DialogFooter><Button variant="outline" onClick={() => setFormOpen(false)}>Batal</Button><Button onClick={() => mutation.mutate()} disabled={mutation.isPending} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">{mutation.isPending ? 'Menyimpan...' : 'Simpan'}</Button></DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}

/* ==================== CHECKLISTS TAB ==================== */
function ChecklistsTab({ token, queryClient }: { token: string | null; queryClient: ReturnType<typeof useQueryClient> }) {
  const [formOpen, setFormOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selected, setSelected] = useState<MasterChecklist | null>(null);
  const [form, setForm] = useState({ name: '', categoryId: '', weight: '', type: '', grade: '' });

  const { data: categories } = useQuery<Category[]>({
    queryKey: ['categories'],
    queryFn: async () => {
      const r = await fetch('/api/master/categories', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
  });

  const { data: checklists, isLoading, error } = useQuery<MasterChecklist[]>({
    queryKey: ['master-checklists'],
    queryFn: async () => {
      const r = await fetch('/api/master/checklists', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const isEdit = !!selected?.id;
      const url = isEdit ? `/api/master/checklists/${selected!.id}` : '/api/master/checklists';
      const r = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          name: form.name,
          categoryId: form.categoryId,
          weight: Number(form.weight) || 1,
          type: form.type || undefined,
          grade: form.grade || undefined,
        }),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal'); }
      return r.json();
    },
    onSuccess: () => { toast.success(selected?.id ? 'Checklist diperbarui' : 'Checklist ditambahkan'); queryClient.invalidateQueries({ queryKey: ['master-checklists'] }); setFormOpen(false); setSelected(null); },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async () => { const r = await fetch(`/api/master/checklists/${selected!.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } }); if (!r.ok) throw new Error('Gagal'); },
    onSuccess: () => { toast.success('Checklist dihapus'); queryClient.invalidateQueries({ queryKey: ['master-checklists'] }); setDeleteOpen(false); setSelected(null); },
    onError: (e: Error) => toast.error(e.message),
  });

  const openEdit = (c: MasterChecklist) => {
    setSelected(c);
    setForm({
      name: c.name,
      categoryId: c.category?.id || '',
      weight: String(c.weight),
      type: c.type || '',
      grade: c.grade || '',
    });
    setFormOpen(true);
  };
  const openAdd = () => {
    setSelected(null);
    setForm({ name: '', categoryId: '', weight: '', type: '', grade: '' });
    setFormOpen(true);
  };

  if (error) return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{(error as Error).message}</AlertDescription></Alert>;

  return (
    <>
      <div className="flex justify-end"><Button className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900" onClick={openAdd}><Plus className="w-4 h-4 mr-2" />Tambah Checklist</Button></div>
      <Card>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="p-6 space-y-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
            ) : (
              <Table>
                <TableHeader><TableRow><TableHead>Nama</TableHead><TableHead>Kategori</TableHead><TableHead>Bobot</TableHead><TableHead>Status</TableHead><TableHead className="w-[100px]">Aksi</TableHead></TableRow></TableHeader>
                <TableBody>
                  {(!checklists || checklists.length === 0) ? (
                    <TableRow><TableCell colSpan={5} className="text-center py-8 text-muted-foreground">Tidak ada checklist</TableCell></TableRow>
                  ) : checklists.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-medium">{c.name}</TableCell>
                      <TableCell>{c.category?.name || '-'}</TableCell>
                      <TableCell>{c.weight}</TableCell>
                      <TableCell><Badge variant={c.isActive ? 'default' : 'secondary'} className={c.isActive ? 'bg-green-100 text-green-800' : ''}>{c.isActive ? 'Aktif' : 'Nonaktif'}</Badge></TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => openEdit(c)}><Pencil className="w-4 h-4" /></Button>
                          <Button size="icon" variant="ghost" className="h-8 w-8 text-red-500" onClick={() => { setSelected(c); setDeleteOpen(true); }}><Trash2 className="w-4 h-4" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </div>
        </CardContent>
      </Card>

      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{selected?.id ? 'Edit' : 'Tambah'} Checklist</DialogTitle><DialogDescription>Lengkapi data checklist.</DialogDescription></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Nama *</Label><Input value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} /></div>
            <div className="space-y-2"><Label>Kategori *</Label>
              <Select value={form.categoryId} onValueChange={(v) => setForm((p) => ({ ...p, categoryId: v }))}>
                <SelectTrigger><SelectValue placeholder="Pilih kategori" /></SelectTrigger>
                <SelectContent>{(categories || []).map((c) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Bobot</Label><Input type="number" value={form.weight} onChange={(e) => setForm((p) => ({ ...p, weight: e.target.value }))} /></div>
              <div className="space-y-2"><Label>Tipe</Label><Input value={form.type} onChange={(e) => setForm((p) => ({ ...p, type: e.target.value }))} placeholder="e.g. VISUAL, FUNGSIONAL" /></div>
            </div>
            <div className="space-y-2"><Label>Grade</Label><Input value={form.grade} onChange={(e) => setForm((p) => ({ ...p, grade: e.target.value }))} placeholder="e.g. A, B, C" /></div>
            <DialogFooter><Button variant="outline" onClick={() => setFormOpen(false)}>Batal</Button><Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">{saveMutation.isPending ? 'Menyimpan...' : 'Simpan'}</Button></DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Hapus Checklist?</AlertDialogTitle><AlertDialogDescription>Checklist <strong>{selected?.name}</strong> akan dihapus.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Batal</AlertDialogCancel><AlertDialogAction onClick={() => deleteMutation.mutate()} className="bg-red-600 hover:bg-red-700">Hapus</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

/* ==================== GRADES TAB ==================== */
function GradesTab({ token, queryClient }: { token: string | null; queryClient: ReturnType<typeof useQueryClient> }) {
  const [formOpen, setFormOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [selected, setSelected] = useState<MasterGrade | null>(null);
  const [form, setForm] = useState({ grade: '', factor: '', description: '', minScore: '', maxScore: '', sortOrder: '' });

  const { data: grades, isLoading, error } = useQuery<MasterGrade[]>({
    queryKey: ['master-grades'],
    queryFn: async () => {
      const r = await fetch('/api/master/grades', { headers: { Authorization: `Bearer ${token}` } });
      if (!r.ok) return [];
      const json = await r.json();
      return json.data || [];
    },
  });

  const saveMutation = useMutation({
    mutationFn: async () => {
      const isEdit = !!selected?.id;
      const url = isEdit ? `/api/master/grades/${selected!.id}` : '/api/master/grades';
      const r = await fetch(url, {
        method: isEdit ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
        body: JSON.stringify({
          grade: form.grade,
          factor: Number(form.factor) || 100,
          description: form.description || undefined,
          minScore: Number(form.minScore) || 0,
          maxScore: Number(form.maxScore) || 100,
          sortOrder: Number(form.sortOrder) || 0,
        }),
      });
      if (!r.ok) { const d = await r.json(); throw new Error(d.error || 'Gagal'); }
      return r.json();
    },
    onSuccess: () => { toast.success(selected?.id ? 'Grade diperbarui' : 'Grade ditambahkan'); queryClient.invalidateQueries({ queryKey: ['master-grades'] }); setFormOpen(false); setSelected(null); },
    onError: (e: Error) => toast.error(e.message),
  });

  const deleteMutation = useMutation({
    mutationFn: async () => { const r = await fetch(`/api/master/grades/${selected!.id}`, { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } }); if (!r.ok) throw new Error('Gagal'); },
    onSuccess: () => { toast.success('Grade dihapus'); queryClient.invalidateQueries({ queryKey: ['master-grades'] }); setDeleteOpen(false); setSelected(null); },
    onError: (e: Error) => toast.error(e.message),
  });

  const openEdit = (g: MasterGrade) => {
    setSelected(g);
    setForm({
      grade: g.grade,
      factor: String(g.factor),
      description: g.description || '',
      minScore: String(g.minScore),
      maxScore: String(g.maxScore),
      sortOrder: String(g.sortOrder),
    });
    setFormOpen(true);
  };
  const openAdd = () => {
    setSelected(null);
    setForm({ grade: '', factor: '', description: '', minScore: '', maxScore: '', sortOrder: '' });
    setFormOpen(true);
  };

  if (error) return <Alert variant="destructive"><AlertCircle className="h-4 w-4" /><AlertDescription>{(error as Error).message}</AlertDescription></Alert>;

  return (
    <>
      <div className="flex justify-end"><Button className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900" onClick={openAdd}><Plus className="w-4 h-4 mr-2" />Tambah Grade</Button></div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          Array.from({ length: 6 }).map((_, i) => <Card key={i}><CardContent className="p-4"><Skeleton className="h-20 w-full" /></CardContent></Card>)
        ) : (!grades || grades.length === 0) ? (
          <Card className="sm:col-span-2 lg:col-span-3"><CardContent className="py-12 text-center text-muted-foreground">Tidak ada grade</CardContent></Card>
        ) : grades.map((g) => (
          <Card key={g.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Badge className={getGradeColor(g.grade)}>{g.grade}</Badge>
                  <span className="font-semibold">{g.description || g.grade}</span>
                </div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => openEdit(g)}><Pencil className="w-3.5 h-3.5" /></Button>
                  <Button size="icon" variant="ghost" className="h-7 w-7 text-red-500" onClick={() => { setSelected(g); setDeleteOpen(true); }}><Trash2 className="w-3.5 h-3.5" /></Button>
                </div>
              </div>
              <p className="text-sm text-muted-foreground">Skor: {g.minScore} - {g.maxScore}</p>
              <p className="text-sm mt-1">Faktor: <strong>{g.factor}x</strong></p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{selected?.id ? 'Edit' : 'Tambah'} Grade</DialogTitle><DialogDescription>Lengkapi data grade.</DialogDescription></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2"><Label>Kode Grade *</Label><Input value={form.grade} onChange={(e) => setForm((p) => ({ ...p, grade: e.target.value }))} placeholder="e.g. A+" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Faktor *</Label><Input type="number" step="1" value={form.factor} onChange={(e) => setForm((p) => ({ ...p, factor: e.target.value }))} /></div>
              <div className="space-y-2"><Label>Urutan</Label><Input type="number" value={form.sortOrder} onChange={(e) => setForm((p) => ({ ...p, sortOrder: e.target.value }))} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2"><Label>Skor Min</Label><Input type="number" value={form.minScore} onChange={(e) => setForm((p) => ({ ...p, minScore: e.target.value }))} /></div>
              <div className="space-y-2"><Label>Skor Max</Label><Input type="number" value={form.maxScore} onChange={(e) => setForm((p) => ({ ...p, maxScore: e.target.value }))} /></div>
            </div>
            <div className="space-y-2"><Label>Deskripsi</Label><Input value={form.description} onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))} /></div>
            <DialogFooter><Button variant="outline" onClick={() => setFormOpen(false)}>Batal</Button><Button onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending} className="bg-[#FBC02D] hover:bg-[#F9A825] text-gray-900">{saveMutation.isPending ? 'Menyimpan...' : 'Simpan'}</Button></DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader><AlertDialogTitle>Hapus Grade?</AlertDialogTitle><AlertDialogDescription>Grade <strong>{selected?.grade}</strong> akan dihapus.</AlertDialogDescription></AlertDialogHeader>
          <AlertDialogFooter><AlertDialogCancel>Batal</AlertDialogCancel><AlertDialogAction onClick={() => deleteMutation.mutate()} className="bg-red-600 hover:bg-red-700">Hapus</AlertDialogAction></AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}