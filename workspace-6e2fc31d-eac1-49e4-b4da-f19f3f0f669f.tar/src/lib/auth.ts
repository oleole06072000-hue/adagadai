import { SignJWT, jwtVerify } from 'jose';
import bcrypt from 'bcryptjs';

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || 'ada-gadai-secret-key-2024-change-in-production');

export interface JWTPayload {
  userId: string;
  username: string;
  role: string;
  branchId: string | null;
  name: string;
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export async function createToken(payload: JWTPayload): Promise<string> {
  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('8h')
    .sign(JWT_SECRET);
}

export async function verifyToken(token: string): Promise<JWTPayload | null> {
  try {
    const { payload } = await jwtVerify(token, JWT_SECRET);
    return payload as unknown as JWTPayload;
  } catch {
    return null;
  }
}

export function getRolePermissions(role: string): string[] {
  const permissions: Record<string, string[]> = {
    ADMIN: [
      'dashboard', 'customers', 'simulation', 'approval', 'loans', 'cash',
      'master_items', 'master_prices', 'master_checklists', 'master_grades',
      'users', 'branches', 'settings', 'reports', 'audit_log',
      'approval_action', 'export', 'backup', 'system_settings'
    ],
    SURVEYOR: [
      'dashboard', 'simulation', 'loans', 'cash', 'reports',
      'input_data', 'upload_photo', 'assessment'
    ],
    KEPALA_CABANG: [
      'dashboard', 'approval', 'loans', 'cash', 'reports', 'monitoring',
      'approval_action', 'export_branch', 'branch_monitoring'
    ],
  };
  return permissions[role] || [];
}

export function hasPermission(role: string, permission: string): boolean {
  return getRolePermissions(role).includes(permission);
}