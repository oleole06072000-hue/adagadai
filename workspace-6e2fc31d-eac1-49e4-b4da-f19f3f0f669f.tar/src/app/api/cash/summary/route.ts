import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const branchId = sp.get('branchId');

    const where: any = {};
    if (branchId) {
      where.branchId = branchId;
    } else if (payload.branchId && payload.role !== 'ADMIN') {
      where.branchId = payload.branchId;
    }

    // Get all active accounts with balances
    const accounts = await db.account.findMany({
      where: { ...where, isActive: true },
      include: {
        branch: { select: { id: true, code: true, name: true } },
      },
    });

    // Get today's transactions
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);

    const [todayDebit, todayCredit] = await Promise.all([
      db.cashTransaction.aggregate({
        where: {
          ...where,
          createdAt: { gte: today, lt: tomorrow },
        },
        _sum: { amount: true },
      }),
      db.cashTransaction.aggregate({
        where: {
          ...where,
          createdAt: { gte: today, lt: tomorrow },
          type: 'WITHDRAWAL',
        },
        _sum: { amount: true },
      }),
    ]);

    // Get month totals
    const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);

    const [monthDisbursements, monthCollections] = await Promise.all([
      db.cashTransaction.aggregate({
        where: {
          ...where,
          category: 'DISBURSEMENT',
          createdAt: { gte: monthStart },
        },
        _sum: { amount: true },
      }),
      db.cashTransaction.aggregate({
        where: {
          ...where,
          category: 'COLLECTION',
          createdAt: { gte: monthStart },
        },
        _sum: { amount: true },
      }),
    ]);

    const totalBalance = accounts.reduce((sum, a) => sum + Number(a.currentBalance), 0);

    return NextResponse.json({
      totalBalance,
      todayInflow: Number(todayDebit._sum.amount || 0),
      todayOutflow: Number(todayCredit._sum.amount || 0),
      monthDisbursements: Number(monthDisbursements._sum.amount || 0),
      monthCollections: Number(monthCollections._sum.amount || 0),
      accounts: accounts.map((a) => ({
        id: a.id,
        code: a.code,
        name: a.name,
        type: a.type,
        currentBalance: Number(a.currentBalance),
        branch: a.branch,
      })),
    });
  } catch (error) {
    console.error('Get cash summary error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}