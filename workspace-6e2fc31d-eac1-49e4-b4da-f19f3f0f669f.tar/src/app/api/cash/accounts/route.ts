import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const type = sp.get('type');
    const isActive = sp.get('isActive');
    const branchId = sp.get('branchId');
    const search = sp.get('search');

    const where: Prisma.AccountWhereInput = {};

    if (type) {
      where.type = type;
    }
    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }
    if (branchId) {
      where.branchId = branchId;
    } else if (payload.branchId && payload.role !== 'ADMIN') {
      where.branchId = payload.branchId;
    }
    if (search) {
      where.OR = [
        { code: { contains: search } },
        { name: { contains: search } },
      ];
    }

    const accounts = await db.account.findMany({
      where,
      include: {
        branch: { select: { id: true, code: true, name: true } },
        _count: { select: { debitTransactions: true, creditTransactions: true, payments: true } },
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      data: accounts.map((a) => ({
        ...a,
        initialBalance: Number(a.initialBalance),
        currentBalance: Number(a.currentBalance),
        createdAt: a.createdAt.toISOString(),
        updatedAt: a.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get accounts error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();
    const { code, name, type, bankName, bankAccount, initialBalance, branchId } = body;

    if (!code || !name) {
      return NextResponse.json({ error: 'Kode dan nama wajib diisi' }, { status: 400 });
    }

    const existing = await db.account.findUnique({ where: { code } });
    if (existing) {
      return NextResponse.json({ error: 'Kode akun sudah digunakan' }, { status: 400 });
    }

    const account = await db.account.create({
      data: {
        code,
        name,
        type: type || 'CASH',
        bankName,
        bankAccount,
        initialBalance: initialBalance || 0,
        currentBalance: initialBalance || 0,
        branchId: branchId || payload.branchId || null,
      },
      include: { branch: true },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'CASH_ACCOUNT',
        description: `Membuat akun kas: ${code} - ${name}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...account,
      initialBalance: Number(account.initialBalance),
      currentBalance: Number(account.currentBalance),
      createdAt: account.createdAt.toISOString(),
      updatedAt: account.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create account error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}