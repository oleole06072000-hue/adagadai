import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { Prisma } from '@prisma/client';

function generateTransactionNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `CT-${y}${m}${d}-${rand}`;
}

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const type = sp.get('type');
    const category = sp.get('category');
    const accountId = sp.get('accountId');
    const referenceType = sp.get('referenceType');
    const referenceId = sp.get('referenceId');
    const dateFrom = sp.get('dateFrom');
    const dateTo = sp.get('dateTo');
    const page = sp.get('page') || '1';
    const limit = sp.get('limit') || '20';
    const search = sp.get('search');

    const where: Prisma.CashTransactionWhereInput = {};

    if (type) {
      where.type = type;
    }
    if (category) {
      where.category = category;
    }
    if (accountId) {
      where.OR = [
        { debitAccountId: accountId },
        { creditAccountId: accountId },
      ];
    }
    if (referenceType) {
      where.referenceType = referenceType;
    }
    if (referenceId) {
      where.referenceId = referenceId;
    }
    if (dateFrom || dateTo) {
      where.createdAt = {};
      if (dateFrom) where.createdAt.gte = new Date(dateFrom);
      if (dateTo) where.createdAt.lte = new Date(dateTo);
    }
    if (search) {
      where.OR = [
        { transactionNumber: { contains: search } },
        { description: { contains: search } },
      ];
    }

    // Branch filter
    if (payload.branchId && payload.role !== 'ADMIN') {
      where.branchId = payload.branchId;
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const [transactions, total] = await Promise.all([
      db.cashTransaction.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, username: true } },
          debitAccount: { select: { id: true, code: true, name: true } },
          creditAccount: { select: { id: true, code: true, name: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
      }),
      db.cashTransaction.count({ where }),
    ]);

    return NextResponse.json({
      data: transactions.map((t) => ({
        ...t,
        amount: Number(t.amount),
        createdAt: t.createdAt.toISOString(),
        updatedAt: t.updatedAt.toISOString(),
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    console.error('Get transactions error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();
    const {
      type, category, amount, description,
      debitAccountId, creditAccountId,
      referenceType, referenceId,
    } = body;

    if (!type || !category || !amount) {
      return NextResponse.json({ error: 'Tipe, kategori, dan jumlah wajib diisi' }, { status: 400 });
    }

    const transactionNumber = generateTransactionNumber();

    // Create transaction with double entry
    const transaction = await db.$transaction(async (tx) => {
      const txn = await tx.cashTransaction.create({
        data: {
          transactionNumber,
          type,
          category,
          amount,
          description,
          debitAccountId,
          creditAccountId,
          referenceType,
          referenceId,
          userId: payload.userId,
          branchId: payload.branchId || null,
        },
        include: {
          user: { select: { id: true, name: true } },
          debitAccount: true,
          creditAccount: true,
        },
      });

      // Update account balances
      if (debitAccountId) {
        await tx.account.update({
          where: { id: debitAccountId },
          data: { currentBalance: { increment: amount } },
        });
      }

      if (creditAccountId) {
        await tx.account.update({
          where: { id: creditAccountId },
          data: { currentBalance: { decrement: amount } },
        });
      }

      return txn;
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'CASH_TRANSACTION',
        description: `Transaksi kas ${type}: ${transactionNumber} - Rp ${Number(amount).toLocaleString('id-ID')}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...transaction,
      amount: Number(transaction.amount),
      createdAt: transaction.createdAt.toISOString(),
      updatedAt: transaction.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create transaction error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}