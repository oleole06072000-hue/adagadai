import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const type = sp.get('type');
    const branchId = sp.get('branchId');
    const dateFrom = sp.get('dateFrom');
    const dateTo = sp.get('dateTo');

    const branchFilter = payload.branchId && payload.role !== 'ADMIN'
      ? payload.branchId
      : branchId;

    switch (type) {
      case 'loan-summary': {
        const where: any = {};
        if (branchFilter) where.branchId = branchFilter;
        if (dateFrom || dateTo) {
          where.loanDate = {};
          if (dateFrom) where.loanDate.gte = new Date(dateFrom);
          if (dateTo) where.loanDate.lte = new Date(dateTo);
        }

        const [loans, stats] = await Promise.all([
          db.loan.findMany({
            where,
            include: {
              customer: { select: { name: true, nik: true } },
              branch: { select: { name: true } },
              assessment: { select: { itemName: true, grade: true } },
            },
            orderBy: { loanDate: 'desc' },
            take: 500,
          }),
          db.loan.aggregate({
            where,
            _sum: {
              principalAmount: true,
              loanAmount: true,
              outstanding: true,
              adminFee: true,
              serviceFee: true,
              penaltyFee: true,
            },
            _count: true,
          }),
        ]);

        const statusBreakdown = await db.loan.groupBy({
          by: ['status'],
          where,
          _count: true,
          _sum: { outstanding: true, loanAmount: true },
        });

        return NextResponse.json({
          type: 'loan-summary',
          summary: {
            totalLoans: stats._count,
            totalPrincipal: Number(stats._sum.principalAmount || 0),
            totalLoanAmount: Number(stats._sum.loanAmount || 0),
            totalOutstanding: Number(stats._sum.outstanding || 0),
            totalAdminFee: Number(stats._sum.adminFee || 0),
            totalServiceFee: Number(stats._sum.serviceFee || 0),
            totalPenaltyFee: Number(stats._sum.penaltyFee || 0),
          },
          statusBreakdown: statusBreakdown.map((s) => ({
            status: s.status,
            count: s._count,
            outstanding: Number(s._sum.outstanding || 0),
            loanAmount: Number(s._sum.loanAmount || 0),
          })),
          data: loans.map((l) => ({
            id: l.id,
            loanNumber: l.loanNumber,
            customerName: l.customer?.name,
            customerNik: l.customer?.nik,
            branchName: l.branch?.name,
            itemName: l.assessment?.itemName,
            grade: l.assessment?.grade,
            principalAmount: Number(l.principalAmount),
            loanAmount: Number(l.loanAmount),
            outstanding: Number(l.outstanding),
            status: l.status,
            loanDate: l.loanDate.toISOString(),
            dueDate: l.dueDate.toISOString(),
          })),
        });
      }

      case 'payment-summary': {
        const where: any = {};
        if (dateFrom || dateTo) {
          where.createdAt = {};
          if (dateFrom) where.createdAt.gte = new Date(dateFrom);
          if (dateTo) where.createdAt.lte = new Date(dateTo);
        }

        const [payments, stats] = await Promise.all([
          db.payment.findMany({
            where,
            include: {
              loan: {
                select: {
                  loanNumber: true,
                  customer: { select: { name: true, customerNumber: true } },
                  branch: { select: { name: true } },
                },
              },
              receivedBy: { select: { name: true } },
            },
            orderBy: { createdAt: 'desc' },
            take: 500,
          }),
          db.payment.aggregate({
            where,
            _sum: {
              principalPaid: true,
              serviceFeePaid: true,
              penaltyPaid: true,
              adminFeePaid: true,
              totalPaid: true,
            },
            _count: true,
          }),
        ]);

        return NextResponse.json({
          type: 'payment-summary',
          summary: {
            totalPayments: stats._count,
            totalPrincipalPaid: Number(stats._sum.principalPaid || 0),
            totalServiceFeePaid: Number(stats._sum.serviceFeePaid || 0),
            totalPenaltyPaid: Number(stats._sum.penaltyPaid || 0),
            totalAdminFeePaid: Number(stats._sum.adminFeePaid || 0),
            totalPaid: Number(stats._sum.totalPaid || 0),
          },
          data: payments.map((p) => ({
            id: p.id,
            paymentNumber: p.paymentNumber,
            loanNumber: p.loan?.loanNumber,
            customerName: p.loan?.customer?.name,
            branchName: p.loan?.branch?.name,
            type: p.type,
            principalPaid: Number(p.principalPaid),
            serviceFeePaid: Number(p.serviceFeePaid),
            penaltyPaid: Number(p.penaltyPaid),
            adminFeePaid: Number(p.adminFeePaid),
            totalPaid: Number(p.totalPaid),
            paymentMethod: p.paymentMethod,
            receivedBy: p.receivedBy?.name,
            createdAt: p.createdAt.toISOString(),
          })),
        });
      }

      case 'overdue-report': {
        const now = new Date();
        const where: any = {
          status: 'OVERDUE',
          dueDate: { lt: now },
        };
        if (branchFilter) where.branchId = branchFilter;

        const loans = await db.loan.findMany({
          where,
          include: {
            customer: { select: { name: true, nik: true, phone: true } },
            branch: { select: { name: true } },
            assessment: { select: { itemName: true, grade: true } },
            surveyor: { select: { name: true } },
            _count: { select: { payments: true } },
          },
          orderBy: { dueDate: 'asc' },
        });

        const enrichedLoans = loans.map((l) => {
          const daysOverdue = Math.max(0, Math.floor((now.getTime() - l.dueDate.getTime()) / (1000 * 60 * 60 * 24)));
          const monthsOverdue = Math.ceil(daysOverdue / 30);
          const outstanding = Number(l.outstanding);
          const serviceFeeCalc = outstanding * 0.01 * monthsOverdue;
          const penaltyCalc = daysOverdue * 5000;

          return {
            id: l.id,
            loanNumber: l.loanNumber,
            customerName: l.customer?.name,
            customerNik: l.customer?.nik,
            customerPhone: l.customer?.phone,
            branchName: l.branch?.name,
            itemName: l.assessment?.itemName,
            grade: l.assessment?.grade,
            outstanding,
            daysOverdue,
            monthsOverdue,
            serviceFeeDue: serviceFeeCalc,
            penaltyDue: penaltyCalc,
            totalPayable: outstanding + serviceFeeCalc + penaltyCalc,
            dueDate: l.dueDate.toISOString(),
            surveyorName: l.surveyor?.name,
            totalPayments: l._count.payments,
          };
        });

        const totalOverdue = enrichedLoans.reduce((sum, l) => sum + l.outstanding, 0);
        const totalPenalty = enrichedLoans.reduce((sum, l) => sum + l.penaltyDue, 0);

        return NextResponse.json({
          type: 'overdue-report',
          summary: {
            totalOverdueLoans: enrichedLoans.length,
            totalOutstanding: totalOverdue,
            totalPenaltyDue: totalPenalty,
            totalPayable: totalOverdue + totalPenalty,
          },
          data: enrichedLoans,
        });
      }

      case 'branch-summary': {
        const branches = await db.branch.findMany({
          where: { isActive: true },
          include: {
            _count: {
              select: {
                users: true,
                customers: true,
                loans: { where: { status: { in: ['ACTIVE', 'OVERDUE'] } } },
              },
            },
          },
          orderBy: { code: 'asc' },
        });

        const branchStats = await Promise.all(
          branches.map(async (b) => {
            const loanStats = await db.loan.aggregate({
              where: { branchId: b.id, status: { in: ['ACTIVE', 'OVERDUE'] } },
              _sum: { outstanding: true, principalAmount: true, loanAmount: true },
            });

            const paymentStats = await db.payment.aggregate({
              where: {
                loan: { branchId: b.id },
                createdAt: dateFrom
                  ? { gte: new Date(dateFrom) }
                  : undefined,
              },
              _sum: { totalPaid: true, serviceFeePaid: true, penaltyPaid: true },
            });

            return {
              id: b.id,
              code: b.code,
              name: b.name,
              area: b.area,
              regional: b.regional,
              totalUsers: b._count.users,
              totalCustomers: b._count.customers,
              activeLoans: b._count.loans,
              totalOutstanding: Number(loanStats._sum.outstanding || 0),
              totalPrincipal: Number(loanStats._sum.principalAmount || 0),
              totalDisbursed: Number(loanStats._sum.loanAmount || 0),
              totalCollections: Number(paymentStats._sum.totalPaid || 0),
              totalFees: Number(paymentStats._sum.serviceFeePaid || 0) + Number(paymentStats._sum.penaltyPaid || 0),
            };
          })
        );

        return NextResponse.json({
          type: 'branch-summary',
          summary: {
            totalBranches: branchStats.length,
            totalUsers: branchStats.reduce((s, b) => s + b.totalUsers, 0),
            totalCustomers: branchStats.reduce((s, b) => s + b.totalCustomers, 0),
            activeLoans: branchStats.reduce((s, b) => s + b.activeLoans, 0),
            totalOutstanding: branchStats.reduce((s, b) => s + b.totalOutstanding, 0),
            totalCollections: branchStats.reduce((s, b) => s + b.totalCollections, 0),
          },
          data: branchStats,
        });
      }

      case 'cash-flow': {
        const where: any = {};
        if (branchFilter) where.branchId = branchFilter;
        if (dateFrom || dateTo) {
          where.createdAt = {};
          if (dateFrom) where.createdAt.gte = new Date(dateFrom);
          if (dateTo) where.createdAt.lte = new Date(dateTo);
        }

        const [transactions, stats] = await Promise.all([
          db.cashTransaction.findMany({
            where,
            include: {
              user: { select: { name: true } },
              debitAccount: { select: { code: true, name: true } },
              creditAccount: { select: { code: true, name: true } },
            },
            orderBy: { createdAt: 'desc' },
            take: 500,
          }),
          db.cashTransaction.groupBy({
            by: ['category'],
            where,
            _sum: { amount: true },
            _count: true,
          }),
        ]);

        const inflow = transactions.filter((t) => t.type === 'INFLOW').reduce((s, t) => s + Number(t.amount), 0);
        const outflow = transactions.filter((t) => t.type === 'OUTFLOW').reduce((s, t) => s + Number(t.amount), 0);

        return NextResponse.json({
          type: 'cash-flow',
          summary: {
            totalInflow: inflow,
            totalOutflow: outflow,
            netFlow: inflow - outflow,
            totalTransactions: transactions.length,
          },
          categoryBreakdown: stats.map((s) => ({
            category: s.category,
            count: s._count,
            totalAmount: Number(s._sum.amount || 0),
          })),
          data: transactions.map((t) => ({
            id: t.id,
            transactionNumber: t.transactionNumber,
            type: t.type,
            category: t.category,
            amount: Number(t.amount),
            description: t.description,
            debitAccount: t.debitAccount,
            creditAccount: t.creditAccount,
            referenceType: t.referenceType,
            referenceId: t.referenceId,
            userName: t.user?.name,
            createdAt: t.createdAt.toISOString(),
          })),
        });
      }

      default: {
        return NextResponse.json({
          error: 'Tipe laporan tidak dikenali. Gunakan: loan-summary, payment-summary, overdue-report, branch-summary, cash-flow',
        }, { status: 400 });
      }
    }
  } catch (error) {
    console.error('Get reports error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}