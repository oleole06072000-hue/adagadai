import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;

    const loan = await db.loan.findUnique({
      where: { id },
      include: {
        customer: true,
        surveyor: { select: { id: true, name: true, username: true } },
        branch: true,
        assessment: {
          include: {
            category: { select: { id: true, name: true } },
            item: { select: { id: true, name: true, brand: true, model: true } },
          },
        },
        account: { select: { id: true, code: true, name: true } },
        approval: true,
        payments: {
          orderBy: { createdAt: 'desc' },
          include: {
            receivedBy: { select: { id: true, name: true } },
            account: { select: { id: true, code: true, name: true } },
          },
        },
        extensions: {
          orderBy: { createdAt: 'desc' },
          include: {
            extendedBy: { select: { id: true, name: true } },
          },
        },
        activityLogs: {
          orderBy: { createdAt: 'desc' },
          take: 20,
          include: {
            user: { select: { id: true, name: true, username: true } },
          },
        },
        _count: { select: { payments: true, extensions: true, activityLogs: true } },
      },
    });

    if (!loan) {
      return NextResponse.json({ error: 'Pinjaman tidak ditemukan' }, { status: 404 });
    }

    // Calculate overdue info
    const now = new Date();
    const dueDate = new Date(loan.dueDate);
    const daysOverdue = Math.max(0, Math.floor((now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));
    const monthsOverdue = Math.ceil(daysOverdue / 30);
    const outstanding = Number(loan.outstanding);
    const serviceFeeCalc = monthsOverdue > 0 ? (outstanding * 0.01 * monthsOverdue) : 0;
    const penaltyCalc = daysOverdue > 0 ? (daysOverdue * 5000) : 0;
    const totalPayable = outstanding + serviceFeeCalc + penaltyCalc;

    return NextResponse.json({
      ...loan,
      customer: loan.customer ? {
        ...loan.customer,
        birthDate: loan.customer.birthDate?.toISOString() || null,
        createdAt: loan.customer.createdAt.toISOString(),
        updatedAt: loan.customer.updatedAt.toISOString(),
      } : null,
      principalAmount: Number(loan.principalAmount),
      loanAmount: Number(loan.loanAmount),
      outstanding: Number(loan.outstanding),
      adminFee: Number(loan.adminFee),
      serviceFee: Number(loan.serviceFee),
      penaltyFee: Number(loan.penaltyFee),
      roundingIncome: Number(loan.roundingIncome),
      loanDate: loan.loanDate.toISOString(),
      dueDate: loan.dueDate.toISOString(),
      maturityDate: loan.maturityDate?.toISOString() || null,
      closeDate: loan.closeDate?.toISOString() || null,
      payments: loan.payments.map((p) => ({
        ...p,
        principalPaid: Number(p.principalPaid),
        serviceFeePaid: Number(p.serviceFeePaid),
        penaltyPaid: Number(p.penaltyPaid),
        adminFeePaid: Number(p.adminFeePaid),
        totalPaid: Number(p.totalPaid),
        remainingPrincipal: Number(p.remainingPrincipal),
        remainingOutstanding: Number(p.remainingOutstanding),
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
      })),
      extensions: loan.extensions.map((e) => ({
        ...e,
        previousDueDate: e.previousDueDate.toISOString(),
        newDueDate: e.newDueDate.toISOString(),
        serviceFee: Number(e.serviceFee),
        createdAt: e.createdAt.toISOString(),
        updatedAt: e.updatedAt.toISOString(),
      })),
      activityLogs: loan.activityLogs.map((a) => ({
        ...a,
        createdAt: a.createdAt.toISOString(),
      })),
      createdAt: loan.createdAt.toISOString(),
      updatedAt: loan.updatedAt.toISOString(),
      overdueInfo: {
        daysOverdue,
        monthsOverdue,
        serviceFeeDue: serviceFeeCalc,
        penaltyDue: penaltyCalc,
        totalPayable,
      },
    });
  } catch (error) {
    console.error('Get loan error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;
    const body = await req.json();

    const data: any = { ...body };
    delete data.id;
    delete data.loanNumber;
    delete data.createdAt;

    const loan = await db.loan.update({
      where: { id },
      data,
      include: {
        customer: { select: { id: true, name: true, nik: true, phone: true } },
        surveyor: { select: { id: true, name: true } },
        branch: { select: { id: true, code: true, name: true } },
        assessment: { select: { id: true, assessmentNumber: true, itemName: true } },
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'UPDATE',
        module: 'LOAN',
        description: `Mengubah pinjaman: ${loan.loanNumber}`,
        branchId: payload.branchId,
        loanId: loan.id,
      },
    });

    return NextResponse.json({
      ...loan,
      principalAmount: Number(loan.principalAmount),
      loanAmount: Number(loan.loanAmount),
      outstanding: Number(loan.outstanding),
      adminFee: Number(loan.adminFee),
      serviceFee: Number(loan.serviceFee),
      loanDate: loan.loanDate.toISOString(),
      dueDate: loan.dueDate.toISOString(),
      maturityDate: loan.maturityDate?.toISOString() || null,
      closeDate: loan.closeDate?.toISOString() || null,
      createdAt: loan.createdAt.toISOString(),
      updatedAt: loan.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update loan error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}