import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { Prisma } from '@prisma/client';

function generateLoanNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `LN-${y}${m}${d}-${rand}`;
}

function generatePaymentNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `PY-${y}${m}${d}-${rand}`;
}

function generateApprovalNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `AP-${y}${m}${d}-${rand}`;
}

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const search = sp.get('search');
    const status = sp.get('status');
    const page = sp.get('page') || '1';
    const limit = sp.get('limit') || '20';
    const branchId = sp.get('branchId');
    const dueDateFrom = sp.get('dueDateFrom');
    const dueDateTo = sp.get('dueDateTo');
    const loanDateFrom = sp.get('loanDateFrom');
    const loanDateTo = sp.get('loanDateTo');

    const where: Prisma.LoanWhereInput = {};

    // Branch filtering
    if (payload.branchId && payload.role !== 'ADMIN') {
      where.branchId = payload.branchId;
    }
    if (branchId && payload.role === 'ADMIN') {
      where.branchId = branchId;
    }

    if (status) {
      where.status = status;
    }
    if (dueDateFrom || dueDateTo) {
      where.dueDate = {};
      if (dueDateFrom) where.dueDate.gte = new Date(dueDateFrom);
      if (dueDateTo) where.dueDate.lte = new Date(dueDateTo);
    }
    if (loanDateFrom || loanDateTo) {
      where.loanDate = {};
      if (loanDateFrom) where.loanDate.gte = new Date(loanDateFrom);
      if (loanDateTo) where.loanDate.lte = new Date(loanDateTo);
    }
    if (search) {
      where.OR = [
        { loanNumber: { contains: search } },
        { customer: { name: { contains: search } } },
        { customer: { nik: { contains: search } } },
      ];
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const [loans, total] = await Promise.all([
      db.loan.findMany({
        where,
        include: {
          customer: { select: { id: true, name: true, nik: true, phone: true, customerNumber: true } },
          surveyor: { select: { id: true, name: true, username: true } },
          branch: { select: { id: true, code: true, name: true } },
          assessment: { select: { id: true, assessmentNumber: true, itemName: true, grade: true, photos: true } },
          account: { select: { id: true, code: true, name: true } },
          approval: { select: { id: true, status: true, approvalNumber: true } },
          _count: { select: { payments: true, extensions: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
      }),
      db.loan.count({ where }),
    ]);

    return NextResponse.json({
      data: loans.map((l) => ({
        ...l,
        principalAmount: Number(l.principalAmount),
        loanAmount: Number(l.loanAmount),
        outstanding: Number(l.outstanding),
        adminFee: Number(l.adminFee),
        serviceFee: Number(l.serviceFee),
        penaltyFee: Number(l.penaltyFee),
        roundingIncome: Number(l.roundingIncome),
        loanDate: l.loanDate.toISOString(),
        dueDate: l.dueDate.toISOString(),
        maturityDate: l.maturityDate?.toISOString() || null,
        closeDate: l.closeDate?.toISOString() || null,
        createdAt: l.createdAt.toISOString(),
        updatedAt: l.updatedAt.toISOString(),
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    console.error('Get loans error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();
    const {
      assessmentId,
      principalAmount,
      loanAmount,
      adminFee,
      serviceFeeRate,
      serviceFee,
      loanPeriodDays,
      accountId,
      disbursementMethod,
      bankName,
      bankAccount,
      bankAccountHolder,
    } = body;

    if (!assessmentId) {
      return NextResponse.json({ error: 'Assessment ID wajib diisi' }, { status: 400 });
    }

    // Get assessment
    const assessment = await db.assessment.findUnique({
      where: { id: assessmentId },
      include: { customer: true, branch: true },
    });

    if (!assessment) {
      return NextResponse.json({ error: 'Simulasi gadai tidak ditemukan' }, { status: 404 });
    }

    if (assessment.status === 'LOAN_CREATED') {
      return NextResponse.json({ error: 'Simulasi ini sudah dibuatkan pinjaman' }, { status: 400 });
    }

    // Calculate due date
    const loanDate = new Date();
    const dueDate = new Date(loanDate);
    dueDate.setDate(dueDate.getDate() + (loanPeriodDays || 30));

    // Create approval
    const approvalNumber = generateApprovalNumber();
    const approval = await db.approval.create({
      data: {
        approvalNumber,
        type: 'LOAN',
        referenceId: assessmentId,
        status: 'PENDING',
      },
    });

    // Calculate values
    const principal = principalAmount || Number(assessment.recommendedLoan);
    const fee = adminFee || Number(assessment.adminFee);
    const totalLoan = loanAmount || (principal + fee);
    const sFee = serviceFee || 0;

    // Create loan
    const loanNumber = generateLoanNumber();
    const loan = await db.loan.create({
      data: {
        loanNumber,
        assessmentId,
        customerId: assessment.customerId,
        surveyorId: assessment.surveyorId,
        branchId: assessment.branchId || payload.branchId || null,
        principalAmount: principal,
        loanAmount: totalLoan,
        outstanding: totalLoan,
        adminFee: fee,
        serviceFeeRate: serviceFeeRate || 1,
        serviceFee: sFee,
        loanDate,
        dueDate,
        disbursementMethod: disbursementMethod || assessment.disbursementMethod || 'CASH',
        bankName: bankName || assessment.bankName,
        bankAccount: bankAccount || assessment.bankAccount,
        bankAccountHolder: bankAccountHolder || assessment.bankAccountHolder,
        accountId,
        approvalId: approval.id,
        status: 'PENDING_APPROVAL',
      },
      include: {
        customer: { select: { id: true, name: true, nik: true, phone: true } },
        surveyor: { select: { id: true, name: true } },
        branch: { select: { id: true, code: true, name: true } },
        assessment: { select: { id: true, assessmentNumber: true, itemName: true } },
        approval: true,
      },
    });

    // Update assessment status
    await db.assessment.update({
      where: { id: assessmentId },
      data: {
        status: 'LOAN_CREATED',
        approvalId: approval.id,
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'LOAN',
        description: `Membuat pinjaman baru: ${loanNumber} dari simulasi ${assessment.assessmentNumber}`,
        branchId: payload.branchId || assessment.branchId,
        loanId: loan.id,
      },
    });

    return NextResponse.json({
      ...loan,
      principalAmount: Number(loan.principalAmount),
      loanAmount: Number(loan.loanAmount),
      outstanding: Number(loan.outstanding),
      adminFee: Number(loan.adminFee),
      serviceFee: Number(loan.serviceFee),
      loanDate: loan.loanDate.toISOString(),
      dueDate: loan.dueDate.toISOString(),
      createdAt: loan.createdAt.toISOString(),
      updatedAt: loan.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create loan error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

// Payment endpoint (POST /api/loans with action=payment)
export async function PUT(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();

    // Handle payment
    if (body.action === 'payment' && body.loanId) {
      const { loanId, amount, paymentMethod, accountId, notes } = body;

      const loan = await db.loan.findUnique({
        where: { id: loanId },
        include: { customer: true, branch: true },
      });

      if (!loan) {
        return NextResponse.json({ error: 'Pinjaman tidak ditemukan' }, { status: 404 });
      }

      if (loan.status === 'PAID_OFF' || loan.status === 'CLOSED') {
        return NextResponse.json({ error: 'Pinjaman sudah dilunasi/ditutup' }, { status: 400 });
      }

      const paymentAmount = Number(amount) || 0;
      const outstanding = Number(loan.outstanding);
      const principal = Number(loan.principalAmount);

      // Calculate fees
      const now = new Date();
      const dueDate = new Date(loan.dueDate);
      const daysOverdue = Math.max(0, Math.floor((now.getTime() - dueDate.getTime()) / (1000 * 60 * 60 * 24)));

      // Service fee: 1% of outstanding per month overdue
      const monthsOverdue = Math.ceil(daysOverdue / 30);
      const serviceFeeCalc = monthsOverdue > 0 ? (outstanding * 0.01 * monthsOverdue) : 0;

      // Penalty: 5000 per day overdue
      const penaltyCalc = daysOverdue > 0 ? (daysOverdue * 5000) : 0;

      // Calculate payment distribution
      let principalPaid = 0;
      let serviceFeePaid = 0;
      let penaltyPaid = 0;
      let adminFeePaid = 0;
      let remaining = paymentAmount;

      // Pay service fee first
      serviceFeePaid = Math.min(remaining, serviceFeeCalc);
      remaining -= serviceFeePaid;

      // Pay penalty
      penaltyPaid = Math.min(remaining, penaltyCalc);
      remaining -= penaltyPaid;

      // Pay admin fee
      const adminFeeCalc = Number(loan.adminFee);
      adminFeePaid = Math.min(remaining, adminFeeCalc);
      remaining -= adminFeePaid;

      // Pay principal
      principalPaid = Math.min(remaining, outstanding);
      remaining -= principalPaid;

      const totalPaid = paymentAmount - remaining;
      const newOutstanding = outstanding - principalPaid;

      // Create payment
      const paymentNumber = generatePaymentNumber();
      const payment = await db.payment.create({
        data: {
          paymentNumber,
          loanId,
          customerId: loan.customerId,
          type: newOutstanding <= 0 ? 'PAYOFF' : 'PARTIAL',
          principalPaid,
          serviceFeePaid,
          penaltyPaid,
          adminFeePaid,
          totalPaid,
          remainingPrincipal: Math.max(0, newOutstanding),
          remainingOutstanding: Math.max(0, newOutstanding + serviceFeeCalc - serviceFeePaid + penaltyCalc - penaltyPaid),
          paymentMethod: paymentMethod || 'CASH',
          accountId,
          receivedById: payload.userId,
          notes,
        },
      });

      // Update loan
      const loanUpdateData: any = {
        outstanding: Math.max(0, newOutstanding),
        serviceFee: serviceFeeCalc,
        penaltyFee: penaltyCalc,
        status: newOutstanding <= 0 ? 'PAID_OFF' : loan.status,
        closeDate: newOutstanding <= 0 ? new Date() : null,
      };

      // Mark as overdue if past due and not already
      if (daysOverdue > 0 && loan.status === 'ACTIVE') {
        loanUpdateData.status = 'OVERDUE';
      }

      await db.loan.update({
        where: { id: loanId },
        data: loanUpdateData,
      });

      // Update loan status if overdue
      if (daysOverdue > 0 && loan.status === 'ACTIVE') {
        await db.loan.update({
          where: { id: loanId },
          data: { status: 'OVERDUE' },
        });
      }

      await db.activityLog.create({
        data: {
          userId: payload.userId,
          action: 'PAYMENT',
          module: 'LOAN',
          description: `Pembayaran pinjaman ${loan.loanNumber}: Rp ${totalPaid.toLocaleString('id-ID')}`,
          branchId: loan.branchId,
          loanId,
        },
      });

      return NextResponse.json({
        ...payment,
        principalPaid: Number(payment.principalPaid),
        serviceFeePaid: Number(payment.serviceFeePaid),
        penaltyPaid: Number(payment.penaltyPaid),
        adminFeePaid: Number(payment.adminFeePaid),
        totalPaid: Number(payment.totalPaid),
        remainingPrincipal: Number(payment.remainingPrincipal),
        remainingOutstanding: Number(payment.remainingOutstanding),
        createdAt: payment.createdAt.toISOString(),
        updatedAt: payment.updatedAt.toISOString(),
        loanStatus: loanUpdateData.status,
      });
    }

    // Regular update
    const { id, ...updateData } = body;
    if (!id) {
      return NextResponse.json({ error: 'ID pinjaman diperlukan' }, { status: 400 });
    }

    const data: any = { ...updateData };
    delete data.action;
    delete data.loanNumber;

    const loan = await db.loan.update({
      where: { id },
      data,
      include: {
        customer: { select: { id: true, name: true, nik: true, phone: true } },
        surveyor: { select: { id: true, name: true } },
        branch: { select: { id: true, code: true, name: true } },
        assessment: { select: { id: true, assessmentNumber: true, itemName: true } },
      },
    });

    return NextResponse.json({
      ...loan,
      principalAmount: Number(loan.principalAmount),
      loanAmount: Number(loan.loanAmount),
      outstanding: Number(loan.outstanding),
      adminFee: Number(loan.adminFee),
      serviceFee: Number(loan.serviceFee),
      penaltyFee: Number(loan.penaltyFee),
      loanDate: loan.loanDate.toISOString(),
      dueDate: loan.dueDate.toISOString(),
      maturityDate: loan.maturityDate?.toISOString() || null,
      closeDate: loan.closeDate?.toISOString() || null,
      createdAt: loan.createdAt.toISOString(),
      updatedAt: loan.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update loan error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}