import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken, hasPermission } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const itemId = sp.get('itemId');
    const isActive = sp.get('isActive');

    const where: Prisma.MasterPriceWhereInput = {};

    if (itemId) {
      where.itemId = itemId;
    }
    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }

    const prices = await db.masterPrice.findMany({
      where,
      include: {
        item: { select: { id: true, name: true, brand: true, model: true, category: { select: { name: true } } } },
      },
      orderBy: { effectiveDate: 'desc' },
    });

    return NextResponse.json({
      data: prices.map((p) => ({
        ...p,
        marketPrice: Number(p.marketPrice),
        liquidationPrice: Number(p.liquidationPrice),
        effectiveDate: p.effectiveDate.toISOString(),
        createdAt: p.createdAt.toISOString(),
        updatedAt: p.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get prices error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (!hasPermission(payload.role, 'master_prices')) {
      return NextResponse.json({ error: 'Anda tidak memiliki akses' }, { status: 403 });
    }

    const body = await req.json();
    const { itemId, marketPrice, liquidationPercent, liquidationPrice, effectiveDate, isActive } = body;

    if (!itemId || !marketPrice) {
      return NextResponse.json({ error: 'Barang dan harga pasar wajib diisi' }, { status: 400 });
    }

    const price = await db.masterPrice.create({
      data: {
        itemId,
        marketPrice,
        liquidationPercent: liquidationPercent || 70,
        liquidationPrice: liquidationPrice || (marketPrice * (liquidationPercent || 70) / 100),
        effectiveDate: effectiveDate ? new Date(effectiveDate) : new Date(),
        isActive: isActive !== undefined ? isActive : true,
      },
      include: {
        item: { select: { id: true, name: true, brand: true, model: true } },
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'MASTER_PRICE',
        description: `Membuat harga barang: ${price.item?.name || itemId} - Rp ${Number(marketPrice).toLocaleString('id-ID')}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...price,
      marketPrice: Number(price.marketPrice),
      liquidationPrice: Number(price.liquidationPrice),
      effectiveDate: price.effectiveDate.toISOString(),
      createdAt: price.createdAt.toISOString(),
      updatedAt: price.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create price error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}