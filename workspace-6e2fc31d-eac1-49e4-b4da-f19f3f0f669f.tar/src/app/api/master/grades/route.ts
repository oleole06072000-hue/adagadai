import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const grades = await db.masterGrade.findMany({
      orderBy: [{ sortOrder: 'asc' }, { minScore: 'desc' }],
    });

    return NextResponse.json({
      data: grades.map((g) => ({
        ...g,
        createdAt: g.createdAt.toISOString(),
        updatedAt: g.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get grades error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (payload.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Hanya admin yang dapat menambah grade' }, { status: 403 });
    }

    const body = await req.json();
    const { grade, factor, description, minScore, maxScore, sortOrder } = body;

    if (!grade) {
      return NextResponse.json({ error: 'Grade wajib diisi' }, { status: 400 });
    }

    const existing = await db.masterGrade.findUnique({ where: { grade } });
    if (existing) {
      return NextResponse.json({ error: 'Grade sudah ada' }, { status: 400 });
    }

    const newGrade = await db.masterGrade.create({
      data: {
        grade,
        factor: factor || 100,
        description,
        minScore: minScore || 0,
        maxScore: maxScore || 100,
        sortOrder: sortOrder || 0,
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'MASTER_GRADE',
        description: `Membuat grade: ${grade}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...newGrade,
      createdAt: newGrade.createdAt.toISOString(),
      updatedAt: newGrade.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create grade error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}