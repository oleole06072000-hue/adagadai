import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken, hasPermission } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const categoryId = sp.get('categoryId');
    const isActive = sp.get('isActive');
    const search = sp.get('search');

    const where: Prisma.MasterChecklistWhereInput = {};

    if (categoryId) {
      where.categoryId = categoryId;
    }
    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }
    if (search) {
      where.name = { contains: search };
    }

    const checklists = await db.masterChecklist.findMany({
      where,
      include: {
        category: { select: { id: true, name: true } },
      },
      orderBy: [{ weight: 'desc' }, { name: 'asc' }],
    });

    return NextResponse.json({
      data: checklists.map((c) => ({
        ...c,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get checklists error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (!hasPermission(payload.role, 'master_checklists')) {
      return NextResponse.json({ error: 'Anda tidak memiliki akses' }, { status: 403 });
    }

    const body = await req.json();
    const { name, categoryId, type, grade, weight, isActive } = body;

    if (!name || !categoryId) {
      return NextResponse.json({ error: 'Nama dan kategori wajib diisi' }, { status: 400 });
    }

    const checklist = await db.masterChecklist.create({
      data: {
        name,
        categoryId,
        type,
        grade,
        weight: weight || 1,
        isActive: isActive !== undefined ? isActive : true,
      },
      include: {
        category: { select: { id: true, name: true } },
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'MASTER_CHECKLIST',
        description: `Membuat checklist: ${name}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...checklist,
      createdAt: checklist.createdAt.toISOString(),
      updatedAt: checklist.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create checklist error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}