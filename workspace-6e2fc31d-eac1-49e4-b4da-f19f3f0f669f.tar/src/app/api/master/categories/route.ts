import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken, hasPermission } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const isActive = sp.get('isActive');
    const search = sp.get('search');

    const where: Prisma.MasterCategoryWhereInput = {};

    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }
    if (search) {
      where.name = { contains: search };
    }

    const categories = await db.masterCategory.findMany({
      where,
      include: {
        _count: { select: { items: true, checklists: true, assessments: true } },
      },
      orderBy: { sortOrder: 'asc' },
    });

    return NextResponse.json({
      data: categories.map((c) => ({
        ...c,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get categories error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (!hasPermission(payload.role, 'master_items')) {
      return NextResponse.json({ error: 'Anda tidak memiliki akses' }, { status: 403 });
    }

    const body = await req.json();
    const { name, description, icon, isActive, sortOrder } = body;

    if (!name) {
      return NextResponse.json({ error: 'Nama kategori wajib diisi' }, { status: 400 });
    }

    const existing = await db.masterCategory.findUnique({ where: { name } });
    if (existing) {
      return NextResponse.json({ error: 'Nama kategori sudah digunakan' }, { status: 400 });
    }

    const category = await db.masterCategory.create({
      data: {
        name,
        description,
        icon,
        isActive: isActive !== undefined ? isActive : true,
        sortOrder: sortOrder || 0,
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'MASTER_CATEGORY',
        description: `Membuat kategori: ${name}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...category,
      createdAt: category.createdAt.toISOString(),
      updatedAt: category.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create category error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

