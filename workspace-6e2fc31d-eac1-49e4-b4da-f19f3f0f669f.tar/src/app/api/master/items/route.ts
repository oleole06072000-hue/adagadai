import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken, hasPermission } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const categoryId = sp.get('categoryId');
    const isActive = sp.get('isActive');
    const search = sp.get('search');
    const includePrices = sp.get('includePrices');

    const where: Prisma.MasterItemWhereInput = {};

    if (categoryId) {
      where.categoryId = categoryId;
    }
    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { brand: { contains: search } },
        { model: { contains: search } },
      ];
    }

    const items = await db.masterItem.findMany({
      where,
      include: {
        category: { select: { id: true, name: true } },
        _count: { select: { prices: true, assessments: true } },
        ...(includePrices === 'true' ? {
          prices: {
            where: { isActive: true },
            orderBy: { effectiveDate: 'desc' },
            take: 1,
          },
        } : {}),
      },
      orderBy: { createdAt: 'desc' },
    });

    return NextResponse.json({
      data: items.map((i) => ({
        ...i,
        prices: i.prices?.map((p) => ({
          ...p,
          marketPrice: Number(p.marketPrice),
          liquidationPrice: Number(p.liquidationPrice),
          effectiveDate: p.effectiveDate.toISOString(),
          createdAt: p.createdAt.toISOString(),
          updatedAt: p.updatedAt.toISOString(),
        })) || [],
        createdAt: i.createdAt.toISOString(),
        updatedAt: i.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get items error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (!hasPermission(payload.role, 'master_items')) {
      return NextResponse.json({ error: 'Anda tidak memiliki akses' }, { status: 403 });
    }

    const body = await req.json();
    const { name, brand, model, categoryId, ram, storage, specs, isActive } = body;

    if (!name || !categoryId) {
      return NextResponse.json({ error: 'Nama dan kategori wajib diisi' }, { status: 400 });
    }

    const item = await db.masterItem.create({
      data: {
        name,
        brand,
        model,
        categoryId,
        ram,
        storage,
        specs,
        isActive: isActive !== undefined ? isActive : true,
      },
      include: {
        category: { select: { id: true, name: true } },
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'MASTER_ITEM',
        description: `Membuat barang: ${name}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...item,
      createdAt: item.createdAt.toISOString(),
      updatedAt: item.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create item error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}