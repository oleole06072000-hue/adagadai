import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const settings = await db.settings.findMany({
      orderBy: { key: 'asc' },
    });

    const settingsMap: Record<string, string> = {};
    for (const s of settings) {
      settingsMap[s.key] = s.value;
    }

    return NextResponse.json({
      data: settings.map((s) => ({
        id: s.id,
        key: s.key,
        value: s.value,
        description: s.description,
        createdAt: s.createdAt.toISOString(),
        updatedAt: s.updatedAt.toISOString(),
      })),
      settings: settingsMap,
    });
  } catch (error) {
    console.error('Get settings error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (payload.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Hanya admin yang dapat mengubah pengaturan' }, { status: 403 });
    }

    const body = await req.json();

    // Support bulk update: { settings: { key: value, ... } }
    if (body.settings && typeof body.settings === 'object') {
      const results = [];
      for (const [key, value] of Object.entries(body.settings)) {
        const setting = await db.settings.upsert({
          where: { key },
          update: { value: String(value) },
          create: { key, value: String(value), description: body.descriptions?.[key] },
        });
        results.push(setting);
      }

      await db.activityLog.create({
        data: {
          userId: payload.userId,
          action: 'UPDATE',
          module: 'SETTINGS',
          description: `Mengubah pengaturan sistem (${Object.keys(body.settings).length} item)`,
          branchId: payload.branchId,
        },
      });

      return NextResponse.json({
        message: 'Pengaturan berhasil disimpan',
        data: results.map((s) => ({
          key: s.key,
          value: s.value,
          updatedAt: s.updatedAt.toISOString(),
        })),
      });
    }

    // Single setting update
    const { key, value, description } = body;
    if (!key) {
      return NextResponse.json({ error: 'Key wajib diisi' }, { status: 400 });
    }

    const setting = await db.settings.upsert({
      where: { key },
      update: { value, description },
      create: { key, value, description },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'UPDATE',
        module: 'SETTINGS',
        description: `Mengubah pengaturan: ${key}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...setting,
      createdAt: setting.createdAt.toISOString(),
      updatedAt: setting.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update settings error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}