import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken, hashPassword, getRolePermissions } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const role = sp.get('role');
    const isActive = sp.get('isActive');
    const branchId = sp.get('branchId');
    const search = sp.get('search');
    const page = sp.get('page') || '1';
    const limit = sp.get('limit') || '20';

    const where: Prisma.UserWhereInput = {};

    if (role) {
      where.role = role;
    }
    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }
    if (branchId) {
      where.branchId = branchId;
    }
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { username: { contains: search } },
        { email: { contains: search } },
      ];
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const [users, total] = await Promise.all([
      db.user.findMany({
        where,
        select: {
          id: true,
          username: true,
          name: true,
          email: true,
          phone: true,
          role: true,
          branchId: true,
          isActive: true,
          lastLogin: true,
          avatar: true,
          createdAt: true,
          updatedAt: true,
          branch: { select: { id: true, code: true, name: true } },
          _count: { select: { assessments: true, loans: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
      }),
      db.user.count({ where }),
    ]);

    return NextResponse.json({
      data: users.map((u) => ({
        ...u,
        lastLogin: u.lastLogin?.toISOString() || null,
        permissions: getRolePermissions(u.role),
        createdAt: u.createdAt.toISOString(),
        updatedAt: u.updatedAt.toISOString(),
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    console.error('Get users error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (payload.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Hanya admin yang dapat membuat pengguna' }, { status: 403 });
    }

    const body = await req.json();
    const { username, password, name, email, phone, role, branchId, avatar } = body;

    if (!username || !password || !name || !role) {
      return NextResponse.json({ error: 'Username, password, nama, dan role wajib diisi' }, { status: 400 });
    }

    const existingUsername = await db.user.findUnique({ where: { username } });
    if (existingUsername) {
      return NextResponse.json({ error: 'Username sudah digunakan' }, { status: 400 });
    }

    const hashedPassword = await hashPassword(password);

    const user = await db.user.create({
      data: {
        username,
        password: hashedPassword,
        name,
        email,
        phone,
        role,
        branchId,
        avatar,
      },
      select: {
        id: true,
        username: true,
        name: true,
        email: true,
        phone: true,
        role: true,
        branchId: true,
        isActive: true,
        avatar: true,
        createdAt: true,
        updatedAt: true,
        branch: { select: { id: true, code: true, name: true } },
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'USER',
        description: `Membuat pengguna: ${username} (${role})`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...user,
      permissions: getRolePermissions(user.role),
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create user error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}