import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken, hashPassword, getRolePermissions } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;

    const user = await db.user.findUnique({
      where: { id },
      select: {
        id: true,
        username: true,
        name: true,
        email: true,
        phone: true,
        role: true,
        branchId: true,
        isActive: true,
        lastLogin: true,
        avatar: true,
        createdAt: true,
        updatedAt: true,
        branch: { select: { id: true, code: true, name: true } },
        _count: { select: { assessments: true, loans: true, approvals: true, activityLogs: true } },
      },
    });

    if (!user) {
      return NextResponse.json({ error: 'Pengguna tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json({
      ...user,
      lastLogin: user.lastLogin?.toISOString() || null,
      permissions: getRolePermissions(user.role),
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Get user error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (payload.role !== 'ADMIN' && payload.userId !== (await params).id) {
      return NextResponse.json({ error: 'Anda tidak memiliki akses' }, { status: 403 });
    }

    const { id } = await params;
    const body = await req.json();

    const data: any = { ...body };
    delete data.id;
    delete data.username;
    delete data.createdAt;
    delete data._count;

    // Hash password if being updated
    if (data.password) {
      data.password = await hashPassword(data.password);
    } else {
      delete data.password;
    }

    const user = await db.user.update({
      where: { id },
      data,
      select: {
        id: true,
        username: true,
        name: true,
        email: true,
        phone: true,
        role: true,
        branchId: true,
        isActive: true,
        avatar: true,
        createdAt: true,
        updatedAt: true,
        branch: { select: { id: true, code: true, name: true } },
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'UPDATE',
        module: 'USER',
        description: `Mengubah pengguna: ${user.username}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...user,
      permissions: getRolePermissions(user.role),
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update user error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (payload.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Hanya admin yang dapat menghapus pengguna' }, { status: 403 });
    }

    const { id } = await params;

    if (id === payload.userId) {
      return NextResponse.json({ error: 'Tidak dapat menonaktifkan diri sendiri' }, { status: 400 });
    }

    const user = await db.user.update({
      where: { id },
      data: { isActive: false },
      select: { id: true, username: true },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'DELETE',
        module: 'USER',
        description: `Menonaktifkan pengguna: ${user.username}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({ message: 'Pengguna berhasil dinonaktifkan' });
  } catch (error) {
    console.error('Delete user error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}