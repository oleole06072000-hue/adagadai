import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const moduleName = sp.get('module');
    const action = sp.get('action');
    const userId = sp.get('userId');
    const loanId = sp.get('loanId');
    const dateFrom = sp.get('dateFrom');
    const dateTo = sp.get('dateTo');
    const page = sp.get('page') || '1';
    const limit = sp.get('limit') || '50';

    const where: Prisma.ActivityLogWhereInput = {};

    if (moduleName) {
      where.module = moduleName;
    }
    if (action) {
      where.action = action;
    }
    if (userId) {
      where.userId = userId;
    }
    if (loanId) {
      where.loanId = loanId;
    }
    if (dateFrom || dateTo) {
      where.createdAt = {};
      if (dateFrom) where.createdAt.gte = new Date(dateFrom);
      if (dateTo) where.createdAt.lte = new Date(dateTo);
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const [logs, total] = await Promise.all([
      db.activityLog.findMany({
        where,
        include: {
          user: { select: { id: true, name: true, username: true, role: true } },
          loan: { select: { id: true, loanNumber: true, customer: { select: { name: true } } } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
      }),
      db.activityLog.count({ where }),
    ]);

    return NextResponse.json({
      data: logs.map((l) => ({
        ...l,
        user: l.user?.name || l.user?.username || 'System',
        loan: l.loan ? {
          id: l.loan.id,
          loanNumber: l.loan.loanNumber,
          customerName: l.loan.customer?.name,
        } : null,
        createdAt: l.createdAt.toISOString(),
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    console.error('Get activity logs error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}