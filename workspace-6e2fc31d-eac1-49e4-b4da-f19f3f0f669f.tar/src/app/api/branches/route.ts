import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { Prisma } from '@prisma/client';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const isActive = sp.get('isActive');
    const search = sp.get('search');

    const where: Prisma.BranchWhereInput = {};

    if (isActive !== null) {
      where.isActive = isActive === 'true';
    }
    if (search) {
      where.OR = [
        { code: { contains: search } },
        { name: { contains: search } },
        { address: { contains: search } },
      ];
    }

    const branches = await db.branch.findMany({
      where,
      include: {
        _count: {
          select: {
            users: true,
            customers: true,
            loans: true,
            accounts: true,
          },
        },
      },
      orderBy: { code: 'asc' },
    });

    return NextResponse.json({
      data: branches.map((b) => ({
        ...b,
        createdAt: b.createdAt.toISOString(),
        updatedAt: b.updatedAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Get branches error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (payload.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Hanya admin yang dapat membuat cabang' }, { status: 403 });
    }

    const body = await req.json();
    const { code, name, address, area, regional, phone } = body;

    if (!code || !name) {
      return NextResponse.json({ error: 'Kode dan nama cabang wajib diisi' }, { status: 400 });
    }

    const existing = await db.branch.findUnique({ where: { code } });
    if (existing) {
      return NextResponse.json({ error: 'Kode cabang sudah digunakan' }, { status: 400 });
    }

    const branch = await db.branch.create({
      data: {
        code,
        name,
        address,
        area,
        regional,
        phone,
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'BRANCH',
        description: `Membuat cabang: ${code} - ${name}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...branch,
      createdAt: branch.createdAt.toISOString(),
      updatedAt: branch.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create branch error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}