import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;

    const branch = await db.branch.findUnique({
      where: { id },
      include: {
        users: {
          where: { isActive: true },
          select: { id: true, username: true, name: true, role },
        },
        _count: {
          select: {
            customers: true,
            loans: { where: { status: { in: ['ACTIVE', 'OVERDUE'] } } },
            accounts: true,
          },
        },
      },
    });

    if (!branch) {
      return NextResponse.json({ error: 'Cabang tidak ditemukan' }, { status: 404 });
    }

    // Get branch loan statistics
    const loanStats = await db.loan.aggregate({
      where: { branchId: id, status: { in: ['ACTIVE', 'OVERDUE'] } },
      _sum: { outstanding: true, principalAmount: true },
    });

    return NextResponse.json({
      ...branch,
      users: branch.users,
      loanStats: {
        totalOutstanding: Number(loanStats._sum.outstanding || 0),
        totalPrincipal: Number(loanStats._sum.principalAmount || 0),
        activeLoans: branch._count.loans,
      },
      createdAt: branch.createdAt.toISOString(),
      updatedAt: branch.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Get branch error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (payload.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Hanya admin yang dapat mengubah cabang' }, { status: 403 });
    }

    const { id } = await params;
    const body = await req.json();

    const data: any = { ...body };
    delete data.id;
    delete data.code;
    delete data.createdAt;

    const branch = await db.branch.update({
      where: { id },
      data,
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'UPDATE',
        module: 'BRANCH',
        description: `Mengubah cabang: ${branch.code} - ${branch.name}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...branch,
      createdAt: branch.createdAt.toISOString(),
      updatedAt: branch.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update branch error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}