import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { Prisma } from '@prisma/client';

function generateApprovalNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `AP-${y}${m}${d}-${rand}`;
}

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const status = sp.get('status');
    const type = sp.get('type');
    const page = sp.get('page') || '1';
    const limit = sp.get('limit') || '20';
    const search = sp.get('search');

    const where: Prisma.ApprovalWhereInput = {};

    if (status) {
      where.status = status;
    }
    if (type) {
      where.type = type;
    }
    if (search) {
      where.approvalNumber = { contains: search };
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const [approvals, total] = await Promise.all([
      db.approval.findMany({
        where,
        include: {
          approver: { select: { id: true, name: true, username: true } },
          assessments: {
            select: {
              id: true,
              assessmentNumber: true,
              itemName: true,
              recommendedLoan: true,
              customer: { select: { name: true } },
              surveyor: { select: { name: true } },
              branch: { select: { name: true } },
            },
          },
          loans: {
            select: {
              id: true,
              loanNumber: true,
              loanAmount: true,
              customer: { select: { name: true } },
              branch: { select: { name: true } },
            },
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
      }),
      db.approval.count({ where }),
    ]);

    return NextResponse.json({
      data: approvals.map((a) => ({
        ...a,
        assessments: a.assessments.map((as) => ({
          ...as,
          recommendedLoan: Number(as.recommendedLoan),
        })),
        loans: a.loans.map((l) => ({
          ...l,
          loanAmount: Number(l.loanAmount),
        })),
        approvedAt: a.approvedAt?.toISOString() || null,
        createdAt: a.createdAt.toISOString(),
        updatedAt: a.updatedAt.toISOString(),
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    console.error('Get approvals error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();
    const { type, referenceId, notes } = body;

    if (!type || !referenceId) {
      return NextResponse.json({ error: 'Tipe dan referensi ID wajib diisi' }, { status: 400 });
    }

    const approvalNumber = generateApprovalNumber();

    const approval = await db.approval.create({
      data: {
        approvalNumber,
        type,
        referenceId,
        status: 'PENDING',
        notes,
      },
      include: {
        approver: { select: { id: true, name: true } },
      },
    });

    // Link to the referenced entity
    if (type === 'ASSESSMENT') {
      await db.assessment.update({
        where: { id: referenceId },
        data: { approvalId: approval.id, status: 'SUBMITTED' },
      });
    } else if (type === 'LOAN') {
      await db.loan.update({
        where: { id: referenceId },
        data: { approvalId: approval.id },
      });
    }

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'APPROVAL',
        description: `Membuat permohonan persetujuan: ${approvalNumber} (${type})`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...approval,
      approvedAt: approval.approvedAt?.toISOString() || null,
      createdAt: approval.createdAt.toISOString(),
      updatedAt: approval.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create approval error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();
    const { id, action, notes } = body;

    if (!id || !action) {
      return NextResponse.json({ error: 'ID dan aksi wajib diisi' }, { status: 400 });
    }

    const approval = await db.approval.findUnique({ where: { id } });
    if (!approval) {
      return NextResponse.json({ error: 'Persetujuan tidak ditemukan' }, { status: 404 });
    }

    if (approval.status !== 'PENDING') {
      return NextResponse.json({ error: 'Persetujuan sudah diproses' }, { status: 400 });
    }

    const newStatus = action === 'approve' ? 'APPROVED' : 'REJECTED';

    const updated = await db.approval.update({
      where: { id },
      data: {
        status: newStatus,
        approverId: payload.userId,
        approvedAt: new Date(),
        notes: notes || approval.notes,
      },
      include: {
        approver: { select: { id: true, name: true } },
      },
    });

    // Update referenced entity
    if (approval.type === 'ASSESSMENT') {
      await db.assessment.update({
        where: { id: approval.referenceId },
        data: {
          status: newStatus === 'APPROVED' ? 'APPROVED' : 'REJECTED',
        },
      });
    } else if (approval.type === 'LOAN') {
      const loan = await db.loan.findUnique({
        where: { id: approval.referenceId },
      });

      if (loan) {
        await db.loan.update({
          where: { id: approval.referenceId },
          data: {
            status: newStatus === 'APPROVED' ? 'ACTIVE' : 'REJECTED',
          },
        });

        // If approved and loan is active, update assessment status
        if (newStatus === 'APPROVED') {
          await db.assessment.update({
            where: { id: loan.assessmentId },
            data: { status: 'LOAN_CREATED' },
          });
        }
      }
    }

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: newStatus === 'APPROVED' ? 'APPROVE' : 'REJECT',
        module: 'APPROVAL',
        description: `${newStatus === 'APPROVED' ? 'Menyetujui' : 'Menolak'} permohonan: ${approval.approvalNumber}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...updated,
      approvedAt: updated.approvedAt?.toISOString() || null,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update approval error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}