import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;

    const approval = await db.approval.findUnique({
      where: { id },
      include: {
        approver: { select: { id: true, name: true, username: true, role: true } },
        assessments: {
          include: {
            customer: { select: { name: true, nik: true, phone: true } },
            surveyor: { select: { name: true } },
            branch: { select: { name: true } },
            category: { select: { name: true } },
            item: { select: { name: true, brand: true, model: true } },
          },
        },
        loans: {
          include: {
            customer: { select: { name: true, nik: true, phone: true } },
            surveyor: { select: { name: true } },
            branch: { select: { name: true } },
            assessment: { select: { itemName: true, grade: true } },
          },
        },
      },
    });

    if (!approval) {
      return NextResponse.json({ error: 'Persetujuan tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json({
      ...approval,
      assessments: approval.assessments.map((a) => ({
        ...a,
        marketPrice: Number(a.marketPrice),
        liquidationPrice: Number(a.liquidationPrice),
        recommendedLoan: Number(a.recommendedLoan),
        adminFee: Number(a.adminFee),
        serviceFee: Number(a.serviceFee),
        createdAt: a.createdAt.toISOString(),
        updatedAt: a.updatedAt.toISOString(),
      })),
      loans: approval.loans.map((l) => ({
        ...l,
        principalAmount: Number(l.principalAmount),
        loanAmount: Number(l.loanAmount),
        outstanding: Number(l.outstanding),
        loanDate: l.loanDate.toISOString(),
        dueDate: l.dueDate.toISOString(),
        createdAt: l.createdAt.toISOString(),
        updatedAt: l.updatedAt.toISOString(),
      })),
      approvedAt: approval.approvedAt?.toISOString() || null,
      createdAt: approval.createdAt.toISOString(),
      updatedAt: approval.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Get approval error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;
    const body = await req.json();
    const { action, notes } = body;

    const approval = await db.approval.findUnique({ where: { id } });
    if (!approval) {
      return NextResponse.json({ error: 'Persetujuan tidak ditemukan' }, { status: 404 });
    }

    if (approval.status !== 'PENDING') {
      return NextResponse.json({ error: 'Persetujuan sudah diproses' }, { status: 400 });
    }

    const newStatus = action === 'approve' ? 'APPROVED' : 'REJECTED';

    const updated = await db.approval.update({
      where: { id },
      data: {
        status: newStatus,
        approverId: payload.userId,
        approvedAt: new Date(),
        notes: notes || approval.notes,
      },
      include: {
        approver: { select: { id: true, name: true } },
      },
    });

    // Update referenced entity
    if (approval.type === 'ASSESSMENT') {
      await db.assessment.update({
        where: { id: approval.referenceId },
        data: {
          status: newStatus === 'APPROVED' ? 'APPROVED' : 'REJECTED',
        },
      });
    } else if (approval.type === 'LOAN') {
      const loan = await db.loan.findUnique({
        where: { id: approval.referenceId },
      });

      if (loan) {
        await db.loan.update({
          where: { id: approval.referenceId },
          data: {
            status: newStatus === 'APPROVED' ? 'ACTIVE' : 'REJECTED',
          },
        });

        if (newStatus === 'APPROVED') {
          await db.assessment.update({
            where: { id: loan.assessmentId },
            data: { status: 'LOAN_CREATED' },
          });
        }
      }
    }

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: newStatus === 'APPROVED' ? 'APPROVE' : 'REJECT',
        module: 'APPROVAL',
        description: `${newStatus === 'APPROVED' ? 'Menyetujui' : 'Menolak'} permohonan: ${approval.approvalNumber}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...updated,
      approvedAt: updated.approvedAt?.toISOString() || null,
      createdAt: updated.createdAt.toISOString(),
      updatedAt: updated.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update approval error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}