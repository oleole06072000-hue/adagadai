import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;

    const assessment = await db.assessment.findUnique({
      where: { id },
      include: {
        customer: true,
        surveyor: { select: { id: true, name: true, username: true } },
        branch: true,
        category: true,
        item: true,
        price: true,
        approval: true,
        loans: {
          orderBy: { createdAt: 'desc' },
          take: 5,
        },
      },
    });

    if (!assessment) {
      return NextResponse.json({ error: 'Simulasi gadai tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json({
      ...assessment,
      customer: assessment.customer ? {
        ...assessment.customer,
        birthDate: assessment.customer.birthDate?.toISOString() || null,
        createdAt: assessment.customer.createdAt.toISOString(),
        updatedAt: assessment.customer.updatedAt.toISOString(),
      } : null,
      marketPrice: Number(assessment.marketPrice),
      liquidationPrice: Number(assessment.liquidationPrice),
      recommendedLoan: Number(assessment.recommendedLoan),
      adminFee: Number(assessment.adminFee),
      serviceFee: Number(assessment.serviceFee),
      createdAt: assessment.createdAt.toISOString(),
      updatedAt: assessment.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Get assessment error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;
    const body = await req.json();

    const existing = await db.assessment.findUnique({ where: { id } });
    if (!existing) {
      return NextResponse.json({ error: 'Simulasi gadai tidak ditemukan' }, { status: 404 });
    }

    if (existing.status === 'LOAN_CREATED') {
      return NextResponse.json({ error: 'Tidak dapat mengubah simulasi yang sudah dibuatkan pinjaman' }, { status: 400 });
    }

    const data: any = { ...body };
    delete data.id;
    delete data.assessmentNumber;
    delete data.createdAt;

    if (data.photos && typeof data.photos !== 'string') {
      data.photos = JSON.stringify(data.photos);
    }
    if (data.checklistResults && typeof data.checklistResults !== 'string') {
      data.checklistResults = JSON.stringify(data.checklistResults);
    }

    const assessment = await db.assessment.update({
      where: { id },
      data,
      include: {
        customer: { select: { id: true, name: true } },
        surveyor: { select: { id: true, name: true } },
        category: true,
        item: true,
        branch: true,
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'UPDATE',
        module: 'ASSESSMENT',
        description: `Mengubah simulasi gadai: ${assessment.assessmentNumber}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...assessment,
      marketPrice: Number(assessment.marketPrice),
      liquidationPrice: Number(assessment.liquidationPrice),
      recommendedLoan: Number(assessment.recommendedLoan),
      adminFee: Number(assessment.adminFee),
      serviceFee: Number(assessment.serviceFee),
      createdAt: assessment.createdAt.toISOString(),
      updatedAt: assessment.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update assessment error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;

    const existing = await db.assessment.findUnique({
      where: { id },
      include: { _count: { select: { loans: true } } },
    });

    if (!existing) {
      return NextResponse.json({ error: 'Simulasi gadai tidak ditemukan' }, { status: 404 });
    }

    if (existing._count.loans > 0) {
      return NextResponse.json({ error: 'Tidak dapat menghapus simulasi yang sudah memiliki pinjaman' }, { status: 400 });
    }

    await db.assessment.delete({ where: { id } });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'DELETE',
        module: 'ASSESSMENT',
        description: `Menghapus simulasi gadai: ${existing.assessmentNumber}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({ message: 'Simulasi gadai berhasil dihapus' });
  } catch (error) {
    console.error('Delete assessment error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}