import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { Prisma } from '@prisma/client';

function generateAssessmentNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  const rand = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `GD-${y}${m}${d}-${rand}`;
}

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const search = sp.get('search');
    const status = sp.get('status');
    const categoryId = sp.get('categoryId');
    const page = sp.get('page') || '1';
    const limit = sp.get('limit') || '20';
    const branchId = sp.get('branchId');

    const where: Prisma.AssessmentWhereInput = {};

    // Branch filtering
    if (payload.branchId && payload.role !== 'ADMIN') {
      where.branchId = payload.branchId;
    }
    if (branchId && payload.role === 'ADMIN') {
      where.branchId = branchId;
    }

    // Surveyor filter
    if (payload.role === 'SURVEYOR') {
      where.surveyorId = payload.userId;
    }

    if (status) {
      where.status = status;
    }
    if (categoryId) {
      where.categoryId = categoryId;
    }
    if (search) {
      where.OR = [
        { assessmentNumber: { contains: search } },
        { customer: { name: { contains: search } } },
        { itemName: { contains: search } },
      ];
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const [assessments, total] = await Promise.all([
      db.assessment.findMany({
        where,
        include: {
          customer: { select: { id: true, name: true, nik: true, phone: true, customerNumber: true } },
          surveyor: { select: { id: true, name: true, username: true } },
          branch: { select: { id: true, code: true, name: true } },
          category: { select: { id: true, name: true } },
          item: { select: { id: true, name: true, brand: true, model: true } },
          approval: { select: { id: true, status: true, approvalNumber: true } },
          _count: { select: { loans: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
      }),
      db.assessment.count({ where }),
    ]);

    return NextResponse.json({
      data: assessments.map((a) => ({
        ...a,
        marketPrice: Number(a.marketPrice),
        liquidationPrice: Number(a.liquidationPrice),
        recommendedLoan: Number(a.recommendedLoan),
        adminFee: Number(a.adminFee),
        serviceFee: Number(a.serviceFee),
        createdAt: a.createdAt.toISOString(),
        updatedAt: a.updatedAt.toISOString(),
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    console.error('Get assessments error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();
    const {
      customerId, categoryId, itemId, priceId,
      itemName, itemBrand, itemModel, itemRam, itemStorage, itemSpecs,
      photos, marketPrice, liquidationPercent, liquidationPrice,
      grade, gradeFactor, recommendedLoan, adminFee, serviceFee,
      autoDescription, description,
      disbursementMethod, bankName, bankAccount, bankAccountHolder,
      checklistResults, status, notes,
    } = body;

    if (!customerId) {
      return NextResponse.json({ error: 'Nasabah wajib dipilih' }, { status: 400 });
    }

    const assessmentNumber = generateAssessmentNumber();

    const assessment = await db.assessment.create({
      data: {
        assessmentNumber,
        customerId,
        surveyorId: payload.userId,
        branchId: payload.branchId || null,
        categoryId,
        itemId,
        priceId,
        itemName,
        itemBrand,
        itemModel,
        itemRam,
        itemStorage,
        itemSpecs,
        photos: typeof photos === 'string' ? photos : JSON.stringify(photos || []),
        marketPrice: marketPrice || 0,
        liquidationPercent: liquidationPercent || 70,
        liquidationPrice: liquidationPrice || 0,
        grade: grade || 'B',
        gradeFactor: gradeFactor || 80,
        recommendedLoan: recommendedLoan || 0,
        adminFee: adminFee || 0,
        serviceFee: serviceFee || 0,
        autoDescription,
        description,
        disbursementMethod: disbursementMethod || 'CASH',
        bankName,
        bankAccount,
        bankAccountHolder,
        checklistResults: typeof checklistResults === 'string' ? checklistResults : JSON.stringify(checklistResults || []),
        status: status || 'DRAFT',
        notes,
      },
      include: {
        customer: { select: { id: true, name: true, nik: true, phone: true } },
        surveyor: { select: { id: true, name: true } },
        category: true,
        item: true,
        branch: true,
      },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'ASSESSMENT',
        description: `Membuat simulasi gadai: ${assessmentNumber}`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...assessment,
      marketPrice: Number(assessment.marketPrice),
      liquidationPrice: Number(assessment.liquidationPrice),
      recommendedLoan: Number(assessment.recommendedLoan),
      adminFee: Number(assessment.adminFee),
      serviceFee: Number(assessment.serviceFee),
      createdAt: assessment.createdAt.toISOString(),
      updatedAt: assessment.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create assessment error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}