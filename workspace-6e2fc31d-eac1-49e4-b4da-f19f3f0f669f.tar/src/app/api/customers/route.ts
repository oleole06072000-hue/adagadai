import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';
import { Prisma } from '@prisma/client';

function generateCustomerNumber(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const rand = String(Math.floor(Math.random() * 1000000)).padStart(6, '0');
  return `NSB-${y}${m}-${rand}`;
}

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const sp = req.nextUrl.searchParams;
    const search = sp.get('search');
    const page = sp.get('page') || '1';
    const limit = sp.get('limit') || '20';
    const branchId = sp.get('branchId');
    const id = sp.get('id');

    // Get by ID
    if (id) {
      const customer = await db.customer.findUnique({
        where: { id },
        include: {
          branch: true,
          _count: { select: { assessments: true, loans: true } },
        },
      });

      if (!customer) {
        return NextResponse.json({ error: 'Nasabah tidak ditemukan' }, { status: 404 });
      }

      return NextResponse.json({
        ...customer,
        birthDate: customer.birthDate?.toISOString() || null,
        createdAt: customer.createdAt.toISOString(),
        updatedAt: customer.updatedAt.toISOString(),
      });
    }

    const where: Prisma.CustomerWhereInput = {};

    // Branch filtering
    if (payload.branchId && payload.role !== 'ADMIN') {
      where.branchId = payload.branchId;
    }
    if (branchId && payload.role === 'ADMIN') {
      where.branchId = branchId;
    }

    // Search
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { nik: { contains: search } },
        { customerNumber: { contains: search } },
        { phone: { contains: search } },
      ];
    }

    const pageNum = parseInt(page);
    const limitNum = parseInt(limit);
    const skip = (pageNum - 1) * limitNum;

    const [customers, total] = await Promise.all([
      db.customer.findMany({
        where,
        include: {
          branch: { select: { id: true, code: true, name: true } },
          _count: { select: { loans: true, assessments: true } },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
      }),
      db.customer.count({ where }),
    ]);

    return NextResponse.json({
      data: customers.map((c) => ({
        ...c,
        birthDate: c.birthDate?.toISOString() || null,
        createdAt: c.createdAt.toISOString(),
        updatedAt: c.updatedAt.toISOString(),
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    console.error('Get customers error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();
    const {
      name, nik, birthPlace, birthDate, gender, address, kelurahan,
      kecamatan, kabupaten, provinsi, postalCode, phone, email,
      occupation, maritalStatus, ktpPhoto, branchId,
    } = body;

    if (!name || !nik || !phone) {
      return NextResponse.json({ error: 'Nama, NIK, dan telepon wajib diisi' }, { status: 400 });
    }

    // Check NIK uniqueness
    const existingNik = await db.customer.findUnique({ where: { nik } });
    if (existingNik) {
      return NextResponse.json({ error: 'NIK sudah terdaftar' }, { status: 400 });
    }

    const customerNumber = generateCustomerNumber();

    const customer = await db.customer.create({
      data: {
        customerNumber,
        name,
        nik,
        birthPlace,
        birthDate: birthDate ? new Date(birthDate) : null,
        gender,
        address,
        kelurahan,
        kecamatan,
        kabupaten,
        provinsi,
        postalCode,
        phone,
        email,
        occupation,
        maritalStatus,
        ktpPhoto,
        branchId: branchId || payload.branchId || null,
      },
      include: { branch: true },
    });

    // Log activity
    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'CREATE',
        module: 'CUSTOMER',
        description: `Membuat nasabah baru: ${name} (${customerNumber})`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...customer,
      birthDate: customer.birthDate?.toISOString() || null,
      createdAt: customer.createdAt.toISOString(),
      updatedAt: customer.updatedAt.toISOString(),
    }, { status: 201 });
  } catch (error) {
    console.error('Create customer error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const body = await req.json();
    const { id, ...updateData } = body;

    if (!id) {
      return NextResponse.json({ error: 'ID nasabah diperlukan' }, { status: 400 });
    }

    if (updateData.nik) {
      const existingNik = await db.customer.findFirst({
        where: { nik: updateData.nik, NOT: { id } },
      });
      if (existingNik) {
        return NextResponse.json({ error: 'NIK sudah terdaftar' }, { status: 400 });
      }
    }

    const data: any = { ...updateData };
    if (data.birthDate) {
      data.birthDate = new Date(data.birthDate);
    }

    const customer = await db.customer.update({
      where: { id },
      data,
      include: { branch: true },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'UPDATE',
        module: 'CUSTOMER',
        description: `Mengubah data nasabah: ${customer.name} (${customer.customerNumber})`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...customer,
      birthDate: customer.birthDate?.toISOString() || null,
      createdAt: customer.createdAt.toISOString(),
      updatedAt: customer.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update customer error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}