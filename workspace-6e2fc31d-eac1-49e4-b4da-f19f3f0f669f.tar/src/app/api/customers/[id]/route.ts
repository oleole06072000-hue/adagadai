import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;

    const customer = await db.customer.findUnique({
      where: { id },
      include: {
        branch: true,
        _count: { select: { assessments: true, loans: true } },
        loans: {
          where: { status: { in: ['ACTIVE', 'OVERDUE', 'PENDING_APPROVAL'] } },
          take: 5,
          orderBy: { createdAt: 'desc' },
        },
      },
    });

    if (!customer) {
      return NextResponse.json({ error: 'Nasabah tidak ditemukan' }, { status: 404 });
    }

    return NextResponse.json({
      ...customer,
      birthDate: customer.birthDate?.toISOString() || null,
      createdAt: customer.createdAt.toISOString(),
      updatedAt: customer.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Get customer error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    const { id } = await params;
    const body = await req.json();

    if (body.nik) {
      const existingNik = await db.customer.findFirst({
        where: { nik: body.nik, NOT: { id } },
      });
      if (existingNik) {
        return NextResponse.json({ error: 'NIK sudah terdaftar' }, { status: 400 });
      }
    }

    const data: any = { ...body };
    if (data.birthDate) {
      data.birthDate = new Date(data.birthDate);
    }
    delete data.id;

    const customer = await db.customer.update({
      where: { id },
      data,
      include: { branch: true },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'UPDATE',
        module: 'CUSTOMER',
        description: `Mengubah data nasabah: ${customer.name} (${customer.customerNumber})`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({
      ...customer,
      birthDate: customer.birthDate?.toISOString() || null,
      createdAt: customer.createdAt.toISOString(),
      updatedAt: customer.updatedAt.toISOString(),
    });
  } catch (error) {
    console.error('Update customer error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}

export async function DELETE(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');

    if (!token) {
      return NextResponse.json({ error: 'Token tidak ditemukan' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });
    }

    if (payload.role !== 'ADMIN') {
      return NextResponse.json({ error: 'Hanya admin yang dapat menghapus nasabah' }, { status: 403 });
    }

    const { id } = await params;

    // Check for active loans
    const activeLoans = await db.loan.count({
      where: { customerId: id, status: { in: ['ACTIVE', 'OVERDUE', 'PENDING_APPROVAL'] } },
    });

    if (activeLoans > 0) {
      return NextResponse.json({ error: 'Nasabah masih memiliki pinjaman aktif' }, { status: 400 });
    }

    const customer = await db.customer.update({
      where: { id },
      data: { isActive: false },
    });

    await db.activityLog.create({
      data: {
        userId: payload.userId,
        action: 'DELETE',
        module: 'CUSTOMER',
        description: `Menonaktifkan nasabah: ${customer.name} (${customer.customerNumber})`,
        branchId: payload.branchId,
      },
    });

    return NextResponse.json({ message: 'Nasabah berhasil dinonaktifkan' });
  } catch (error) {
    console.error('Delete customer error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}