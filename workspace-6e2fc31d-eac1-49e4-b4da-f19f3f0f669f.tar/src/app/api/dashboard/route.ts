import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { verifyToken } from '@/lib/auth';

export async function GET(req: NextRequest) {
  try {
    const authHeader = req.headers.get('authorization');
    const token = authHeader?.replace('Bearer ', '');
    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Token tidak valid' }, { status: 401 });

    const branchId = payload.branchId || undefined;
    const today = new Date();
    const todayStart = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const todayEnd = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 23, 59, 59, 999);
    const nearDueEnd = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    const twelveMonthsAgo = new Date(today.getFullYear(), today.getMonth() - 11, 1);

    const [
      totalCustomers,
      totalAssessments,
      totalActiveLoans,
      outstandingAgg,
      incomeAgg,
      pendingApprovals,
      nearDueLoans,
      dueLoans,
      todayCustomers,
      todayLoans,
      allRecentLoans,
      allRecentPayments,
      categoryLoans,
      recentActivities,
    ] = await Promise.all([
      db.customer.count({ where: { branchId, isActive: true } }),
      db.assessment.count({ where: { branchId } }),
      db.loan.count({ where: { branchId, status: { in: ['ACTIVE'] } } }),
      db.loan.aggregate({ where: { branchId, status: { in: ['ACTIVE'] } }, _sum: { outstanding: true } }),
      db.payment.aggregate({ _sum: { serviceFeePaid: true, penaltyPaid: true, adminFeePaid: true } }),
      db.approval.count({ where: { status: 'PENDING' } }),
      db.loan.count({ where: { branchId, status: 'ACTIVE', dueDate: { gte: today, lte: nearDueEnd } } }),
      db.loan.count({ where: { branchId, status: 'ACTIVE', dueDate: { gte: todayStart, lte: todayEnd } } }),
      db.customer.count({ where: { branchId, createdAt: { gte: todayStart, lte: todayEnd } } }),
      db.loan.count({ where: { branchId, createdAt: { gte: todayStart, lte: todayEnd } } }),
      db.loan.findMany({
        where: { createdAt: { gte: twelveMonthsAgo }, ...(branchId ? { branchId } : {}) },
        select: { createdAt: true, loanAmount: true },
      }),
      db.payment.findMany({
        where: { createdAt: { gte: twelveMonthsAgo } },
        select: { createdAt: true, totalPaid: true },
      }),
      db.loan.findMany({
        where: { status: { in: ['ACTIVE', 'PENDING_APPROVAL'] } },
        select: { assessment: { select: { category: { select: { name: true } } } } },
        take: 500,
      }),
      db.activityLog.findMany({
        take: 10, orderBy: { createdAt: 'desc' },
        include: { user: { select: { name: true, username: true } } },
      }),
    ]);

    // Build monthly chart data in JS
    const monthlyMap = new Map<string, { loans: number; payments: number }>();
    for (const l of allRecentLoans) {
      const key = `${l.createdAt.getFullYear()}-${String(l.createdAt.getMonth() + 1).padStart(2, '0')}`;
      const entry = monthlyMap.get(key) || { loans: 0, payments: 0 };
      entry.loans += 1;
      monthlyMap.set(key, entry);
    }
    for (const p of allRecentPayments) {
      const key = `${p.createdAt.getFullYear()}-${String(p.createdAt.getMonth() + 1).padStart(2, '0')}`;
      const entry = monthlyMap.get(key) || { loans: 0, payments: 0 };
      entry.payments += Number(p.totalPaid);
      monthlyMap.set(key, entry);
    }

    const monthlyLoans: { month: string; loans: number; payments: number }[] = [];
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des'];
    for (let i = 11; i >= 0; i--) {
      const d = new Date(today.getFullYear(), today.getMonth() - i, 1);
      const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const data = monthlyMap.get(key);
      monthlyLoans.push({
        month: `${monthNames[d.getMonth()]} ${String(d.getFullYear()).slice(2)}`,
        loans: data?.loans || 0,
        payments: data?.payments || 0,
      });
    }

    // Build category distribution
    const catMap: Record<string, number> = {};
    for (const l of categoryLoans) {
      const name = l.assessment?.category?.name || 'Lainnya';
      catMap[name] = (catMap[name] || 0) + 1;
    }
    const categoryDistribution = Object.entries(catMap).map(([name, value]) => ({ name, value }));

    return NextResponse.json({
      kpis: {
        totalCustomers,
        totalAssessments,
        totalActiveLoans,
        totalOutstanding: Number(outstandingAgg._sum.outstanding || 0),
        totalIncome: Number(incomeAgg._sum.serviceFeePaid || 0) + Number(incomeAgg._sum.penaltyPaid || 0) + Number(incomeAgg._sum.adminFeePaid || 0),
        pendingApprovals,
        nearDue: nearDueLoans,
        dueToday: dueLoans,
        overdue: 0,
        todayNewCustomers: todayCustomers,
        todayNewLoans: todayLoans,
      },
      chartData: { monthlyLoans, categoryDistribution },
      recentActivities: recentActivities.map((a) => ({
        id: a.id, action: a.action, module: a.module, description: a.description,
        user: a.user?.name || a.user?.username || 'System',
        createdAt: a.createdAt.toISOString(),
      })),
    });
  } catch (error) {
    console.error('Dashboard error:', error);
    return NextResponse.json({ error: 'Terjadi kesalahan server' }, { status: 500 });
  }
}