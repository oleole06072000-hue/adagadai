'use client';

import { useState, useEffect, useSyncExternalStore } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from 'next-themes';
import { useAuthStore } from '@/stores/auth-store';
import type { JWTPayload } from '@/lib/auth';
import LoginPage from '@/components/ada-gadai/login-page';
import AppShell from '@/components/ada-gadai/app-shell';
import { Toaster } from '@/components/ui/sonner';

const emptySubscribe = () => () => {};

function useHydrated() {
  return useSyncExternalStore(emptySubscribe, () => true, () => false);
}

function AppContent() {
  const { isAuthenticated, login } = useAuthStore();
  const hydrated = useHydrated();

  useEffect(() => {
    if (!hydrated) return;
    const savedToken = localStorage.getItem('ada_gadai_token');
    const savedUser = localStorage.getItem('ada_gadai_user');

    if (savedToken && savedUser && !isAuthenticated) {
      try {
        const user = JSON.parse(savedUser) as JWTPayload;
        login(savedToken, user);
      } catch {
        localStorage.removeItem('ada_gadai_token');
        localStorage.removeItem('ada_gadai_user');
      }
    }
  }, [hydrated, isAuthenticated, login]);

  if (!hydrated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#F5F5F5] dark:bg-gray-950">
        <div className="animate-pulse flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#FBC02D]/20" />
          <div className="h-4 w-24 bg-gray-200 dark:bg-gray-800 rounded" />
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return <AppShell />;
}

export default function Home() {
  const [queryClient] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30 * 1000,
            retry: 1,
            refetchOnWindowFocus: false,
          },
        },
      })
  );

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light" enableSystem disableTransitionOnChange>
        <AppContent />
        <Toaster position="top-right" richColors closeButton />
      </ThemeProvider>
    </QueryClientProvider>
  );
}