import { db } from '@/lib/db';
import { hashPassword } from '@/lib/auth';
import { Prisma } from '@prisma/client';

async function generateNumber(prefix: string, modelName: 'User' | 'Branch' | 'Customer' | 'Assessment' | 'Loan' | 'Payment' | 'Extension' | 'Approval' | 'CashTransaction' | 'Account', dateField?: string): Promise<string> {
  const now = new Date();
  const yyyy = now.getFullYear().toString();
  const mm = now.getMonth().toString().padStart(2, '0');
  const dd = now.getDate().toString().padStart(2, '0');
  
  let datePrefix = prefix;
  if (prefix === 'NSB') {
    datePrefix = `NSB-${yyyy}${mm}`;
  } else if (prefix === 'GD') {
    datePrefix = `GD-${yyyy}${mm}${dd}`;
  } else if (prefix === 'LN') {
    datePrefix = `LN-${yyyy}${mm}${dd}`;
  } else if (prefix === 'PY') {
    datePrefix = `PY-${yyyy}${mm}${dd}`;
  } else if (prefix === 'EX') {
    datePrefix = `EX-${yyyy}${mm}${dd}`;
  } else if (prefix === 'AP') {
    datePrefix = `AP-${yyyy}${mm}${dd}`;
  } else if (prefix === 'CT') {
    datePrefix = `CT-${yyyy}${mm}${dd}`;
  }

  // For customer numbers, we need to check the format NSB-YYYYMM-XXXXX
  // For others, it's PREFIX-YYYYMMDD-XXXXX
  const separatorCount = (prefix === 'NSB') ? 2 : 2;

  // Get count for today/month
  let whereClause: Prisma.WhereInput = {};
  if (prefix === 'NSB') {
    whereClause = { customerNumber: { startsWith: `NSB-${yyyy}${mm}` } };
  } else {
    const dateStr = `${yyyy}${mm}${dd}`;
    whereClause = {
      OR: [
        { loanNumber: { startsWith: `${prefix}-${dateStr}` } },
        { paymentNumber: { startsWith: `${prefix}-${dateStr}` } },
        { assessmentNumber: { startsWith: `${prefix}-${dateStr}` } },
        { extensionNumber: { startsWith: `${prefix}-${dateStr}` } },
        { approvalNumber: { startsWith: `${prefix}-${dateStr}` } },
        { transactionNumber: { startsWith: `${prefix}-${dateStr}` } },
      ]
    };
  }

  let count = 0;
  if (modelName === 'Customer') {
    count = await db.customer.count({ where: { customerNumber: { startsWith: `NSB-${yyyy}${mm}` } } });
  } else if (modelName === 'Assessment') {
    count = await db.assessment.count({ where: { assessmentNumber: { startsWith: `GD-${yyyy}${mm}${dd}` } } });
  } else if (modelName === 'Loan') {
    count = await db.loan.count({ where: { loanNumber: { startsWith: `LN-${yyyy}${mm}${dd}` } } });
  } else if (modelName === 'Payment') {
    count = await db.payment.count({ where: { paymentNumber: { startsWith: `PY-${yyyy}${mm}${dd}` } } });
  } else if (modelName === 'Extension') {
    count = await db.extension.count({ where: { extensionNumber: { startsWith: `EX-${yyyy}${mm}${dd}` } } });
  } else if (modelName === 'Approval') {
    count = await db.approval.count({ where: { approvalNumber: { startsWith: `AP-${yyyy}${mm}${dd}` } } });
  } else if (modelName === 'CashTransaction') {
    count = await db.cashTransaction.count({ where: { transactionNumber: { startsWith: `CT-${yyyy}${mm}${dd}` } } });
  }

  const seq = (count + 1).toString().padStart(6, '0');
  return `${datePrefix}-${seq}`;
}

async function seed() {
  console.log('🌱 Seeding ADA GADAI database...\n');

  // Seed Branches
  const branch1 = await db.branch.upsert({
    where: { code: 'CB-JKT-001' },
    update: {},
    create: { code: 'CB-JKT-001', name: 'Cabang Jakarta Pusat', area: 'Jakarta', regional: 'Jabodetabek', address: 'Jl. Gajah Mada No. 100', phone: '021-1234567' }
  });
  const branch2 = await db.branch.upsert({
    where: { code: 'CB-BDG-001' },
    update: {},
    create: { code: 'CB-BDG-001', name: 'Cabang Bandung', area: 'Jawa Barat', regional: 'Jawa Barat', address: 'Jl. Asia Afrika No. 50', phone: '022-7654321' }
  });
  const branch3 = await db.branch.upsert({
    where: { code: 'CB-SBY-001' },
    update: {},
    create: { code: 'CB-SBY-001', name: 'Cabang Surabaya', area: 'Jawa Timur', regional: 'Jawa Timur', address: 'Jl. Tunjungan No. 75', phone: '031-9876543' }
  });
  console.log('✅ Branches seeded');

  // Seed Users
  const adminPw = await hashPassword('admin123');
  const surveyorPw = await hashPassword('surveyor123');
  const kcPw = await hashPassword('kc123');

  await db.user.upsert({ where: { username: 'admin' }, update: {}, create: { username: 'admin', password: adminPw, name: 'Administrator', email: 'admin@adagadai.com', phone: '081234567890', role: 'ADMIN', branchId: branch1.id } });
  await db.user.upsert({ where: { username: 'surveyor1' }, update: {}, create: { username: 'surveyor1', password: surveyorPw, name: 'Budi Santoso', email: 'budi@adagadai.com', phone: '081234567891', role: 'SURVEYOR', branchId: branch1.id } });
  await db.user.upsert({ where: { username: 'kc_jakarta' }, update: {}, create: { username: 'kc_jakarta', password: kcPw, name: 'Hendra Wijaya', email: 'hendra@adagadai.com', phone: '081234567892', role: 'KEPALA_CABANG', branchId: branch1.id } });
  await db.user.upsert({ where: { username: 'surveyor2' }, update: {}, create: { username: 'surveyor2', password: surveyorPw, name: 'Dewi Lestari', email: 'dewi@adagadai.com', phone: '081234567893', role: 'SURVEYOR', branchId: branch2.id } });
  await db.user.upsert({ where: { username: 'kc_bandung' }, update: {}, create: { username: 'kc_bandung', password: kcPw, name: 'Agus Pratama', email: 'agus@adagadai.com', phone: '081234567894', role: 'KEPALA_CABANG', branchId: branch2.id } });
  console.log('✅ Users seeded');

  // Seed Master Grades
  const grades = [
    { grade: 'A+', factor: 100, description: 'Kondisi sempurna seperti baru', minScore: 90, maxScore: 100, sortOrder: 1 },
    { grade: 'A', factor: 90, description: 'Kondisi sangat baik, minim goresan', minScore: 75, maxScore: 89, sortOrder: 2 },
    { grade: 'B', factor: 80, description: 'Kondisi baik, ada sedikit goresan', minScore: 55, maxScore: 74, sortOrder: 3 },
    { grade: 'C', factor: 70, description: 'Kondisi cukup, ada goresan dan dent', minScore: 30, maxScore: 54, sortOrder: 4 },
    { grade: 'F', factor: 60, description: 'Kondisi buruk, rusak berat', minScore: 0, maxScore: 29, sortOrder: 5 },
  ];
  for (const g of grades) {
    await db.masterGrade.upsert({ where: { grade: g.grade }, update: {}, create: g });
  }
  console.log('✅ Grades seeded');

  // Seed Master Categories
  const categories = [
    { name: 'Handphone', icon: 'Smartphone', sortOrder: 1 },
    { name: 'Laptop', icon: 'Laptop', sortOrder: 2 },
    { name: 'Kamera', icon: 'Camera', sortOrder: 3 },
    { name: 'Smartwatch', icon: 'Watch', sortOrder: 4 },
    { name: 'TV', icon: 'Tv', sortOrder: 5 },
    { name: 'Tablet', icon: 'Tablet', sortOrder: 6 },
    { name: 'Console', icon: 'Gamepad2', sortOrder: 7 },
    { name: 'Drone', icon: 'Plane', sortOrder: 8 },
  ];
  const catMap: Record<string, string> = {};
  for (const c of categories) {
    const cat = await db.masterCategory.upsert({ where: { name: c.name }, update: {}, create: c });
    catMap[c.name] = cat.id;
  }
  console.log('✅ Categories seeded');

  // Seed Master Items
  const items = [
    { name: 'iPhone 15 Pro Max', brand: 'Apple', model: 'iPhone 15 Pro Max', categoryId: catMap['Handphone'], ram: '8GB', storage: '256GB' },
    { name: 'iPhone 15', brand: 'Apple', model: 'iPhone 15', categoryId: catMap['Handphone'], ram: '6GB', storage: '128GB' },
    { name: 'Samsung Galaxy S24 Ultra', brand: 'Samsung', model: 'Galaxy S24 Ultra', categoryId: catMap['Handphone'], ram: '12GB', storage: '256GB' },
    { name: 'Samsung Galaxy A54', brand: 'Samsung', model: 'Galaxy A54', categoryId: catMap['Handphone'], ram: '8GB', storage: '128GB' },
    { name: 'Xiaomi 14 Pro', brand: 'Xiaomi', model: '14 Pro', categoryId: catMap['Handphone'], ram: '12GB', storage: '256GB' },
    { name: 'MacBook Pro M3', brand: 'Apple', model: 'MacBook Pro M3 14"', categoryId: catMap['Laptop'], ram: '18GB', storage: '512GB SSD' },
    { name: 'ASUS ROG Strix G16', brand: 'ASUS', model: 'ROG Strix G16', categoryId: catMap['Laptop'], ram: '16GB', storage: '1TB SSD' },
    { name: 'Canon EOS R6 Mark II', brand: 'Canon', model: 'EOS R6 Mark II', categoryId: catMap['Kamera'], storage: '256GB' },
    { name: 'Apple Watch Ultra 2', brand: 'Apple', model: 'Watch Ultra 2', categoryId: catMap['Smartwatch'], storage: '64GB' },
    { name: 'Samsung Galaxy Watch 6', brand: 'Samsung', model: 'Galaxy Watch 6', categoryId: catMap['Smartwatch'], storage: '32GB' },
    { name: 'LG OLED C3 55"', brand: 'LG', model: 'OLED55C3', categoryId: catMap['TV'] },
    { name: 'iPad Pro M2', brand: 'Apple', model: 'iPad Pro M2 12.9"', categoryId: catMap['Tablet'], ram: '8GB', storage: '256GB' },
    { name: 'PlayStation 5', brand: 'Sony', model: 'PS5 Slim', categoryId: catMap['Console'] },
    { name: 'Nintendo Switch OLED', brand: 'Nintendo', model: 'Switch OLED', categoryId: catMap['Console'] },
    { name: 'DJI Mini 4 Pro', brand: 'DJI', model: 'Mini 4 Pro', categoryId: catMap['Drone'] },
  ];
  const itemMap: Record<string, string> = {};
  for (const item of items) {
    const created = await db.masterItem.create({ data: item });
    itemMap[item.name] = created.id;
  }
  console.log('✅ Items seeded');

  // Seed Master Prices
  const prices = [
    { itemId: itemMap['iPhone 15 Pro Max'], marketPrice: 22000000, liquidationPercent: 70 },
    { itemId: itemMap['iPhone 15'], marketPrice: 16000000, liquidationPercent: 70 },
    { itemId: itemMap['Samsung Galaxy S24 Ultra'], marketPrice: 20000000, liquidationPercent: 70 },
    { itemId: itemMap['Samsung Galaxy A54'], marketPrice: 5500000, liquidationPercent: 70 },
    { itemId: itemMap['Xiaomi 14 Pro'], marketPrice: 12000000, liquidationPercent: 70 },
    { itemId: itemMap['MacBook Pro M3'], marketPrice: 35000000, liquidationPercent: 70 },
    { itemId: itemMap['ASUS ROG Strix G16'], marketPrice: 22000000, liquidationPercent: 70 },
    { itemId: itemMap['Canon EOS R6 Mark II'], marketPrice: 35000000, liquidationPercent: 65 },
    { itemId: itemMap['Apple Watch Ultra 2'], marketPrice: 10000000, liquidationPercent: 70 },
    { itemId: itemMap['Samsung Galaxy Watch 6'], marketPrice: 4000000, liquidationPercent: 70 },
    { itemId: itemMap['LG OLED C3 55"'], marketPrice: 15000000, liquidationPercent: 65 },
    { itemId: itemMap['iPad Pro M2'], marketPrice: 18000000, liquidationPercent: 70 },
    { itemId: itemMap['PlayStation 5'], marketPrice: 7000000, liquidationPercent: 70 },
    { itemId: itemMap['Nintendo Switch OLED'], marketPrice: 5000000, liquidationPercent: 70 },
    { itemId: itemMap['DJI Mini 4 Pro'], marketPrice: 10000000, liquidationPercent: 65 },
  ];
  for (const p of prices) {
    const liqPrice = Math.round(Number(p.marketPrice) * p.liquidationPercent / 100);
    await db.masterPrice.create({
      data: { ...p, liquidationPrice: liqPrice }
    });
  }
  console.log('✅ Prices seeded');

  // Seed Master Checklists
  const checklists = [
    { name: 'Layar tidak retak', categoryId: catMap['Handphone'], type: 'VISUAL', grade: 'A+', weight: 3 },
    { name: 'Body tidak lecet', categoryId: catMap['Handphone'], type: 'VISUAL', grade: 'A', weight: 2 },
    { name: 'Tombol berfungsi baik', categoryId: catMap['Handphone'], type: 'FUNCTIONAL', grade: 'A', weight: 2 },
    { name: 'Kamera berfungsi baik', categoryId: catMap['Handphone'], type: 'FUNCTIONAL', grade: 'A', weight: 2 },
    { name: 'Speaker berfungsi baik', categoryId: catMap['Handphone'], type: 'FUNCTIONAL', grade: 'A', weight: 1 },
    { name: 'Charger dan kotak lengkap', categoryId: catMap['Handphone'], type: 'ACCESSORY', grade: 'A+', weight: 1 },
    { name: 'IMEI terbaca', categoryId: catMap['Handphone'], type: 'FUNCTIONAL', grade: null, weight: 3 },
    { name: 'Tidak dalam blacklist', categoryId: catMap['Handphone'], type: 'FUNCTIONAL', grade: null, weight: 5 },
    { name: 'Layar tidak retak', categoryId: catMap['Laptop'], type: 'VISUAL', grade: 'A+', weight: 3 },
    { name: 'Keyboard berfungsi baik', categoryId: catMap['Laptop'], type: 'FUNCTIONAL', grade: 'A', weight: 2 },
    { name: 'Baterai sehat', categoryId: catMap['Laptop'], type: 'FUNCTIONAL', grade: 'A', weight: 2 },
    { name: 'Charger original', categoryId: catMap['Laptop'], type: 'ACCESSORY', grade: 'A+', weight: 1 },
    { name: 'Sensor berfungsi baik', categoryId: catMap['Kamera'], type: 'FUNCTIONAL', grade: 'A', weight: 3 },
    { name: 'Lens tidak jamuran', categoryId: catMap['Kamera'], type: 'VISUAL', grade: 'A+', weight: 3 },
    { name: 'Tali asli', categoryId: catMap['Smartwatch'], type: 'ACCESSORY', grade: 'A+', weight: 1 },
  ];
  for (const c of checklists) {
    await db.masterChecklist.create({ data: c });
  }
  console.log('✅ Checklists seeded');

  // Seed Cash Accounts
  await db.account.upsert({ where: { code: 'KA-001' }, update: {}, create: { code: 'KA-001', name: 'Kas Tunai Jakarta', type: 'CASH', initialBalance: 50000000, currentBalance: 50000000, branchId: branch1.id } });
  await db.account.upsert({ where: { code: 'BK-MND-001' }, update: {}, create: { code: 'BK-MND-001', name: 'Bank Mandiri Jakarta', type: 'BANK', bankName: 'Mandiri', bankAccount: '1234567890', initialBalance: 100000000, currentBalance: 100000000, branchId: branch1.id } });
  await db.account.upsert({ where: { code: 'BK-BCA-001' }, update: {}, create: { code: 'BK-BCA-001', name: 'Bank BCA Jakarta', type: 'BANK', bankName: 'BCA', bankAccount: '0987654321', initialBalance: 100000000, currentBalance: 100000000, branchId: branch1.id } });
  await db.account.upsert({ where: { code: 'KA-002' }, update: {}, create: { code: 'KA-002', name: 'Kas Tunai Bandung', type: 'CASH', initialBalance: 30000000, currentBalance: 30000000, branchId: branch2.id } });
  console.log('✅ Cash accounts seeded');

  // Seed Settings
  const settings = [
    { key: 'admin_fee_percent', value: '0', description: 'Biaya administrasi dalam persen' },
    { key: 'admin_fee_flat', value: '10000', description: 'Biaya administrasi tetap (Rp)' },
    { key: 'service_fee_percent', value: '1', description: 'Biaya jasa per bulan (persen)' },
    { key: 'penalty_fee_per_day', value: '5000', description: 'Denda per hari keterlambatan (Rp)' },
    { key: 'loan_duration_days', value: '90', description: 'Durasi pinjaman default (hari)' },
    { key: 'near_due_days', value: '7', description: 'Peringatan sebelum jatuh tempo (hari)' },
    { key: 'rounding_to', value: '1000', description: 'Pembulatan ke (Rp)' },
    { key: 'max_photos', value: '20', description: 'Maksimal foto barang' },
    { key: 'min_photos', value: '4', description: 'Minimal foto barang' },
    { key: 'liquidation_default_percent', value: '70', description: 'Persentase likuidasi default' },
    { key: 'company_name', value: 'ADA GADAI', description: 'Nama perusahaan' },
    { key: 'company_address', value: 'Jakarta, Indonesia', description: 'Alamat perusahaan' },
  ];
  for (const s of settings) {
    await db.settings.upsert({ where: { key: s.key }, update: {}, create: s });
  }
  console.log('✅ Settings seeded');

  // Seed Sample Customers
  const customers = [
    { customerNumber: 'NSB-202501-000001', name: 'Ahmad Fauzi', nik: '3201010101800001', birthPlace: 'Jakarta', gender: 'L', address: 'Jl. Merdeka No. 10', kelurahan: 'Merdeka', kecamatan: 'Gambir', kabupaten: 'Jakarta Pusat', provinsi: 'DKI Jakarta', postalCode: '10110', phone: '081200001111', email: 'ahmad@email.com', occupation: 'Karyawan Swasta', maritalStatus: 'MARRIED', branchId: branch1.id },
    { customerNumber: 'NSB-202501-000002', name: 'Siti Rahayu', nik: '3201010201800002', birthPlace: 'Bandung', gender: 'P', address: 'Jl. Braga No. 25', kelurahan: 'Braga', kecamatan: 'Sumur Bandung', kabupaten: 'Bandung', provinsi: 'Jawa Barat', postalCode: '40111', phone: '081200002222', email: 'siti@email.com', occupation: 'Wiraswasta', maritalStatus: 'MARRIED', branchId: branch1.id },
    { customerNumber: 'NSB-202501-000003', name: 'Bambang Hermawan', nik: '3201010301800003', birthPlace: 'Surabaya', gender: 'L', address: 'Jl. Basuki Rahmat No. 100', kelurahan: 'Genteng', kecamatan: 'Genteng', kabupaten: 'Surabaya', provinsi: 'Jawa Timur', postalCode: '60275', phone: '081200003333', email: 'bambang@email.com', occupation: 'PNS', maritalStatus: 'SINGLE', branchId: branch2.id },
    { customerNumber: 'NSB-202501-000004', name: 'Diana Putri', nik: '3201010401800004', birthPlace: 'Jakarta', gender: 'P', address: 'Jl. Sudirman No. 50', kelurahan: 'Karet Semanggi', kecamatan: 'Setiabudi', kabupaten: 'Jakarta Selatan', provinsi: 'DKI Jakarta', postalCode: '12930', phone: '081200004444', email: 'diana@email.com', occupation: 'Freelancer', maritalStatus: 'SINGLE', branchId: branch1.id },
    { customerNumber: 'NSB-202501-000005', name: 'Rudi Hartono', nik: '3201010501800005', birthPlace: 'Semarang', gender: 'L', address: 'Jl. Pandanaran No. 30', kelurahan: 'Pandanaran', kecamatan: 'Semarang Tengah', kabupaten: 'Semarang', provinsi: 'Jawa Tengah', postalCode: '50134', phone: '081200005555', email: 'rudi@email.com', occupation: 'Pedagang', maritalStatus: 'MARRIED', branchId: branch2.id },
  ];
  for (const c of customers) {
    await db.customer.upsert({ where: { nik: c.nik }, update: {}, create: c });
  }
  console.log('✅ Customers seeded');

  // Seed Sample Loans with various statuses
  const adminUser = await db.user.findFirst({ where: { username: 'admin' } });
  const surveyor1 = await db.user.findFirst({ where: { username: 'surveyor1' } });
  const cust1 = await db.customer.findFirst({ where: { nik: '3201010101800001' } });
  const cust2 = await db.customer.findFirst({ where: { nik: '3201010201800002' } });
  const cashAccount = await db.account.findFirst({ where: { code: 'KA-001' } });

  if (adminUser && surveyor1 && cust1 && cust2 && cashAccount) {
    // Sample Assessment
    const assessment1 = await db.assessment.create({
      data: {
        assessmentNumber: 'GD-20250115000001',
        customerId: cust1.id,
        surveyorId: surveyor1.id,
        branchId: branch1.id,
        categoryId: catMap['Handphone'],
        itemId: itemMap['iPhone 15 Pro Max'],
        itemName: 'iPhone 15 Pro Max',
        itemBrand: 'Apple',
        itemModel: 'iPhone 15 Pro Max',
        itemRam: '8GB',
        itemStorage: '256GB',
        marketPrice: 22000000,
        liquidationPercent: 70,
        liquidationPrice: 15400000,
        grade: 'A',
        gradeFactor: 90,
        recommendedLoan: 13860000,
        adminFee: 10000,
        serviceFee: 138600,
        autoDescription: 'Apple iPhone 15 Pro Max 8GB/256GB Grade A - Kondisi sangat baik, minim goresan, lengkap dengan charger dan kotak.',
        description: 'Apple iPhone 15 Pro Max 8GB/256GB Grade A - Kondisi sangat baik, minim goresan, lengkap dengan charger dan kotak.',
        disbursementMethod: 'CASH',
        status: 'LOAN_CREATED',
      }
    });

    // Active loan
    const loan1 = await db.loan.create({
      data: {
        loanNumber: 'LN-20250115000001',
        assessmentId: assessment1.id,
        customerId: cust1.id,
        surveyorId: surveyor1.id,
        branchId: branch1.id,
        principalAmount: 13860000,
        loanAmount: 13750000,
        outstanding: 13860000,
        adminFee: 10000,
        serviceFeeRate: 1,
        serviceFee: 138600,
        roundingIncome: 1000,
        loanDate: new Date('2025-01-15'),
        dueDate: new Date('2025-04-15'),
        status: 'ACTIVE',
        disbursementMethod: 'CASH',
        accountId: cashAccount.id,
      }
    });

    // Pending approval
    const assessment2 = await db.assessment.create({
      data: {
        assessmentNumber: 'GD-20250120000001',
        customerId: cust2.id,
        surveyorId: surveyor1.id,
        branchId: branch1.id,
        categoryId: catMap['Laptop'],
        itemId: itemMap['MacBook Pro M3'],
        itemName: 'MacBook Pro M3',
        itemBrand: 'Apple',
        itemModel: 'MacBook Pro M3 14"',
        itemRam: '18GB',
        itemStorage: '512GB SSD',
        marketPrice: 35000000,
        liquidationPercent: 70,
        liquidationPrice: 24500000,
        grade: 'A+',
        gradeFactor: 100,
        recommendedLoan: 24500000,
        adminFee: 10000,
        serviceFee: 245000,
        autoDescription: 'Apple MacBook Pro M3 14" 18GB/512GB SSD Grade A+ - Kondisi sempurna seperti baru, lengkap charger.',
        description: 'Apple MacBook Pro M3 14" 18GB/512GB SSD Grade A+ - Kondisi sempurna seperti baru, lengkap charger.',
        disbursementMethod: 'TRANSFER',
        bankName: 'BCA',
        bankAccount: '1234567890',
        bankAccountHolder: 'Siti Rahayu',
        status: 'SUBMITTED',
      }
    });

    await db.loan.create({
      data: {
        loanNumber: 'LN-20250120000001',
        assessmentId: assessment2.id,
        customerId: cust2.id,
        surveyorId: surveyor1.id,
        branchId: branch1.id,
        principalAmount: 24500000,
        loanAmount: 24500000,
        outstanding: 24500000,
        adminFee: 10000,
        serviceFeeRate: 1,
        serviceFee: 245000,
        loanDate: new Date('2025-01-20'),
        dueDate: new Date('2025-04-20'),
        status: 'PENDING_APPROVAL',
        disbursementMethod: 'TRANSFER',
        bankName: 'BCA',
        bankAccount: '1234567890',
        bankAccountHolder: 'Siti Rahayu',
      }
    });
  }

  console.log('✅ Sample data seeded');
  console.log('\n🎉 ADA GADAI database seeded successfully!');
  console.log('\n📋 Login credentials:');
  console.log('   Admin:     admin / admin123');
  console.log('   Surveyor:  surveyor1 / surveyor123');
  console.log('   Kepala Cabang: kc_jakarta / kc123');
}

seed()
  .catch(console.error)
  .finally(() => process.exit(0));